// Thin DOM layer: HUD updates, menus, toasts, speech bubble.
import { $ } from './util.js';
import { COLORS } from './config.js';

const hex = (n) => '#' + n.toString(16).padStart(6, '0');
const HEART = '<svg class="heart" viewBox="0 0 32 30"><defs><linearGradient id="hg" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="#ff9ad0"/><stop offset="1" stop-color="#ff3d8b"/></linearGradient></defs><path d="M16 29C4 20 1 14 1 9a8 8 0 0 1 15-3.5A8 8 0 0 1 31 9c0 5-3 11-15 20z" fill="url(#hg)" stroke="#fff" stroke-opacity=".7" stroke-width="1.5"/></svg>';

export class UI {
  constructor() {
    this.el = {
      loading: $('loading'), loadFill: $('loadFill'), loadHint: $('loadHint'), hud: $('hud'),
      hearts: $('hearts'), score: $('score'), lvNum: $('lvNum'), lvName: $('lvName'),
      pips: $('pips'), chainTxt: $('chainTxt'), chain: $('chain'), boostFill: $('boostFill'), boostBar: document.querySelector('.boost-wrap .bar'),
      toast: $('toast'), banner: $('banner'), b1: $('b1'), b2: $('b2'), bubble: $('bubble'),
      comp: $('compChip'), compRing: $('compRing'), flash: $('flash'), tip: $('tip'), fps: $('fps')
    };
    this.maxHearts = 3;
    COLORS.forEach((c) => { const p = document.createElement('i'); p.className = 'pip'; p.style.background = hex(c.hex); p.style.color = hex(c.hex); this.el.pips.appendChild(p); });
    this.pipEls = [...this.el.pips.children];
    this._toastT = 0; this._bubbleUntil = 0; this._lastScore = -1; this._lastBoost = -1;
  }

  // ---- screens ----
  screens = ['menu', 'pause', 'over', 'settings', 'auth', 'board', 'how'];
  show(id) { $(id).classList.add('show'); }
  hide(id) { $(id).classList.remove('show'); }
  hideAll() { this.screens.forEach((s) => this.hide(s)); }
  hud(on) { this.el.hud.classList.toggle('hidden', !on); }

  loading(p, msg) { this.el.loadFill.style.width = Math.round(p * 100) + '%'; if (msg) this.el.loadHint.textContent = msg; }
  loaded() { this.el.loading.classList.remove('show'); }

  // ---- HUD ----
  setHearts(n, max = Math.max(3, n), pop = false) {
    this.maxHearts = max;
    const h = this.el.hearts;
    if (h.children.length !== max) { h.innerHTML = HEART.repeat(max); }
    [...h.children].forEach((e, i) => {
      e.classList.toggle('lost', i >= n);
      if (pop && i === n - 1) { e.classList.remove('pop'); void e.getBoundingClientRect(); e.classList.add('pop'); }
    });
  }
  setScore(v) { v = Math.floor(v); if (v !== this._lastScore) { this._lastScore = v; this.el.score.textContent = v.toLocaleString(); } }
  setLevel(num, name) { this.el.lvNum.textContent = num; this.el.lvName.textContent = name; }
  setBoost(frac, boosting, locked) {
    const f = Math.round(frac * 100);
    if (f !== this._lastBoost) { this._lastBoost = f; this.el.boostFill.style.width = f + '%'; }
    this.el.boostBar.classList.toggle('on', boosting);
    this.el.boostBar.classList.toggle('low', locked || frac < 0.12);
  }
  setChain(color, streak, mult) {
    this.pipEls.forEach((p, i) => p.classList.toggle('on', i === color));
    if (color < 0) { this.el.chainTxt.textContent = 'Collect a colour!'; return; }
    const left = 3 - (streak % 3 || 3);
    this.el.chainTxt.textContent = streak >= 3 ? `${COLORS[color].name} ×${mult}  ·  ${left === 0 ? 'chain!' : left + ' to next'}` : `${COLORS[color].name}  ·  ${3 - streak} more for a chain`;
  }
  toast(text, color = '#ffffff') {
    const t = this.el.toast; t.textContent = text; t.style.color = color;
    t.style.textShadow = `0 0 18px ${color}, 0 4px 20px rgba(40,10,90,.5)`;
    t.classList.remove('show'); void t.offsetWidth; t.classList.add('show');
  }
  banner(t1, t2 = '') {
    const b = this.el.banner; this.el.b1.textContent = t1; this.el.b2.textContent = t2;
    b.classList.remove('show'); void b.offsetWidth; b.classList.add('show');
  }
  flash(color = '#ff5a9a') {
    const f = this.el.flash; f.style.setProperty('--flashc', color);
    f.classList.add('on'); requestAnimationFrame(() => requestAnimationFrame(() => f.classList.remove('on')));
  }
  tip(on) { this.el.tip.classList.toggle('on', on); }
  setCompanion(on, frac = 0) {
    this.el.comp.classList.toggle('on', on);
    if (on) this.el.compRing.style.strokeDashoffset = String((1 - frac) * 119.4);
  }
  bubble(text, x, y) {
    const b = this.el.bubble;
    if (text !== null && b.textContent !== text) b.textContent = text;
    b.style.left = x + 'px'; b.style.top = y + 'px'; b.classList.add('on');
  }
  hideBubble() { this.el.bubble.classList.remove('on'); }
  fps(txt) { this.el.fps.textContent = txt; }
  fpsVisible(v) { this.el.fps.classList.toggle('hidden', !v); }
}
