// Optional Firebase layer: username + passcode accounts, Firestore cloud saves (with offline
// persistence) and a global leaderboard. Everything is loaded lazily from Google's CDN only
// when FIREBASE_CONFIG is set, so the game stays 100 % playable offline / without Firebase.

const SDK = '11.10.0';
const BASE = `https://www.gstatic.com/firebasejs/${SDK}`;

export class Cloud {
  constructor(config) {
    this.config = config;
    this.enabled = !!config;
    this.ready = false;
    this.user = null;
    this.fb = null;
    this.unsub = null;
  }

  async init() {
    if (!this.enabled || this.ready) return this.ready;
    try {
      const [app, auth, fs] = await Promise.all([
        import(`${BASE}/firebase-app.js`),
        import(`${BASE}/firebase-auth.js`),
        import(`${BASE}/firebase-firestore.js`)
      ]);
      const a = app.initializeApp(this.config);
      const au = auth.getAuth(a);
      let db;
      try { db = fs.initializeFirestore(a, { localCache: fs.persistentLocalCache({ tabManager: fs.persistentMultipleTabManager() }) }); }
      catch (e) { db = fs.getFirestore(a); }
      this.fb = { app, auth, fs, a, au, db };
      await new Promise((res) => { const off = auth.onAuthStateChanged(au, (u) => { this.user = u; off(); res(); }); });
      this.ready = true;
    } catch (e) {
      console.warn('[cloud] unavailable (offline or blocked):', e);
      this.ready = false;
    }
    return this.ready;
  }

  _email(username) {
    const slug = username.toLowerCase().replace(/[^a-z0-9]+/g, '.').replace(/^\.|\.$/g, '') || 'player';
    return `${slug}@projectbutterfly.game`;
  }
  _pass(pin, username) { return `${pin}-bf-${username.toLowerCase().replace(/\s+/g, '')}`; }

  async signUp(username, pin) {
    const { auth, au } = this.fb;
    const cred = await auth.createUserWithEmailAndPassword(au, this._email(username), this._pass(pin, username));
    this.user = cred.user; return cred.user;
  }
  async signIn(username, pin) {
    const { auth, au } = this.fb;
    const cred = await auth.signInWithEmailAndPassword(au, this._email(username), this._pass(pin, username));
    this.user = cred.user; return cred.user;
  }
  async signOut() { if (this.unsub) { this.unsub(); this.unsub = null; } if (this.fb) await this.fb.auth.signOut(this.fb.au); this.user = null; }

  get signedIn() { return !!(this.ready && this.user); }

  _ref() { const { fs, db } = this.fb; return fs.doc(db, 'players', this.user.uid); }

  async load() {
    if (!this.signedIn) return null;
    try { const snap = await this.fb.fs.getDoc(this._ref()); return snap.exists() ? snap.data() : null; }
    catch (e) { console.warn('[cloud] load failed', e); return null; }
  }

  async save(data) {
    if (!this.signedIn) return;
    try {
      const { fs } = this.fb;
      await fs.setDoc(this._ref(), { ...data, username: data.username, updatedAt: data.updatedAt || Date.now(), serverTime: fs.serverTimestamp() }, { merge: true });
    } catch (e) { console.warn('[cloud] save failed (will retry)', e); }
  }

  // Live updates from other devices (e.g. you finish a level on iPad, iPhone sees it instantly).
  watch(cb) {
    if (!this.signedIn) return;
    if (this.unsub) this.unsub();
    const { fs } = this.fb;
    this.unsub = fs.onSnapshot(this._ref(), (snap) => {
      if (!snap.exists() || snap.metadata.hasPendingWrites) return;
      cb(snap.data());
    }, () => {});
  }

  async leaderboard(n = 10) {
    if (!this.signedIn) return [];
    try {
      const { fs, db } = this.fb;
      const q = fs.query(fs.collection(db, 'players'), fs.orderBy('best', 'desc'), fs.limit(n));
      const snap = await fs.getDocs(q);
      return snap.docs.map((d) => { const x = d.data(); return { name: x.username, best: x.best || 0, level: (x.maxLevel || 0) + 1, you: d.id === this.user.uid }; });
    } catch (e) { console.warn('[cloud] leaderboard failed', e); return []; }
  }
}
