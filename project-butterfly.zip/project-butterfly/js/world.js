// The magical world: sky dome, streamed terrain chunks, glowing runway, water zones,
// instanced scenery (blossom trees, crystals, flowers, lanterns, clouds, floating islands),
// and the level palette that blends smoothly from one level to the next.
import * as THREE from '../vendor/three.bundle.js';
import {
  PATH_HALF_WIDTH, CHUNK_LEN, CHUNK_COUNT, CHUNK_BEHIND, LEVELS, LEVEL_LENGTH, COLORS,
  WATER_FIRST_AT, WATER_PERIOD, WATER_LENGTH, WATER_BLEND, WATER_LEVEL, WATER_DEPTH
} from './config.js';
import { clamp, lerp, smooth, rng, fbm, noise2 } from './util.js';
import { fogU, timeU, FOG_GLSL, glowMaterial, setInstance, setInstanceColor, crystalGeometry, merge, paint } from './geo.js';

// --------------------------------------------------------------------------
// Pure world functions (shared with gameplay)
// --------------------------------------------------------------------------
export function waterFactor(s) {
  if (s < WATER_FIRST_AT - WATER_BLEND) return 0;
  let k = Math.floor((s - WATER_FIRST_AT) / WATER_PERIOD);
  let best = 0;
  for (let j = k; j <= k + 1; j++) {
    if (j < 0) continue;
    const local = s - (WATER_FIRST_AT + j * WATER_PERIOD);
    const w = smooth(-WATER_BLEND, 0, local) * (1 - smooth(WATER_LENGTH, WATER_LENGTH + WATER_BLEND, local));
    if (w > best) best = w;
  }
  return best;
}
export const pathY = (s) => -WATER_DEPTH * waterFactor(s);

export function terrainY(x, s) {
  const ax = Math.abs(x);
  const d = ax - PATH_HALF_WIDTH;
  const py = pathY(s);
  if (d <= 0) return py;
  // gentle banks near the path, big dreamy hills further out
  const side = smooth(0, 7.5, d);
  const hills = fbm(x * 0.035 + 11.3, s * 0.028) * 20 - 3.5;
  const far = smooth(18, 120, d);
  const mount = fbm(x * 0.012 + 4.7, s * 0.011) * 70 * far * far;
  const ripple = (noise2(x * 0.22, s * 0.22) - 0.5) * 0.7 * smooth(4, 20, d);
  const bank = Math.max(0.35, hills * smooth(2, 14, d) + 0.5 + mount + ripple);
  return lerp(py, bank, side);
}

// --------------------------------------------------------------------------
// GLSL shared bits
// --------------------------------------------------------------------------
const NOISE_GLSL = /* glsl */`
  float hash21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
  float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + vec2(1.0, 0.0)), f.x), mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), f.x), f.y);
  }
  float fbm3(vec2 p) { return vnoise(p) * 0.55 + vnoise(p * 2.07) * 0.3 + vnoise(p * 4.1) * 0.15; }
`;

const SKY_FN = /* glsl */`
  uniform vec3 uTop, uMid, uLow, uSunCol, uSunDir;
  vec3 skyBase(vec3 d) {
    float h = d.y;
    vec3 col = mix(uLow, uMid, smoothstep(-0.05, 0.38, h));
    col = mix(col, uTop, smoothstep(0.28, 0.95, h));
    col = mix(col, uLow * 0.92, smoothstep(0.0, -0.3, h));
    float sd = max(dot(d, uSunDir), 0.0);
    col += uSunCol * (pow(sd, 1200.0) * 5.0 + pow(sd, 60.0) * 0.4 + pow(sd, 7.0) * 0.2);
    return col;
  }
`;

// --------------------------------------------------------------------------
export class World {
  constructor(gfx, particles) {
    this.gfx = gfx; this.scene = gfx.scene; this.particles = particles;
    this.t = 0;
    this.levelIndex = -1;
    this.sunDir = new THREE.Vector3(0.28, 0.34, -0.9).normalize();

    // shared palette colours (mutated in place each frame → every material sees them)
    this.pal = {
      top: new THREE.Color(), mid: new THREE.Color(), low: new THREE.Color(), fog: new THREE.Color(),
      sun: new THREE.Color(), grass: new THREE.Color(), grass2: new THREE.Color()
    };
    this.U = {
      uTop: { value: this.pal.top }, uMid: { value: this.pal.mid }, uLow: { value: this.pal.low },
      uSunCol: { value: this.pal.sun }, uSunDir: { value: this.sunDir },
      uStars: { value: 0 }, uTime: timeU
    };
    this.pathTint = new THREE.Color(0xff9ad5);  // glow colour of the runway (follows player tint)
    this.pathTintTarget = new THREE.Color(0xff9ad5);

    this._lights();
    this._sky();
    this._buildTextures();
    this._pathMaterials();
    this._terrainMaterial();
    this._water();
    this._sceneryAssets();
    this.chunks = [];
    for (let i = 0; i < CHUNK_COUNT; i++) this.chunks.push(this._makeChunk());
    this.setProgress(0, 0);
    this.regenEnv();
    this.rebuildAll(0);
    this._ambient();
  }

  // ---- lights & fog -------------------------------------------------------
  _lights() {
    const s = this.scene;
    this.hemi = new THREE.HemisphereLight(0xcfe4ff, 0xffc7e8, 1.05);
    s.add(this.hemi);
    this.sunLight = new THREE.DirectionalLight(0xfff0d8, 2.6);
    this.sunLight.position.copy(this.sunDir).multiplyScalar(60);
    const c = this.sunLight.shadow.camera;
    c.left = -16; c.right = 16; c.top = 16; c.bottom = -16; c.near = 1; c.far = 140;
    this.sunLight.shadow.bias = -0.0004; this.sunLight.shadow.normalBias = 0.03;
    s.add(this.sunLight); s.add(this.sunLight.target);
    s.fog = new THREE.FogExp2(0xffd9e8, 0.0075);
  }

  // ---- sky ------------------------------------------------------------------
  _sky() {
    const mat = new THREE.ShaderMaterial({
      uniforms: this.U,
      vertexShader: `varying vec3 vDir; void main(){ vDir = position; vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }`,
      fragmentShader: /* glsl */`
        precision highp float;
        uniform float uTime, uStars;
        varying vec3 vDir;
        ${SKY_FN}
        ${NOISE_GLSL}
        void main() {
          vec3 d = normalize(vDir);
          vec3 col = skyBase(d);
          float h = d.y;
          if (h > 0.0) {
            vec2 p = d.xz / (h + 0.28) * 1.4 + vec2(uTime * 0.012, 0.0);
            float n = fbm3(p * 1.6);
            float cl = smoothstep(0.52, 0.82, n) * smoothstep(0.0, 0.22, h);
            float sunSide = pow(max(dot(d, uSunDir), 0.0), 3.0);
            vec3 cc = mix(uMid * 1.25 + 0.25, uSunCol * 1.5 + 0.3, sunSide);
            col = mix(col, cc, cl * 0.72);
            // stars (visible in dark palettes)
            vec3 g = floor(d * 220.0);
            float st = step(0.9965, fract(sin(dot(g, vec3(12.9898, 78.233, 37.719))) * 43758.5453));
            float tw = 0.6 + 0.4 * sin(uTime * 2.0 + dot(g, vec3(1.0)));
            col += st * tw * uStars * smoothstep(0.08, 0.5, h) * (1.0 - cl) * 2.2;
          }
          gl_FragColor = vec4(col, 1.0);
        }`,
      side: THREE.BackSide, depthWrite: false, depthTest: false, fog: false
    });
    this.skyMat = mat;
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(300, 40, 20), mat);
    this.sky.frustumCulled = false; this.sky.renderOrder = -10;
    this.scene.add(this.sky);
  }

  regenEnv() {
    // bake the current sky into a PMREM so glossy materials reflect it
    const pm = this.pmrem || (this.pmrem = new THREE.PMREMGenerator(this.gfx.renderer));
    const envScene = new THREE.Scene();
    const m = new THREE.Mesh(new THREE.SphereGeometry(50, 32, 16), this.skyMat);
    envScene.add(m);
    if (this.envRT) this.envRT.dispose();
    // bake WITHOUT the sun disc so the glossy runway never shows a blinding streak
    const sun = this.pal.sun, keep = sun.clone();
    sun.setRGB(0, 0, 0);
    this.envRT = pm.fromScene(envScene, 0.03, 0.1, 200);
    sun.copy(keep);
    this.scene.environment = this.envRT.texture;
    this.scene.environmentIntensity = 0.6;
    m.geometry.dispose();
  }

  // ---- procedural textures ---------------------------------------------------
  _buildTextures() {
    // Runway colour (pearl tiles) and emissive (glowing inlay) maps. Tile = 256 px = one repeat.
    const S = 512;
    const c1 = document.createElement('canvas'); c1.width = c1.height = S;
    const g = c1.getContext('2d');
    const grad = g.createLinearGradient(0, 0, S, 0);
    grad.addColorStop(0, '#9d86e8'); grad.addColorStop(0.5, '#c4aef7'); grad.addColorStop(1, '#8fb4f0');
    g.fillStyle = grad; g.fillRect(0, 0, S, S);
    // subtle marble veins
    g.globalAlpha = 0.18;
    for (let i = 0; i < 26; i++) {
      g.strokeStyle = i % 2 ? '#b99cff' : '#ffa8d8';
      g.lineWidth = 1 + Math.random() * 2;
      g.beginPath();
      let x = Math.random() * S, y = Math.random() * S;
      g.moveTo(x, y);
      for (let j = 0; j < 6; j++) { x += (Math.random() - 0.5) * 140; y += (Math.random() - 0.5) * 140; g.lineTo(x, y); }
      g.stroke();
    }
    g.globalAlpha = 1;
    // tile seams
    g.strokeStyle = 'rgba(160,130,220,0.35)'; g.lineWidth = 3;
    g.strokeRect(1.5, 1.5, S - 3, S - 3);
    this.pathMap = new THREE.CanvasTexture(c1);

    const c2 = document.createElement('canvas'); c2.width = c2.height = S;
    const e = c2.getContext('2d');
    e.fillStyle = '#000'; e.fillRect(0, 0, S, S);
    // glowing edge lines (left/right of the runway = u 0.03 and 0.97)
    const line = (x, w, a) => { e.fillStyle = `rgba(255,255,255,${a})`; e.fillRect(x - w / 2, 0, w, S); };
    line(S * 0.035, 9, 1); line(S * 0.965, 9, 1);
    line(S * 0.075, 3, 0.55); line(S * 0.925, 3, 0.55);
    // centre diamond rune + dashes
    e.strokeStyle = 'rgba(255,255,255,0.95)'; e.lineWidth = 6; e.lineJoin = 'round';
    const cx = S / 2, cy = S / 2;
    e.beginPath(); e.moveTo(cx, cy - 120); e.lineTo(cx + 62, cy); e.lineTo(cx, cy + 120); e.lineTo(cx - 62, cy); e.closePath(); e.stroke();
    e.lineWidth = 3; e.globalAlpha = 0.7;
    e.beginPath(); e.moveTo(cx, cy - 70); e.lineTo(cx + 34, cy); e.lineTo(cx, cy + 70); e.lineTo(cx - 34, cy); e.closePath(); e.stroke();
    e.globalAlpha = 1;
    // lane guide dots
    for (const lx of [0.25, 0.75]) for (let i = 0; i < 8; i++) {
      e.beginPath(); e.arc(S * lx, S * (i + 0.5) / 8, 5, 0, Math.PI * 2); e.fillStyle = 'rgba(255,255,255,0.8)'; e.fill();
    }
    // little butterflies in the corners
    const bf = (x, y, r) => {
      e.fillStyle = 'rgba(255,255,255,0.9)';
      e.beginPath(); e.ellipse(x - r, y - r * 0.4, r, r * 0.8, -0.5, 0, 7); e.fill();
      e.beginPath(); e.ellipse(x + r, y - r * 0.4, r, r * 0.8, 0.5, 0, 7); e.fill();
      e.beginPath(); e.ellipse(x - r * 0.7, y + r * 0.6, r * 0.6, r * 0.5, 0.4, 0, 7); e.fill();
      e.beginPath(); e.ellipse(x + r * 0.7, y + r * 0.6, r * 0.6, r * 0.5, -0.4, 0, 7); e.fill();
    };
    bf(S * 0.5, S * 0.06, 12); bf(S * 0.5, S * 0.94, 12);
    this.pathEmissive = new THREE.CanvasTexture(c2);

    for (const t of [this.pathMap, this.pathEmissive]) {
      t.wrapS = THREE.ClampToEdgeWrapping; t.wrapT = THREE.RepeatWrapping;
      t.colorSpace = THREE.SRGBColorSpace;
      t.anisotropy = Math.min(8, this.gfx.renderer.capabilities.getMaxAnisotropy());
      t.generateMipmaps = true;
    }
  }

  _pathMaterials() {
    this.pathMat = new THREE.MeshPhysicalMaterial({
      map: this.pathMap, color: 0xffffff, roughness: 0.5, metalness: 0.0, specularIntensity: 0.22,
      clearcoat: 0.12, clearcoatRoughness: 0.4,
      emissive: this.pathTint, emissiveMap: this.pathEmissive, emissiveIntensity: 1.8,
      envMapIntensity: 0.3
    });
    this.pathMat.userData.shared = true;
  }

  // ---- terrain shader ----------------------------------------------------------
  _terrainMaterial() {
    const pal = this.pal;
    this.terrainMat = new THREE.ShaderMaterial({
      uniforms: {
        ...fogU, ...this.U,
        uGrass: { value: pal.grass }, uGrass2: { value: pal.grass2 },
        uWL: { value: WATER_LEVEL }, uAmbient: { value: new THREE.Color(0.55, 0.55, 0.7) },
        uPathTint: { value: this.pathTint }
      },
      vertexShader: /* glsl */`
        varying vec3 vN; varying vec3 vW; varying float vDist;
        void main() {
          vec4 w = modelMatrix * vec4(position, 1.0);
          vW = w.xyz; vN = normalize(mat3(modelMatrix) * normal);
          vec4 mv = viewMatrix * w; vDist = length(mv.xyz);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: /* glsl */`
        precision highp float;
        uniform vec3 uGrass, uGrass2, uAmbient, uSunCol, uSunDir, uPathTint, uLow;
        uniform float uWL, uTime;
        varying vec3 vN; varying vec3 vW; varying float vDist;
        ${NOISE_GLSL}
        ${FOG_GLSL}
        void main() {
          vec3 n = normalize(vN);
          vec2 p = vW.xz;
          float pat = fbm3(p * 0.045);
          vec3 base = mix(uGrass, uGrass2, smoothstep(0.38, 0.72, pat));
          // soft blades / mottling
          base *= 0.9 + 0.2 * vnoise(p * 1.7);
          // meadow flowers
          vec2 cell = floor(p * 1.1);
          float fh = hash21(cell);
          vec2 cp = fract(p * 1.1) - 0.5;
          float fl = step(0.965, fh) * (1.0 - smoothstep(0.1, 0.2, length(cp)));
          vec3 fcol = 0.55 + 0.45 * cos(6.2831 * (fh * 7.0 + vec3(0.0, 0.33, 0.67)));
          base = mix(base, fcol * 1.2, fl);
          // steep slopes → lilac stone
          float slope = 1.0 - n.y;
          base = mix(base, mix(uGrass2, vec3(0.62, 0.55, 0.78), 0.55) * 0.9, smoothstep(0.32, 0.65, slope));
          // altitude haze (mountains lighten toward the sky)
          base = mix(base, uLow, smoothstep(14.0, 70.0, vW.y) * 0.5);
          float ndl = max(dot(n, uSunDir), 0.0);
          float wrap = max(dot(n, uSunDir) * 0.5 + 0.5, 0.0);
          vec3 lit = base * (uAmbient + uSunCol * (ndl * 0.85 + wrap * 0.25));
          // runway glow spilling on to the grass
          float edge = abs(vW.x);
          float pg = exp(-max(edge - 6.2, 0.0) * 0.55) * step(6.0, edge);
          lit += uPathTint * pg * 0.28 * smoothstep(0.0, 0.2, vW.y - uWL + 0.3);
          // underwater
          float depth = clamp((uWL - vW.y) / 3.2, 0.0, 1.0);
          if (vW.y < uWL + 0.15) {
            vec3 shallow = vec3(0.35, 0.95, 0.9), deep = vec3(0.04, 0.18, 0.5);
            vec3 wc = mix(shallow, deep, smoothstep(0.0, 1.0, depth)) * (0.55 + 0.45 * ndl);
            // caustics
            float c1 = sin(p.x * 1.3 + uTime * 1.2 + sin(p.y * 0.9 + uTime)) + sin(p.y * 1.6 - uTime * 1.4 + sin(p.x * 1.1));
            float caus = pow(clamp(1.0 - abs(c1) * 0.5, 0.0, 1.0), 6.0) * (1.0 - depth * 0.7);
            wc += caus * vec3(0.6, 1.0, 1.0) * 0.8;
            lit = mix(lit, wc, smoothstep(uWL + 0.15, uWL - 0.2, vW.y));
          }
          // shoreline foam
          float fo = 1.0 - smoothstep(0.0, 0.32, abs(vW.y - uWL));
          fo *= 0.55 + 0.45 * sin(vW.x * 3.0 + vW.z * 2.0 + uTime * 2.0);
          lit += fo * vec3(0.9, 1.0, 1.0) * 0.55;
          lit = applyFog(lit, vDist);
          gl_FragColor = vec4(lit, 1.0);
        }`,
      side: THREE.DoubleSide
    });
  }

  // ---- water ---------------------------------------------------------------------
  _water() {
    const mat = new THREE.ShaderMaterial({
      uniforms: {
        ...fogU, ...this.U,
        uCenter: { value: new THREE.Vector2() },
        uShallow: { value: new THREE.Color(0x3fe0e0) }, uDeep: { value: new THREE.Color(0x1b5cff) },
        uTint: { value: this.pathTint }
      },
      vertexShader: /* glsl */`
        varying vec2 vLocal; varying vec3 vView; varying float vDist;
        void main() {
          vLocal = position.xz;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          vView = -mv.xyz; vDist = length(mv.xyz);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: /* glsl */`
        precision highp float;
        uniform vec2 uCenter; uniform float uTime;
        uniform vec3 uShallow, uDeep, uTint;
        varying vec2 vLocal; varying vec3 vView; varying float vDist;
        ${SKY_FN}
        ${FOG_GLSL}
        const float K = 0.012271846; // 2*PI/512 → waves tile seamlessly while the plane follows the player
        vec2 wave(vec2 p, vec2 dir, float n, float spd, float amp) {
          float ph = dot(dir, p) * K * n + uTime * spd;
          return normalize(dir) * amp * cos(ph);
        }
        void main() {
          vec2 wp = vLocal + uCenter;
          vec2 g = vec2(0.0);
          g += wave(wp, vec2(1.0, 0.25), 37.0, 1.1, 0.10);
          g += wave(wp, vec2(-0.4, 1.0), 53.0, 1.4, 0.075);
          g += wave(wp, vec2(0.7, 0.7), 79.0, 1.9, 0.06);
          g += wave(wp, vec2(-0.9, 0.3), 131.0, 2.5, 0.045);
          g += wave(wp, vec2(0.2, -1.0), 197.0, 3.2, 0.035);
          vec3 N = normalize(vec3(-g.x, 1.0, -g.y));
          vec3 Vv = normalize(vView);
          vec3 Vw = Vv * mat3(viewMatrix);       // view-space → world-space direction
          float ndv = clamp(dot(N, Vw), 0.0, 1.0);
          float fres = 0.03 + 0.97 * pow(1.0 - ndv, 4.2);
          vec3 R = reflect(-Vw, N);
          R.y = abs(R.y);
          vec3 refl = skyBase(normalize(R));
          vec3 refr = mix(uShallow, uDeep, smoothstep(0.25, 0.95, 1.0 - ndv * 0.8));
          refr += uTint * 0.08;
          vec3 col = mix(refr, refl, clamp(fres, 0.0, 1.0));
          // sun glitter + sparkle glints
          float sp = pow(max(dot(R, uSunDir), 0.0), 260.0);
          col += uSunCol * sp * 3.5;
          float glint = pow(max(0.0, sin(wp.x * 2.2 + uTime * 1.7) * sin(wp.y * 2.0 - uTime * 1.3)), 24.0) * 0.8;
          col += glint * (0.4 + fres);
          float a = clamp(0.5 + fres * 0.45 + sp, 0.0, 0.97);
          col = applyFog(col, vDist);
          gl_FragColor = vec4(col, a);
        }`,
      transparent: true, depthWrite: false
    });
    this.waterMat = mat;
    const g = new THREE.PlaneGeometry(900, 900, 1, 1); g.rotateX(-Math.PI / 2);
    this.water = new THREE.Mesh(g, mat);
    this.water.position.y = WATER_LEVEL;
    this.water.frustumCulled = false; this.water.renderOrder = 2;
    this.scene.add(this.water);
  }

  // ---- scenery assets -----------------------------------------------------------
  _sceneryAssets() {
    // blossom tree
    const trunkG = new THREE.CylinderGeometry(0.16, 0.3, 3.0, 7); trunkG.translate(0, 1.5, 0);
    const bl = [];
    for (const [x, y, z, r] of [[0, 0, 0, 1.25], [0.9, -0.25, 0.3, 0.95], [-0.85, -0.15, -0.4, 1.0], [0.1, 0.75, -0.2, 0.9]]) {
      const s = new THREE.IcosahedronGeometry(r, 2); s.translate(x, y, z); bl.push(s);
    }
    const canopyG = merge(bl); canopyG.translate(0, 3.6, 0);
    this.treeAssets = {
      trunk: trunkG, canopy: canopyG,
      trunkMat: new THREE.MeshStandardMaterial({ color: 0xb48a8a, roughness: 0.85 }),
      canopyMat: new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.55, emissive: 0x331122, emissiveIntensity: 0.25 })
    };
    this.crystalG = crystalGeometry(5, 1.0, 0.9, 7);
    this.crystalMat = glowMaterial({ intensity: 1.25, rim: 1.4, rimPower: 2.2, useVertexColor: true, shade: 0.5 });
    const head = new THREE.SphereGeometry(0.22, 8, 6); head.translate(0, 0.6, 0); paint(head, 0xffffff);
    const stem = new THREE.ConeGeometry(0.06, 0.6, 5); stem.translate(0, 0.3, 0); paint(stem, 0x6a8f74);
    const flowerG = merge([head, stem]);
    this.flowerG = flowerG;
    this.flowerMat = glowMaterial({ intensity: 1.9, rim: 0.8, useVertexColor: true, pulse: 0.15 });
    const poleG = new THREE.CylinderGeometry(0.06, 0.1, 3.2, 6); poleG.translate(0, 1.6, 0);
    this.poleG = poleG; this.poleMat = new THREE.MeshStandardMaterial({ color: 0xfff0f8, roughness: 0.3, metalness: 0.2 });
    this.orbG = new THREE.IcosahedronGeometry(0.42, 2);
    this.orbMat = glowMaterial({ intensity: 2.6, rim: 1.5, pulse: 0.2 });
    const puff = [];
    for (const [x, y, z, r] of [[0, 0, 0, 5], [4.5, -0.6, 1, 3.8], [-4.2, -0.4, -1, 4], [8, -1, 0, 2.8], [-7.6, -1.2, 1, 2.6]]) { const s = new THREE.IcosahedronGeometry(r, 2); s.translate(x, y, z); puff.push(s); }
    this.cloudG = merge(puff); this.cloudG.scale(1, 0.55, 1);
    this.cloudMat = glowMaterial({ intensity: 1.15, rim: 0.6, shade: 1.0, opacity: 0.88 });
    // floating island
    const rock = new THREE.ConeGeometry(5.2, 9, 9, 3); rock.rotateX(Math.PI); rock.translate(0, -4.5, 0);
    const rp = rock.attributes.position;
    for (let i = 0; i < rp.count; i++) {
      const x = rp.getX(i), y = rp.getY(i), z = rp.getZ(i);
      const k = 1 + (noise2(x * 0.6 + 3, z * 0.6 + y * 0.4) - 0.5) * 0.55;
      rp.setXYZ(i, x * k, y, z * k);
    }
    rock.computeVertexNormals();
    this.islandRockG = rock;
    this.islandRockMat = new THREE.MeshStandardMaterial({ color: 0xb9a6d6, roughness: 0.9, flatShading: true });
    const top = new THREE.SphereGeometry(5.3, 20, 8, 0, Math.PI * 2, 0, Math.PI / 2); top.scale(1, 0.16, 1);
    this.islandTopG = top;
    this.islandTopMat = new THREE.MeshStandardMaterial({ color: 0x9ff0b4, roughness: 0.8, emissive: 0x1a4a30, emissiveIntensity: 0.3 });
  }

  _inst(geo, mat, max) {
    const m = new THREE.InstancedMesh(geo, mat, max);
    m.count = 0; m.frustumCulled = false;
    m.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    return m;
  }

  _makeChunk() {
    const chunk = { index: -999, group: new THREE.Group() };
    // terrain grid (dense near the path, sparse far away)
    const ds = [0, 1.5, 3, 4.5, 6.2, 7.4, 8.6, 10, 12, 14.5, 17.5, 21, 25, 30, 36, 43, 52, 62, 75, 90, 110, 135, 165];
    const xs = [];
    for (let i = ds.length - 1; i > 0; i--) xs.push(-ds[i]);
    for (let i = 0; i < ds.length; i++) xs.push(ds[i]);
    chunk.xs = xs;
    const rows = 40;
    chunk.rows = rows;
    const cols = xs.length;
    const vCount = cols * (rows + 1);
    const pos = new Float32Array(vCount * 3);
    const nor = new Float32Array(vCount * 3);
    const idx = [];
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols - 1; c++) {
      const a = r * cols + c, b = a + 1, d = a + cols, e = d + 1;
      idx.push(a, b, d, b, e, d);
    }
    const tg = new THREE.BufferGeometry();
    tg.setAttribute('position', new THREE.BufferAttribute(pos, 3).setUsage(THREE.DynamicDrawUsage));
    tg.setAttribute('normal', new THREE.BufferAttribute(nor, 3).setUsage(THREE.DynamicDrawUsage));
    tg.setIndex(idx);
    tg.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 10, -CHUNK_LEN / 2), 260);
    chunk.terrain = new THREE.Mesh(tg, this.terrainMat);
    chunk.terrain.frustumCulled = false;
    chunk.group.add(chunk.terrain);

    // runway ribbon
    const pc = 6, pr = 40;
    const ppos = new Float32Array((pc + 1) * (pr + 1) * 3);
    const puv = new Float32Array((pc + 1) * (pr + 1) * 2);
    const pidx = [];
    for (let r = 0; r < pr; r++) for (let c = 0; c < pc; c++) {
      const a = r * (pc + 1) + c, b = a + 1, d = a + pc + 1, e = d + 1;
      pidx.push(a, b, d, b, e, d);
    }
    const pg = new THREE.BufferGeometry();
    pg.setAttribute('position', new THREE.BufferAttribute(ppos, 3).setUsage(THREE.DynamicDrawUsage));
    pg.setAttribute('uv', new THREE.BufferAttribute(puv, 2).setUsage(THREE.DynamicDrawUsage));
    pg.setIndex(pidx);
    pg.computeVertexNormals();
    pg.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 0, -CHUNK_LEN / 2), 80);
    chunk.path = new THREE.Mesh(pg, this.pathMat);
    chunk.path.receiveShadow = true; chunk.path.frustumCulled = false;
    chunk.group.add(chunk.path);

    const A = this.treeAssets;
    chunk.trunks = this._inst(A.trunk, A.trunkMat, 40);
    chunk.canopies = this._inst(A.canopy, A.canopyMat, 40);
    chunk.crystals = this._inst(this.crystalG, this.crystalMat, 24);
    chunk.flowers = this._inst(this.flowerG, this.flowerMat, 90);
    chunk.poles = this._inst(this.poleG, this.poleMat, 12);
    chunk.lamps = this._inst(this.orbG, this.orbMat, 12);
    chunk.clouds = this._inst(this.cloudG, this.cloudMat, 8);
    chunk.rocks = this._inst(this.islandRockG, this.islandRockMat, 3);
    chunk.tops = this._inst(this.islandTopG, this.islandTopMat, 3);
    for (const k of ['trunks', 'canopies', 'crystals', 'flowers', 'poles', 'lamps', 'clouds', 'rocks', 'tops']) {
      chunk[k].instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(chunk[k].instanceMatrix.count * 3), 3);
      chunk.group.add(chunk[k]);
    }
    chunk.clouds.renderOrder = 3;
    this.scene.add(chunk.group);
    return chunk;
  }

  // Fill a chunk with terrain + scenery for chunk index k (covers s ∈ [k*L, (k+1)*L)).
  buildChunk(chunk, k) {
    chunk.index = k;
    const s0 = k * CHUNK_LEN;
    chunk.group.position.set(0, 0, -s0);
    const { xs, rows } = chunk;
    const cols = xs.length;
    const pos = chunk.terrain.geometry.attributes.position.array;
    const nor = chunk.terrain.geometry.attributes.normal.array;
    const step = CHUNK_LEN / rows;
    const e = 0.6;
    for (let r = 0; r <= rows; r++) {
      const ds = r * step, s = s0 + ds;
      for (let c = 0; c < cols; c++) {
        const x = xs[c];
        const i = (r * cols + c) * 3;
        const y = terrainY(x, s);
        pos[i] = x; pos[i + 1] = y; pos[i + 2] = -ds;
        const hx = terrainY(x + e, s) - terrainY(x - e, s);
        const hz = terrainY(x, s + e) - terrainY(x, s - e);
        // dz in world is -ds, so slope along world z = -(dh/ds)
        let nx = -hx / (2 * e), nz = hz / (2 * e), ny = 1;
        const l = Math.hypot(nx, ny, nz); nor[i] = nx / l; nor[i + 1] = ny / l; nor[i + 2] = nz / l;
      }
    }
    chunk.terrain.geometry.attributes.position.needsUpdate = true;
    chunk.terrain.geometry.attributes.normal.needsUpdate = true;

    // runway
    const pc = 6, pr = 40;
    const pp = chunk.path.geometry.attributes.position.array;
    const uv = chunk.path.geometry.attributes.uv.array;
    const hw = PATH_HALF_WIDTH + 0.45;
    for (let r = 0; r <= pr; r++) {
      const ds = (r / pr) * CHUNK_LEN, s = s0 + ds;
      const y = pathY(s) + 0.03;
      for (let c = 0; c <= pc; c++) {
        const i = r * (pc + 1) + c;
        const u = c / pc;
        pp[i * 3] = (u * 2 - 1) * hw; pp[i * 3 + 1] = y; pp[i * 3 + 2] = -ds;
        uv[i * 2] = u; uv[i * 2 + 1] = s / 12;
      }
    }
    chunk.path.geometry.attributes.position.needsUpdate = true;
    chunk.path.geometry.attributes.uv.needsUpdate = true;
    chunk.path.geometry.computeVertexNormals();

    this._scatter(chunk, k, s0);
  }

  _scatter(chunk, k, s0) {
    const R = rng(k * 7919 + 101);
    const q = this.gfx.q.scenery;
    const TREE = [0xffa6d1, 0xd9b3ff, 0xa6f2d0, 0xffd1a6, 0xa6d4ff, 0xfff0a6];
    const tmp = new THREE.Color();
    let nT = 0, nC = 0, nF = 0, nP = 0, nL = 0, nCl = 0, nI = 0;
    const colorAt = (mesh, i, hex, mul = 1) => { tmp.set(hex); setInstanceColor(mesh, i, tmp.r * mul, tmp.g * mul, tmp.b * mul); };

    // trees
    const treeCount = Math.floor(11 * q);
    for (let side = -1; side <= 1; side += 2) {
      for (let i = 0; i < treeCount; i++) {
        const dist = 11 + Math.pow(R(), 1.7) * 62;
        const x = side * dist, ds = R() * CHUNK_LEN, s = s0 + ds;
        const y = terrainY(x, s);
        const sc = 1.1 + R() * 1.9 + dist * 0.025;
        if (y < WATER_LEVEL + 0.5 || nT >= 40) { R(); R(); continue; }
        const ry = R() * 6.28;
        setInstance(chunk.trunks, nT, x, y - 0.1, -ds, sc, sc, sc, 0, ry, 0);
        setInstance(chunk.canopies, nT, x, y - 0.1, -ds, sc, sc * (0.85 + R() * 0.3), sc, 0, ry, 0);
        colorAt(chunk.trunks, nT, 0xffffff, 1);
        colorAt(chunk.canopies, nT, TREE[Math.floor(R() * TREE.length)], 1);
        nT++;
      }
    }
    // crystals + flowers near the path edge
    for (let side = -1; side <= 1; side += 2) {
      const cc = Math.floor(3 * q) + 1;
      for (let i = 0; i < cc; i++) {
        const dist = 8.5 + R() * 24;
        const x = side * dist, ds = R() * CHUNK_LEN, s = s0 + ds, y = terrainY(x, s);
        if (y < WATER_LEVEL + 0.4 || nC >= 24) continue;
        const sc = 0.7 + R() * 1.5 + (dist > 18 ? 1.3 : 0);
        setInstance(chunk.crystals, nC, x, y - 0.1, -ds, sc, sc * (0.9 + R() * 0.7), sc, 0, R() * 6.28, (R() - 0.5) * 0.15);
        const col = COLORS[Math.floor(R() * COLORS.length)];
        colorAt(chunk.crystals, nC, col.hex, 1.0);
        nC++;
      }
      const fc = Math.floor(22 * q);
      for (let i = 0; i < fc; i++) {
        const dist = 7.0 + Math.pow(R(), 1.3) * 14;
        const x = side * dist, ds = R() * CHUNK_LEN, s = s0 + ds, y = terrainY(x, s);
        if (y < WATER_LEVEL + 0.35 || nF >= 90) continue;
        const sc = 0.8 + R() * 1.3;
        setInstance(chunk.flowers, nF, x, y, -ds, sc, sc, sc, (R() - 0.5) * 0.3, 0, (R() - 0.5) * 0.3);
        colorAt(chunk.flowers, nF, COLORS[Math.floor(R() * COLORS.length)].hex, 1);
        nF++;
      }
    }
    // lantern posts along the runway (dry sections only)
    for (let ds = 8; ds < CHUNK_LEN; ds += 20) {
      const s = s0 + ds;
      if (waterFactor(s) > 0.02) continue;
      for (let side = -1; side <= 1; side += 2) {
        if (nP >= 12) break;
        const x = side * (PATH_HALF_WIDTH + 1.0), y = pathY(s);
        setInstance(chunk.poles, nP, x, y, -ds, 1, 1, 1);
        colorAt(chunk.poles, nP, 0xffffff);
        setInstance(chunk.lamps, nL, x, y + 3.4, -ds, 1, 1, 1);
        const col = COLORS[(((Math.floor(s / 20) + (side > 0 ? 3 : 0)) % COLORS.length) + COLORS.length) % COLORS.length];
        colorAt(chunk.lamps, nL, col.hex, 1.0);
        nP++; nL++;
      }
    }
    // clouds
    const cl = Math.floor(2 + R() * 3 * q);
    for (let i = 0; i < cl && nCl < 8; i++) {
      const side = R() < 0.5 ? -1 : 1;
      const x = side * (35 + R() * 110), ds = R() * CHUNK_LEN;
      const y = 40 + R() * 40;
      const sc = 1.4 + R() * 2.2;
      setInstance(chunk.clouds, nCl, x, y, -ds, sc, sc, sc, 0, R() * 6.28, 0);
      colorAt(chunk.clouds, nCl, 0xfff2fb, 1);
      nCl++;
    }
    // floating islands
    const isl = R() < 0.7 ? 1 : 0;
    for (let i = 0; i < isl && nI < 3; i++) {
      const side = R() < 0.5 ? -1 : 1;
      const x = side * (26 + R() * 38), ds = R() * CHUNK_LEN, y = 16 + R() * 22;
      const sc = 0.8 + R() * 1.1;
      setInstance(chunk.rocks, nI, x, y, -ds, sc, sc, sc, 0, R() * 6.28, 0);
      setInstance(chunk.tops, nI, x, y, -ds, sc, sc, sc, 0, 0, 0);
      colorAt(chunk.rocks, nI, 0xffffff); colorAt(chunk.tops, nI, 0xffffff);
      if (nT < 40) {
        const ts = sc * 1.4;
        setInstance(chunk.trunks, nT, x, y + 0.2, -ds, ts, ts, ts, 0, 0, 0);
        setInstance(chunk.canopies, nT, x, y + 0.2, -ds, ts, ts, ts, 0, 0, 0);
        colorAt(chunk.trunks, nT, 0xffffff); colorAt(chunk.canopies, nT, TREE[Math.floor(R() * TREE.length)]);
        nT++;
      }
      nI++;
    }

    const set = (m, n) => { m.count = n; m.instanceMatrix.needsUpdate = true; if (m.instanceColor) m.instanceColor.needsUpdate = true; };
    set(chunk.trunks, nT); set(chunk.canopies, nT); set(chunk.crystals, nC); set(chunk.flowers, nF);
    set(chunk.poles, nP); set(chunk.lamps, nL); set(chunk.clouds, nCl); set(chunk.rocks, nI); set(chunk.tops, nI);
  }

  rebuildAll(s) {
    const first = Math.floor((s - CHUNK_LEN * CHUNK_BEHIND) / CHUNK_LEN);
    this.chunks.forEach((c, i) => this.buildChunk(c, first + i));
    this.firstChunk = first;
  }

  // Called when the quality tier changes (scenery density).
  refreshScenery() {
    this.chunks.forEach((c) => this.buildChunk(c, c.index));
  }

  // ---- ambient fireflies / pollen around the camera -----------------------------
  _ambient() { this._ambAcc = 0; }

  // ---- palette ---------------------------------------------------------------------
  setProgress(s, dt) {
    const lf = Math.max(0, s) / LEVEL_LENGTH;
    const i = Math.floor(lf), frac = lf - i;
    const a = LEVELS[i % LEVELS.length], b = LEVELS[(i + 1) % LEVELS.length];
    const t = smooth(0.8, 1.0, frac);
    const P = this.pal;
    const tc = this._tc || (this._tc = new THREE.Color()), white = this._white || (this._white = new THREE.Color(0xffffff));
    const mix = (out, ka) => out.set(a[ka]).lerp(tc.set(b[ka]), t);
    mix(P.top, 'top'); mix(P.mid, 'mid'); mix(P.low, 'low'); mix(P.fog, 'fog');
    mix(P.sun, 'sun'); mix(P.grass, 'grass'); mix(P.grass2, 'grass2');
    // star visibility from palette darkness
    const dark = 1 - clamp((P.top.r + P.top.g + P.top.b) / 1.2, 0, 1);
    this.U.uStars.value = smooth(0.35, 0.85, dark);
    const sc = this.scene;
    sc.fog.color.copy(P.fog);
    fogU.uFogColor.value.copy(P.fog);
    const dens = 0.0058 + 0.0014 * (1 - t);
    sc.fog.density = dens; fogU.uFogDensity.value = dens;
    this.hemi.color.copy(P.mid).lerp(white, 0.55);
    this.hemi.groundColor.copy(P.grass2).multiplyScalar(0.75);
    this.hemi.intensity = lerp(1.05, 0.8, dark);
    this.sunLight.color.copy(P.sun);
    this.sunLight.intensity = lerp(2.2, 1.3, dark);
    this.terrainMat.uniforms.uAmbient.value.copy(P.mid).lerp(white, 0.6).multiplyScalar(lerp(0.62, 0.4, dark));
    this.waterMat.uniforms.uShallow.value.copy(P.low).lerp(tc.set(0x3fe8e0), 0.6);
    this.waterMat.uniforms.uDeep.value.copy(P.top).lerp(tc.set(0x1860ff), 0.5).multiplyScalar(0.8);
    this.gfx.renderer.setClearColor(P.fog, 1);
    this.darkness = dark;
    const level = i;
    if (level !== this.levelIndex) { this.levelIndex = level; this._envDirty = 0.5; }
    if (this._envDirty > 0) { this._envDirty -= dt; if (this._envDirty <= 0) this.regenEnv(); }
  }

  // ---- per-frame update -------------------------------------------------------------
  update(dt, time, s, playerX, camera) {
    this.t = time; timeU.value = time;
    this.pathTint.lerp(this.pathTintTarget, 1 - Math.exp(-4 * dt));
    this.pathMat.emissive.copy(this.pathTint);
    this.pathMat.emissiveIntensity = 1.5 + Math.sin(time * 2.2) * 0.25;
    this.setProgress(s, dt);

    // stream chunks
    const first = Math.floor((s - CHUNK_LEN * CHUNK_BEHIND) / CHUNK_LEN);
    if (first !== this.firstChunk) {
      const lo = first, hi = first + CHUNK_COUNT - 1;
      const have = new Set(this.chunks.map((c) => c.index));
      const free = this.chunks.filter((c) => c.index < lo || c.index > hi);
      for (let k = lo; k <= hi; k++) {
        if (!have.has(k)) { const c = free.pop(); if (c) this.buildChunk(c, k); }
      }
      this.firstChunk = first;
    }

    // sky follows the camera; water follows the player on a snapped grid
    this.sky.position.copy(camera.position);
    const snap = 64;
    const px = Math.round(camera.position.x / snap) * snap, pz = Math.round(camera.position.z / snap) * snap;
    this.water.position.set(px, WATER_LEVEL, pz);
    const mod = (v) => ((v % 512) + 512) % 512;
    this.waterMat.uniforms.uCenter.value.set(mod(px), mod(pz));

    // sun light follows the player (shadow frustum)
    const L = this.sunLight;
    L.target.position.set(playerX, 0, camera.position.z - 12);
    L.position.copy(L.target.position).addScaledVector(this.sunDir, 60);
    L.target.updateMatrixWorld();

    // ambient pollen / fireflies
    this._ambAcc += dt * 26;
    while (this._ambAcc >= 1) {
      this._ambAcc -= 1;
      const x = camera.position.x + (Math.random() - 0.5) * 40;
      const y = 0.5 + Math.random() * 9;
      const z = camera.position.z - 6 - Math.random() * 70;
      const c = this.pal.sun;
      this.particles.emit(x, y, z, (Math.random() - 0.5) * 0.6, 0.3 + Math.random() * 0.6, (Math.random() - 0.5) * 0.6,
        0.9 + c.r * 0.4, 0.8 + c.g * 0.3, 0.9 + c.b * 0.3, 0.14 + Math.random() * 0.2, 3 + Math.random() * 2.5, { star: Math.random() < 0.3 ? 1 : 0, alpha: 0.7 });
    }
  }
}
