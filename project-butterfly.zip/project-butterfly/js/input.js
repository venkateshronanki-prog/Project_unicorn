// Unified input: touch drag / mouse drag steering, hold-still-to-boost,
// on-screen BOOST button, keyboard, gamepad and optional gyro tilt.
import { clamp } from './util.js';

export class Input {
  constructor(canvas, boostButton) {
    this.canvas = canvas;
    this.steer = 0;           // -1..1 target horizontal position (relative drag)
    this.target = 0;          // final steering target after gyro mixing
    this.steerRate = 0;
    this.boostHeld = false;   // any boost source active
    this.pointerDown = false;
    this.sensitivity = 1.0;
    this.gyroOn = false;
    this.gyroSupported = typeof DeviceOrientationEvent !== 'undefined';
    this._gyroBase = null;
    this._gyroValue = 0;

    this._pointers = new Map();
    this._lastX = 0;
    this._lastMove = performance.now();
    this._holdMs = 320;       // hold still this long → boost
    this._btnHeld = false;
    this._keys = new Set();
    this._padBoost = false;
    this._padX = 0;
    this._pointerBoost = false;
    this._active = false;
    this.onFirstGesture = null;
    this.onPause = null;

    this._bind(boostButton);
  }

  _bind(btn) {
    const c = this.canvas;
    const opts = { passive: false };

    c.addEventListener('pointerdown', (e) => {
      if (this.onFirstGesture) this.onFirstGesture();
      c.setPointerCapture?.(e.pointerId);
      this._pointers.set(e.pointerId, { x: e.clientX, y: e.clientY, sx: e.clientX, t: performance.now() });
      this.pointerDown = true;
      this._lastX = e.clientX;
      this._lastMove = performance.now();
      e.preventDefault();
    }, opts);

    c.addEventListener('pointermove', (e) => {
      const p = this._pointers.get(e.pointerId);
      if (!p) return;
      const dx = e.clientX - p.x;
      p.x = e.clientX; p.y = e.clientY;
      const w = Math.max(320, window.innerWidth);
      // drag distance → steer. Full width ≈ full lane travel * 1.6 for fast response.
      this.steer = clamp(this.steer + (dx / w) * 3.2 * this.sensitivity, -1, 1);
      if (Math.abs(dx) > 1.2) this._lastMove = performance.now();
      e.preventDefault();
    }, opts);

    const up = (e) => {
      this._pointers.delete(e.pointerId);
      this.pointerDown = this._pointers.size > 0;
      if (!this.pointerDown) this._pointerBoost = false;
    };
    c.addEventListener('pointerup', up);
    c.addEventListener('pointercancel', up);
    c.addEventListener('lostpointercapture', up);
    c.addEventListener('contextmenu', (e) => e.preventDefault());
    // block iOS gestures (pinch / double-tap zoom / bounce)
    ['gesturestart', 'gesturechange', 'gestureend'].forEach((n) =>
      document.addEventListener(n, (e) => e.preventDefault(), opts));
    document.addEventListener('touchmove', (e) => { if (this._active) e.preventDefault(); }, opts);

    // BOOST button (hold)
    if (btn) {
      const on = (e) => { this._btnHeld = true; btn.classList.add('held'); if (this.onFirstGesture) this.onFirstGesture(); e.preventDefault(); e.stopPropagation(); };
      const off = (e) => { this._btnHeld = false; btn.classList.remove('held'); e.stopPropagation(); };
      btn.addEventListener('pointerdown', on, opts);
      btn.addEventListener('pointerup', off);
      btn.addEventListener('pointercancel', off);
      btn.addEventListener('pointerleave', off);
    }

    window.addEventListener('keydown', (e) => {
      if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space'].includes(e.code)) e.preventDefault();
      this._keys.add(e.code);
      if (e.code === 'Escape' || e.code === 'KeyP') this.onPause?.();
      if (this.onFirstGesture) this.onFirstGesture();
    });
    window.addEventListener('keyup', (e) => this._keys.delete(e.code));
    window.addEventListener('blur', () => { this._keys.clear(); this._btnHeld = false; this._pointers.clear(); this.pointerDown = false; });

    window.addEventListener('gamepadconnected', () => { this._hasPad = true; });
  }

  setActive(a) { this._active = a; if (!a) { this._pointers.clear(); this.pointerDown = false; } }

  // iOS 13+ needs an explicit permission request from a user gesture.
  async enableGyro() {
    if (!this.gyroSupported) return false;
    try {
      if (typeof DeviceOrientationEvent.requestPermission === 'function') {
        const r = await DeviceOrientationEvent.requestPermission();
        if (r !== 'granted') return false;
      }
    } catch (e) { return false; }
    this._gyroHandler = this._gyroHandler || ((e) => {
      if (e.gamma == null) return;
      // gamma = left/right tilt in portrait; in landscape use beta.
      const land = window.innerWidth > window.innerHeight;
      let v = land ? (e.beta || 0) : (e.gamma || 0);
      const ang = (screen.orientation && screen.orientation.angle) || window.orientation || 0;
      if (land && (ang === -90 || ang === 270)) v = -v;
      if (land && ang === 90) v = -v; // landscape-left sign fix
      if (this._gyroBase === null) this._gyroBase = v;
      this._gyroValue = clamp((v - this._gyroBase) / 22, -1, 1);
    });
    window.addEventListener('deviceorientation', this._gyroHandler);
    this.gyroOn = true;
    this._gyroBase = null;
    return true;
  }
  disableGyro() {
    if (this._gyroHandler) window.removeEventListener('deviceorientation', this._gyroHandler);
    this.gyroOn = false; this._gyroValue = 0; this._gyroBase = null;
  }
  recenter() { this._gyroBase = null; this.steer = 0; }

  // call each frame
  update(dt) {
    // keyboard
    let k = 0;
    if (this._keys.has('ArrowLeft') || this._keys.has('KeyA')) k -= 1;
    if (this._keys.has('ArrowRight') || this._keys.has('KeyD')) k += 1;
    // gamepad
    let padBoost = false, padX = 0;
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    for (const p of pads) {
      if (!p) continue;
      const ax = p.axes[0] || 0;
      if (Math.abs(ax) > 0.12) padX = ax;
      if (p.buttons[0]?.pressed || p.buttons[7]?.pressed || p.buttons[5]?.pressed) padBoost = true;
      if (p.buttons[9]?.pressed && !this._startDown) { this._startDown = true; this.onPause?.(); }
      if (!p.buttons[9]?.pressed) this._startDown = false;
      if (p.buttons[14]?.pressed) padX = -1;
      if (p.buttons[15]?.pressed) padX = 1;
    }
    const cont = clamp(k + padX, -1, 1);
    if (cont !== 0) this.steer = clamp(this.steer + cont * dt * 2.1, -1, 1);

    // gyro adds on top of the target
    let target = this.steer;
    if (this.gyroOn) target = clamp(this.steer * 0.25 + this._gyroValue, -1, 1);
    this.target = target;

    // hold-still boost
    const now = performance.now();
    if (this.pointerDown) {
      if (now - this._lastMove > this._holdMs) this._pointerBoost = true;
      else if (this._pointerBoost && now - this._lastMove < 80) this._pointerBoost = false; // moving again cancels
    }
    const keyBoost = this._keys.has('Space') || this._keys.has('ShiftLeft') || this._keys.has('ShiftRight') || this._keys.has('ArrowUp');
    this.boostHeld = this._pointerBoost || this._btnHeld || keyBoost || padBoost;
  }
}
