// Project Butterfly — game orchestration: boot, state machine, game loop, camera, scoring.
import * as THREE from '../vendor/three.bundle.js';
import {
  FIREBASE_CONFIG, VERSION, STEER_LIMIT, BASE_SPEED, SPEED_PER_LEVEL, MAX_SPEED, BOOST_MULT, BOOST_DRAIN, BOOST_REGEN,
  LEVEL_LENGTH, START_HEARTS, COMPANION_LIFETIME, FIRST_COMPANION_AT, COLORS, LEVELS, WATER_LEVEL, QUALITY
} from './config.js';
import { clamp, damp, lerp, $, isIOS, isTouch } from './util.js';
import { Gfx } from './gfx.js';
import { Particles, Ripples } from './fx.js';
import { AudioEngine } from './audio.js';
import { Haptics } from './haptics.js';
import { Input } from './input.js';
import { World, waterFactor } from './world.js';
import { Player } from './player.js';
import { Companion } from './companion.js';
import { Track } from './track.js';
import { UI } from './ui.js';
import { Save, cleanName } from './save.js';
import { Cloud } from './cloud.js';

const ui = new UI();
const nextFrame = () => new Promise((r) => requestAnimationFrame(() => r()));
const fail = (msg) => { ui.loading(1, msg); console.error(msg); };

async function boot() {
  ui.loading(0.08, 'Warming up WebGL…');
  await nextFrame();
  let gfx;
  try { gfx = new Gfx($('c')); } catch (e) { return fail('Sorry — this browser cannot run WebGL 2.'); }
  if (!gfx.renderer.capabilities.isWebGL2) return fail('Sorry — WebGL 2 is required.');
  ui.loading(0.2, 'Painting the sky…'); await nextFrame();

  const particles = new Particles(gfx.scene, 2600);
  const ripples = new Ripples(gfx.scene, 10);
  const audio = new AudioEngine();
  const haptics = new Haptics();
  const save = new Save();
  const cloud = new Cloud(FIREBASE_CONFIG);
  const input = new Input($('c'), $('boostBtn'));
  ui.loading(0.35, 'Growing the meadow…'); await nextFrame();
  const world = new World(gfx, particles);
  ui.loading(0.6, 'Waking the unicorn…'); await nextFrame();
  const player = new Player(gfx.scene, particles);
  const companion = new Companion(gfx.scene, particles);
  const track = new Track(gfx.scene, particles, audio, haptics);
  ui.loading(0.8, 'Polishing the rainbows…'); await nextFrame();

  // ------------------------------------------------------------------------------------
  // Settings / quality plumbing
  // ------------------------------------------------------------------------------------
  const applyQuality = () => {
    particles.limit = Math.ceil(particles.max * gfx.q.particles);
    gfx.setShadowSize(world.sunLight);
    player.setShadow(gfx.q.shadows > 0);
    const h = gfx.h * gfx.dpr;
    particles.setScale(h, gfx.camera.fov); track.setScale(h, gfx.camera.fov);
  };
  let sceneryTier = gfx.tier;
  gfx.onQuality = () => { applyQuality(); if (gfx.q.scenery !== QUALITY[sceneryTier].scenery) { sceneryTier = gfx.tier; world.refreshScenery(); } };
  gfx.onResize = () => applyQuality();
  applyQuality();

  const applySettings = () => {
    const s = save.data.settings;
    gfx.setQualityMode(s.quality === 'auto' ? 'auto' : +s.quality);
    audio.setVolumes(s.sfx, s.music);
    haptics.enabled = s.haptics;
    input.sensitivity = s.sens;
    ui.fpsVisible(s.fps);
    if (s.gyro && !input.gyroOn) input.enableGyro().then((ok) => { if (!ok) { save.setSettings({ gyro: false }); syncSettingsUI(); } });
    if (!s.gyro && input.gyroOn) input.disableGyro();
  };

  // ------------------------------------------------------------------------------------
  // Game state
  // ------------------------------------------------------------------------------------
  const G = {
    mode: 'menu', s: 0, x: 0, vx: 0, speed: 20, level: 0, hearts: START_HEARTS, score: 0, runOrbs: 0, colorCounts: {},
    maxHearts: 3, energy: 1, boosting: false, boostLock: false, boostK: 0, slow: 1, invuln: 0, shake: 0, punch: 0,
    chainColor: -1, chainStreak: 0, runTime: 0, startS: 0, w: 0, wSmooth: 0, formCd: 0, dead: false, deadT: 0,
    camBlend: 0, firstBuddy: false, tintAmt: 0.07, flashCol: new THREE.Color(0, 0, 0), rippleT: 0, saveT: 0, hitStreak: 0, menuS: 0
  };
  const camPos = new THREE.Vector3(0, 4, 10);
  const tmpV = new THREE.Vector3(), tmpC = new THREE.Color(), tmpV2 = new THREE.Vector3();
  const hexOf = (n) => '#' + n.toString(16).padStart(6, '0');
  const levelInfo = (lv) => LEVELS[lv % LEVELS.length];

  // ------------------------------------------------------------------------------------
  // Track callbacks
  // ------------------------------------------------------------------------------------
  track.onCollect = (o) => {
    const c = COLORS[o.c];
    player.setTint(c.hex); world.pathTintTarget.set(c.hex);
    G.tintAmt = 0.3; gfx.grade.uniforms.uTint.value.set(c.hex);
    G.punch = Math.min(0.06, G.punch + 0.025);
    if (G.mode !== 'playing') return;
    if (G.chainColor === o.c) G.chainStreak++; else { G.chainColor = o.c; G.chainStreak = 1; }
    const mult = Math.min(6, 1 + Math.floor(G.chainStreak / 3));
    G.score += 10 * mult; G.runOrbs++; G.colorCounts[c.id] = (G.colorCounts[c.id] || 0) + 1;
    G.energy = Math.min(1, G.energy + 0.04);
    audio.pickup(o.c, G.chainStreak); haptics.collect();
    ui.setChain(G.chainColor, G.chainStreak, mult);
    if (G.chainStreak % 3 === 0) {
      G.score += 60 * mult; audio.chain(); haptics.chain();
      ui.toast(`Chroma Chain ×${mult}!`, hexOf(c.hex)); G.punch = 0.09;
      const p = player.rig.position, col = tmpC.set(c.hex).multiplyScalar(1.4);
      for (let i = 0; i < 48; i++) {
        const a = (i / 48) * Math.PI * 2;
        particles.emit(p.x, p.y + 1.1, p.z, Math.cos(a) * 9, Math.sin(a) * 9 * 0.5 + 1, Math.sin(a) * 3 - 4, col.r, col.g, col.b, 0.6, 0.9, { star: 1, drag: 2.2 });
      }
    }
  };
  track.onHit = () => {
    if (G.mode !== 'playing' || G.dead || G.invuln > 0) return;
    G.hearts--; G.invuln = 2.1; G.slow = 0.55; G.shake = 0.8; G.chainColor = -1; G.chainStreak = 0;
    G.boosting = false; audio.hit(); haptics.hit(); ui.flash('#ff4f8f'); ui.setHearts(G.hearts, G.maxHearts, true);
    ui.setChain(-1, 0, 1);
    if (G.hearts <= 0) gameOver();
  };
  track.onGate = () => {
    G.score += 120; G.energy = Math.min(1, G.energy + 0.3);
    audio.gate(); haptics.collect(); ui.toast('Rainbow Gate! +Boost', '#bff3ff'); G.punch = 0.08;
  };
  track.onHeart = () => {
    if (G.mode !== 'playing') return;
    G.hearts = Math.min(5, G.hearts + 1); G.maxHearts = Math.max(G.maxHearts, G.hearts);
    audio.heart(); haptics.collect(); ui.toast('+1 Heart 💖', '#ff9ad0'); ui.setHearts(G.hearts, G.maxHearts, true);
  };
  track.onEgg = () => {
    if (G.mode !== 'playing') return;
    audio.heart(); haptics.collect(); companion.summon(player.rig.position, COMPANION_LIFETIME);
  };
  companion.onHello = () => { audio.companionHello(); haptics.tick(); };
  companion.onGoodbye = () => { audio.companionBye(); haptics.play([20, 60, 20]); };
  companion.onGift = () => { track.gift(G.s, G.x, 8); ui.toast('Lumi left you a gift ✨', '#ffd1ee'); };

  // keep the screen awake while playing (Safari 16.4+, Chrome, Android)
  let wake = null;
  const lockScreen = async () => {
    try { if ('wakeLock' in navigator && !wake) { wake = await navigator.wakeLock.request('screen'); wake.addEventListener('release', () => { wake = null; }); } } catch (e) { wake = null; }
  };

  // ------------------------------------------------------------------------------------
  // Run lifecycle
  // ------------------------------------------------------------------------------------
  const hudLevel = () => ui.setLevel(G.level + 1, levelInfo(G.level).name);

  function resetWorldAt(s) {
    world.rebuildAll(s); world.setProgress(s, 0);
    track.reset(s); particles.clear();
    player.reset(0, 1.2, -s);
    companion.dismiss();
    G.s = s; G.x = 0; G.vx = 0; input.steer = 0; input.recenter();
    camPos.set(0, 4.4, -s + 8.5);
  }

  function startRun(level, resume = null) {
    audio.unlock().then(() => audio.startMusic());
    lockScreen();
    ui.hideAll(); ui.hud(true); input.setActive(true);
    G.mode = 'playing'; G.dead = false; G.deadT = 0; G.level = level;
    const s0 = resume ? resume.s : level * LEVEL_LENGTH + 4;
    resetWorldAt(s0);
    G.startS = s0; G.speed = resume ? 18 : 9; G.hearts = resume ? clamp(resume.hearts || START_HEARTS, 1, 5) : START_HEARTS;
    G.score = resume ? resume.score || 0 : 0; G.runOrbs = 0; G.colorCounts = {}; G.energy = 1; G.boosting = false; G.boostLock = false; G.boostK = 0;
    G.slow = 1; G.invuln = 1.6; G.chainColor = -1; G.chainStreak = 0; G.runTime = 0; G.formCd = 0; G.firstBuddy = false; G.saveT = 0;
    G.level = Math.floor(G.s / LEVEL_LENGTH);
    track.safeUntil = s0 + 90;
    G.maxHearts = Math.max(3, G.hearts); ui.setHearts(G.hearts, G.maxHearts); ui.setScore(G.score); ui.setChain(-1, 0, 1); hudLevel(); ui.setCompanion(false);
    ui.banner(`Level ${G.level + 1}`, levelInfo(G.level).name);
    ui.tip(save.data.runs < 2); setTimeout(() => ui.tip(false), 7000);
    audio.setWaterMix(0);
  }

  function levelUp(lv) {
    G.level = lv; save.reachedLevel(lv); save.tick(0, true);
    audio.levelUp(); haptics.levelUp(); hudLevel();
    ui.banner(`Level ${lv + 1}`, levelInfo(lv).name); G.score += 250; G.punch = 0.12;
    const p = player.rig.position;
    particles.burst(p.x, p.y + 1.2, p.z, tmpC.set(0xfff0b0).multiplyScalar(1.3), 80, 12, 0.8, 1.3, { star: 1, drag: 1.5 });
  }

  function gameOver() {
    G.dead = true; G.deadT = 0; G.boosting = false;
    audio.gameOver(); ui.flash('#a77bff');
    const prevBest = save.data.best;
    const dist = G.s - G.startS;
    const d = save.finishRun({ score: G.score, dist, orbs: G.runOrbs, colors: G.colorCounts });
    save.tick(0, true);
    G.result = { score: G.score, dist, orbs: G.runOrbs, best: d.best, newBest: Math.floor(G.score) > prevBest };
    if (companion.state === 'following') { companion.state = 'goodbye'; companion.stateT = 0; }
  }

  function showGameOver() {
    G.mode = 'over';
    const r = G.result;
    $('rScore').textContent = Math.floor(r.score).toLocaleString();
    $('rDist').textContent = Math.floor(r.dist).toLocaleString() + ' m';
    $('rOrbs').textContent = r.orbs;
    $('rBest').textContent = r.best.toLocaleString();
    $('newBest').hidden = !r.newBest;
    $('overMsg').textContent = `You reached Level ${G.level + 1} — ${levelInfo(G.level).name}.`;
    $('oRetry').textContent = `Try Level ${G.level + 1} again`;
    ui.hud(false); ui.show('over'); input.setActive(false);
  }

  function enterMenu() {
    ui.hideAll(); ui.hud(false); input.setActive(false);
    G.mode = 'menu'; G.dead = false; G.menuS = Math.max(0, save.data.maxLevel) * LEVEL_LENGTH + 30;
    resetWorldAt(G.menuS); G.speed = 20; G.invuln = 1e6; G.runTime = 0;
    G.level = Math.floor(G.menuS / LEVEL_LENGTH);
    refreshMenu(); ui.show('menu');
  }

  function refreshMenu() {
    const d = save.data;
    $('whoName').textContent = d.username;
    $('avatar').textContent = (d.username[0] || '🦋').toUpperCase();
    $('whoSub').textContent = cloud.signedIn ? 'Cloud saves · synced' : (cloud.enabled ? 'Saved on this device · sign in to sync' : 'Saved on this device');
    $('btnPlay').textContent = d.maxLevel > 0 ? `Play · Level ${d.maxLevel + 1}` : 'Play';
    const cont = $('btnContinue');
    if (d.run && d.run.s > 60) { cont.hidden = false; cont.textContent = `Continue run · Level ${Math.floor(d.run.s / LEVEL_LENGTH) + 1} · ${Math.floor(d.run.s).toLocaleString()} m`; }
    else cont.hidden = true;
    $('statsLine').textContent = d.runs ? `Best ${d.best.toLocaleString()}  ·  ${d.totalOrbs.toLocaleString()} orbs  ·  ${d.runs} runs` : 'Welcome, dreamer ✨';
  }

  function pauseGame() {
    if (G.mode !== 'playing' || G.dead) return;
    G.mode = 'paused'; ui.show('pause'); input.setActive(false);
    persistRun(); save.tick(0, true);
  }
  function resumeGame() { if (G.mode !== 'paused') return; ui.hide('pause'); G.mode = 'playing'; input.setActive(true); }

  function persistRun() {
    if ((G.mode !== 'playing' && G.mode !== 'paused') || G.dead) return;
    save.saveRun({ s: Math.floor(G.s / 10) * 10, score: Math.floor(G.score), hearts: G.hearts, level: G.level });
  }

  // ------------------------------------------------------------------------------------
  // Per-frame simulation
  // ------------------------------------------------------------------------------------
  let time = 0;

  function autopilot(dt) {
    let best = null, bd = 1e9;
    for (const o of track.orbs) { const ds = o.s - G.s; if (ds > 2 && ds < 46 && ds < bd) { bd = ds; best = o; } }
    let tx = best ? best.x : Math.sin(time * 0.5) * 3.2;
    for (const ob of track.obstacles) { const ds = ob.s - G.s; if (ds > 0 && ds < 26 && Math.abs(ob.x - tx) < 2.4) tx = ob.x + (ob.x > 0 ? -3.2 : 3.2); }
    input.steer = damp(input.steer, clamp(tx / STEER_LIMIT, -1, 1), 3, dt);
    input.target = input.steer;
  }

  function simulate(dt) {
    const playing = G.mode === 'playing' || G.mode === 'over';
    const attract = G.mode === 'menu';
    G.runTime += dt;
    if (G.dead) G.deadT += dt;
    const base = Math.min(MAX_SPEED, BASE_SPEED + G.level * SPEED_PER_LEVEL);

    // ---- boost ----
    const want = !G.dead && !attract && input.boostHeld && G.energy > 0.02 && !G.boostLock;
    if (want && !G.boosting) { G.boosting = true; audio.boostStart(); haptics.boost(); }
    if (!want && G.boosting) { G.boosting = false; audio.boostEnd(); }
    if (G.boosting) { G.energy -= BOOST_DRAIN * dt; if (G.energy <= 0) { G.energy = 0; G.boostLock = true; } }
    else { G.energy = Math.min(1, G.energy + BOOST_REGEN * dt * (companion.following ? 1.8 : 1)); if (G.boostLock && G.energy > 0.22) G.boostLock = false; }
    G.boostK = damp(G.boostK, G.boosting ? 1 : 0, 6, dt);

    // ---- speed & distance ----
    G.slow = Math.min(1, G.slow + dt * 0.45);
    const target = G.dead ? 0 : base * (G.boosting ? BOOST_MULT : 1) * G.slow * (attract ? 0.72 : 1);
    G.speed = damp(G.speed, target, G.dead ? 1.4 : (G.boosting ? 4 : 1.7), dt);
    G.s += G.speed * dt;
    if (!attract && !G.dead) G.score += G.speed * dt * 0.12 * (G.boosting ? 1.5 : 1);

    // ---- steering ----
    if (attract) autopilot(dt);
    const tx = G.dead ? G.x : input.target * STEER_LIMIT;
    const px = G.x; G.x = damp(G.x, tx, 11, dt);
    G.vx = clamp((G.x - px) / Math.max(dt, 1e-3), -40, 40);

    // ---- forms: air ⇄ water ----
    G.w = waterFactor(G.s); G.formCd -= dt;
    G.wSmooth = damp(G.wSmooth, player.inWater ? 1 : 0, 3, dt);
    if (G.formCd <= 0) {
      if (!player.inWater && G.w > 0.62) switchForm(true);
      else if (player.inWater && G.w < 0.34) switchForm(false);
    }
    const targetY = player.inWater ? WATER_LEVEL + 0.18 + Math.sin(time * 2.2) * 0.05 : 1.2 + G.boostK * 0.25 + Math.sin(time * 2.0) * 0.09;

    const rig = player.rig;
    rig.position.x = G.x; rig.position.z = -G.s;
    player.update(dt, time, { speed: G.speed, boost: G.boosting, vx: G.vx, targetY });
    G.invuln = Math.max(0, G.invuln - dt);
    rig.visible = !(G.invuln > 0 && G.invuln < 1e5 && Math.floor(time * 16) % 2 === 0);

    // ---- track ----
    track.generate(G.s, G.level, { companionActive: companion.active });
    track.update(dt, time, { s: G.s, x: G.x, y: rig.position.y, inWater: player.inWater, magnet: companion.following ? 8 : 0, invulnerable: G.invuln > 0 || G.dead || attract });

    // ---- companion ----
    if (!attract) {
      companion.update(dt, time, player, G.speed);
      if (!G.firstBuddy && G.runTime > FIRST_COMPANION_AT && !G.dead) { G.firstBuddy = true; if (!companion.active) companion.summon(rig.position, COMPANION_LIFETIME); }
    }

    // ---- level progression ----
    const lv = Math.floor(G.s / LEVEL_LENGTH);
    if (!attract && !G.dead && lv > G.level) levelUp(lv);
    if (attract) G.level = lv;

    // ---- emitters (trails, wakes, speed lines) ----
    emitTrails(dt, attract);

    // ---- periodic persistence ----
    if (G.mode === 'playing' && !G.dead) { G.saveT += dt; if (G.saveT > 4) { G.saveT = 0; persistRun(); } }

    // ---- game over delay ----
    if (G.dead && G.deadT > 1.5 && G.mode === 'playing') showGameOver();
  }

  function switchForm(toWater) {
    G.formCd = 1.4;
    player.startMorph(toWater);
    audio.morph(toWater); haptics.morph();
    const p = player.rig.position;
    G.punch = 0.12; G.flashCol.setRGB(0.5, 0.55, 0.65);
    if (toWater) {
      audio.splash();
      particles.burst(p.x, WATER_LEVEL + 0.2, p.z, tmpC.set(0x9fe8ff).multiplyScalar(1.2), 70, 7, 0.5, 1.0, { gravity: 9, drag: 0.4, star: 0 });
      ripples.spawn(p.x, WATER_LEVEL + 0.04, p.z, tmpC.set(0x9fe8ff), 12, 1.4, 0.9);
      if (G.mode === 'playing') { ui.toast('Mermaid form 🧜‍♀️', '#9fe8ff'); }
    } else {
      audio.splash();
      particles.burst(p.x, WATER_LEVEL + 0.2, p.z, tmpC.set(0x9fe8ff).multiplyScalar(1.2), 50, 8, 0.5, 1.0, { gravity: 9, drag: 0.4, star: 0 });
      if (G.mode === 'playing') { ui.toast('Wings return 🦄', '#ffd1ee'); }
    }
    audio.setWaterMix(toWater ? 1 : 0);
  }

  function emitTrails(dt, attract) {
    const rig = player.rig, p = rig.position, t = player.tint;
    const boost = G.boostK;
    const qmul = gfx.q.particles;
    // sparkle from wing tips (air) / fins (water)
    const wings = player.inWater ? player.wWings : player.uWings;
    if (player.air.visible || player.water.visible) {
      const n = (Math.random() < dt * (46 + boost * 80) * qmul) ? 1 : 0;
      for (let i = 0; i < n; i++) {
        const side = Math.random() < 0.5 ? wings.r : wings.l;
        const reach = (Math.random() * 0.6 + 0.7) * (player.inWater ? 1.6 : 2.5);
        tmpV.set(reach, 0, -0.4 - Math.random() * 0.5);
        side.localToWorld(tmpV);
        particles.emit(tmpV.x, tmpV.y, tmpV.z, (Math.random() - 0.5) * 0.7, (Math.random() - 0.2) * 0.9, 1.8 + Math.random() * 1.2,
          0.9 + t.r * 0.6, 0.8 + t.g * 0.6, 0.95 + t.b * 0.6, 0.22 + Math.random() * 0.2, 0.7 + Math.random() * 0.4, { star: Math.random() < 0.55 ? 1 : 0, drag: 0.8, alpha: 0.9 });
      }
    }
    if (!player.inWater && player.air.visible) {
      // glittering hoofprints on the runway
      if (Math.random() < dt * 26 * qmul) {
        const side = Math.random() < 0.5 ? -0.3 : 0.3;
        particles.emit(p.x + side, p.y - 0.6, p.z + 0.4 + Math.random() * 0.6, (Math.random() - 0.5) * 0.4, 0.2, 2.2, 1.0, 0.85 + t.g * 0.2, 0.95, 0.18, 0.8, { star: 1, drag: 1 });
      }
    } else if (player.inWater) {
      G.rippleT -= dt;
      if (G.rippleT <= 0) { G.rippleT = G.boosting ? 0.1 : 0.2; ripples.spawn(p.x, WATER_LEVEL + 0.04, p.z + 0.5, tmpC.set(0xbff6ff).lerp(t, 0.25), 5 + G.speed * 0.1, 1.2, 0.5); }
      if (Math.random() < dt * 40 * qmul) {
        particles.emit(p.x + (Math.random() - 0.5) * 1.2, WATER_LEVEL + 0.1, p.z + 0.8, (Math.random() - 0.5) * 2, 2.5 + Math.random() * 2.5, 3 + Math.random() * 2, 0.7, 0.95, 1.0, 0.16 + Math.random() * 0.12, 0.9, { gravity: 8, drag: 0.2, alpha: 0.9 });
      }
    }
    // speed streaks while boosting
    if (boost > 0.2 && Math.random() < dt * 90 * boost * qmul) {
      const cam = gfx.camera.position;
      const a = Math.random() * Math.PI * 2, r = 3 + Math.random() * 12;
      particles.emit(cam.x + Math.cos(a) * r, cam.y + Math.sin(a) * r * 0.55, cam.z - 6 - Math.random() * 30, 0, 0, G.speed * 1.9, 1, 0.95, 1, 0.1, 0.45, { alpha: 0.7 });
    }
  }

  // ------------------------------------------------------------------------------------
  // Camera & post-processing
  // ------------------------------------------------------------------------------------
  function updateCamera(dt) {
    const cam = gfx.camera, rig = player.rig, p = rig.position;
    const play = G.mode === 'playing' || G.mode === 'over' || G.mode === 'paused';
    G.camBlend = damp(G.camBlend, play ? 1 : 0, 2.4, dt);
    const b = G.camBlend, bk = G.boostK;
    const water = G.wSmooth;
    // hero (menu) camera orbits gently; play camera chases from behind
    const asp = cam.aspect, wide = asp > 1.2;
    const halfT = Math.tan(THREE.MathUtils.degToRad(gfx.baseFov / 2)) * asp;
    const fit = clamp(11.5 / (2 * halfT), 7.2, 15);          // pull back on tall (portrait) screens so every lane stays visible
    const hx = p.x + Math.sin(time * 0.28) * 4.2, hy = p.y + 2.0 + Math.sin(time * 0.4) * 0.3, hz = p.z + Math.max(6.0, fit * 0.8) + Math.cos(time * 0.28) * 1.0;
    const dist = fit + bk * 1.9 - water * 0.6;
    const px = p.x * 0.78, py = p.y + 4.0 + (fit - 7.2) * 0.5 - water * 0.6 + bk * 0.25, pz = p.z + dist;
    const tx = lerp(hx, px, b), ty = lerp(hy, py, b), tz = lerp(hz, pz, b);
    camPos.x = damp(camPos.x, tx, 5.5, dt); camPos.y = damp(camPos.y, ty, 4.5, dt);
    camPos.z = b > 0.98 ? tz : damp(camPos.z, tz, 6, dt);
    cam.position.copy(camPos);
    if (G.shake > 0.001) { cam.position.x += (Math.random() - 0.5) * G.shake * 0.5; cam.position.y += (Math.random() - 0.5) * G.shake * 0.4; G.shake = damp(G.shake, 0, 5, dt); }
    // look target
    const menuShift = wide ? -2.6 : 0;   // title screen: unicorn sits to the right of the menu card
    const lx = lerp(p.x + menuShift, p.x * 0.55, b), ly = lerp(p.y + 1.2, p.y + 1.0, b), lz = lerp(p.z - 0.2, p.z - 9, b);
    const roll = clamp(-G.vx * 0.0065, -0.1, 0.1) * b;
    cam.up.set(Math.sin(roll), Math.cos(roll), 0);
    cam.lookAt(lx, ly, lz);
    // FOV punch
    G.punch = damp(G.punch, 0, 4, dt);
    const fov = gfx.baseFov * (1 + bk * 0.13 + G.punch);
    if (Math.abs(cam.fov - fov) > 0.01) { cam.fov = fov; cam.updateProjectionMatrix(); gfx.fovScale = fov; particles.setScale(gfx.h * gfx.dpr, fov); track.setScale(gfx.h * gfx.dpr, fov); }
  }

  function updateGrade(dt) {
    const u = gfx.grade.uniforms, bk = G.boostK;
    G.tintAmt = damp(G.tintAmt, 0.07, 2.2, dt);
    u.uTintAmt.value = G.tintAmt;
    u.uWarp.value = bk * 0.7; u.uAberration.value = bk * 0.0032 + G.shake * 0.002;
    u.uWater.value = G.wSmooth;
    u.uVignette.value = 0.3 + bk * 0.18 + (G.invuln > 0 && G.invuln < 1e5 ? 0.12 : 0);
    G.flashCol.multiplyScalar(Math.exp(-5 * dt)); u.uFlash.value.copy(G.flashCol);
    gfx.bloom.strength = 0.34 + bk * 0.2 + G.tintAmt * 0.5 + world.darkness * 0.2;
    gfx.bloom.threshold = lerp(1.15, 0.85, world.darkness);
    gfx.renderer.toneMappingExposure = lerp(0.95, 1.15, world.darkness);
    audio.setWaterMix(G.wSmooth);
  }

  function updateHUD(dt) {
    ui.setScore(G.score);
    ui.setBoost(G.energy, G.boosting, G.boostLock);
    ui.setCompanion(companion.following, companion.fraction);
    // speech bubble above Lumi
    if (companion.active && companion.speech) {
      tmpV2.copy(companion.pos).y += 1.15; tmpV2.project(gfx.camera);
      if (tmpV2.z < 1) {
        const x = clamp((tmpV2.x * 0.5 + 0.5) * gfx.w, 110, gfx.w - 110), y = clamp((-tmpV2.y * 0.5 + 0.5) * gfx.h, 70, gfx.h - 130);
        ui.bubble(companion.speech, x, y);
      } else ui.hideBubble();
    } else ui.hideBubble();
    if (save.data.settings.fps) ui.fps(`${gfx.fps.toFixed(0)} fps · ${QUALITY[gfx.tier].name}${gfx.auto ? ' (auto)' : ''} · ${gfx.dpr.toFixed(2)}×`);
  }

  // ------------------------------------------------------------------------------------
  // Main loop
  // ------------------------------------------------------------------------------------
  let last = performance.now();
  function frame(now) {
    requestAnimationFrame(frame);
    const raw = Math.min(0.1, (now - last) / 1000); last = now;
    gfx.monitor(raw);
    const dt = Math.min(raw, 1 / 20);
    input.update(dt);
    if (G.mode !== 'paused') {
      time += dt;
      simulate(dt);
      ripples.update(dt);
      particles.update(dt);
      world.update(dt, time, G.s, G.x, gfx.camera);
      audio.update();
      if (G.mode === 'playing' || G.mode === 'over') updateHUD(dt);
    }
    updateCamera(dt);
    updateGrade(dt);
    save.tick(dt);
    gfx.render(time);
  }

  // ------------------------------------------------------------------------------------
  // UI wiring
  // ------------------------------------------------------------------------------------
  const syncSettingsUI = () => {
    const s = save.data.settings;
    document.querySelectorAll('#segQuality button').forEach((b) => b.classList.toggle('on', b.dataset.q === String(s.quality)));
    $('rngMusic').value = s.music; $('rngSfx').value = s.sfx; $('rngSens').value = s.sens;
    $('chkHaptics').checked = s.haptics; $('chkGyro').checked = s.gyro; $('chkFps').checked = s.fps;
  };
  let settingsFrom = 'menu';
  const openSettings = (from) => { settingsFrom = from; syncSettingsUI(); ui.show('settings'); };
  $('btnSettings').onclick = () => openSettings('menu');
  $('pSettings').onclick = () => openSettings('pause');
  $('sClose').onclick = () => { ui.hide('settings'); audio.click(); };
  document.querySelectorAll('#segQuality button').forEach((b) => b.addEventListener('click', () => { save.setSettings({ quality: b.dataset.q === 'auto' ? 'auto' : +b.dataset.q }); applySettings(); syncSettingsUI(); audio.click(); }));
  $('rngMusic').oninput = (e) => { save.setSettings({ music: +e.target.value }); applySettings(); };
  $('rngSfx').oninput = (e) => { save.setSettings({ sfx: +e.target.value }); applySettings(); };
  $('rngSens').oninput = (e) => { save.setSettings({ sens: +e.target.value }); applySettings(); };
  $('chkHaptics').onchange = (e) => { save.setSettings({ haptics: e.target.checked }); applySettings(); if (e.target.checked) haptics.collect(); };
  $('chkFps').onchange = (e) => { save.setSettings({ fps: e.target.checked }); applySettings(); };
  $('chkGyro').onchange = async (e) => {
    if (e.target.checked) { const ok = await input.enableGyro(); if (!ok) { e.target.checked = false; ui.toast('Tilt needs motion permission', '#ffd1ee'); } save.setSettings({ gyro: ok }); }
    else { input.disableGyro(); save.setSettings({ gyro: false }); }
  };

  $('btnPlay').onclick = () => { audio.click(); startRun(Math.max(0, save.data.maxLevel)); };
  $('btnContinue').onclick = () => { audio.click(); const r = save.data.run; if (r) startRun(Math.floor(r.s / LEVEL_LENGTH), r); };
  $('btnHow').onclick = () => { audio.click(); ui.show('how'); };
  $('hClose').onclick = () => ui.hide('how');
  $('btnPause').onclick = () => { audio.click(); pauseGame(); };
  $('pResume').onclick = () => { audio.click(); resumeGame(); };
  $('pRestart').onclick = () => { audio.click(); ui.hide('pause'); startRun(G.level); };
  $('pQuit').onclick = () => { audio.click(); persistRun(); save.tick(0, true); enterMenu(); };
  $('oRetry').onclick = () => { audio.click(); ui.hide('over'); startRun(G.level); };
  $('oRestart').onclick = () => { audio.click(); ui.hide('over'); startRun(0); };
  $('oMenu').onclick = () => { audio.click(); enterMenu(); };
  $('btnMute').onclick = () => { audio.setMuted(!audio.muted); $('btnMute').classList.toggle('off', audio.muted); };
  input.onPause = () => { if (G.mode === 'playing') pauseGame(); else if (G.mode === 'paused') resumeGame(); };

  // ---- profile / auth ----
  const setAuthMode = () => {
    const cloudOn = cloud.enabled;
    $('inPin').hidden = !cloudOn;
    $('aSignUp').hidden = !cloudOn;
    $('aSignIn').textContent = cloudOn ? 'Sign in' : 'Save name';
    $('authTitle').textContent = cloudOn ? 'Sign in to sync' : 'Your player name';
    $('authMsg').textContent = cloudOn ? 'Same name + passcode on any device resumes your run.' : 'Pick a name to keep your progress on this device.';
    $('authErr').textContent = '';
    $('inUser').value = save.hasUser ? save.name : '';
  };
  $('btnProfile').onclick = () => { audio.click(); setAuthMode(); ui.show('auth'); };
  $('aCancel').onclick = () => ui.hide('auth');
  const adoptUser = async (name) => {
    save.load(name); save.persist(false); applySettings(); refreshMenu();
    if (cloud.signedIn) await syncFromCloud();
  };
  async function syncFromCloud() {
    const c = await cloud.load(); save.mergeCloud(c); applySettings(); refreshMenu();
    save.cloudPush = (d) => cloud.save(d); save.persist(true); save.tick(0, true);
    cloud.watch((remote) => { if (G.mode === 'menu') { save.mergeCloud(remote); applySettings(); refreshMenu(); } else save.mergeCloud({ ...remote, run: null, updatedAt: 0 }); });
  }
  $('aSignIn').onclick = async () => {
    const name = cleanName($('inUser').value); const err = $('authErr');
    if (name.length < 2) { err.textContent = 'Please use at least 2 characters.'; return; }
    if (!cloud.enabled) { await adoptUser(name); ui.hide('auth'); return; }
    const pin = $('inPin').value;
    if (pin.length < 4) { err.textContent = 'Passcode needs at least 4 characters.'; return; }
    err.textContent = 'Signing in…';
    try { if (!(await cloud.init())) throw new Error('offline'); await cloud.signIn(name, pin); await adoptUser(name); ui.hide('auth'); }
    catch (e) { err.textContent = friendlyAuthError(e); }
  };
  $('aSignUp').onclick = async () => {
    const name = cleanName($('inUser').value); const pin = $('inPin').value; const err = $('authErr');
    if (name.length < 2) { err.textContent = 'Please use at least 2 characters.'; return; }
    if (pin.length < 4) { err.textContent = 'Passcode needs at least 4 characters.'; return; }
    err.textContent = 'Creating account…';
    try { if (!(await cloud.init())) throw new Error('offline'); await cloud.signUp(name, pin); await adoptUser(name); ui.hide('auth'); }
    catch (e) { err.textContent = friendlyAuthError(e); }
  };
  function friendlyAuthError(e) {
    const c = (e && e.code) || '';
    if (c.includes('email-already-in-use')) return 'That name is taken — sign in instead, or pick another.';
    if (c.includes('invalid-credential') || c.includes('wrong-password') || c.includes('user-not-found') || c.includes('invalid-login')) return 'Name or passcode not recognised.';
    if (c.includes('weak-password')) return 'Choose a longer passcode.';
    if (c.includes('network') || String(e.message).includes('offline')) return 'You appear to be offline. You can still play — sign in later.';
    if (c.includes('operation-not-allowed')) return 'Enable Email/Password sign-in in your Firebase console (see README).';
    return 'Something went wrong. Please try again.';
  }

  // ---- leaderboard ----
  $('btnBoard').onclick = async () => {
    audio.click(); const list = $('boardList'); list.innerHTML = '<li><span class="nm">Loading…</span></li>'; ui.show('board');
    if (!cloud.signedIn) {
      list.innerHTML = `<li class="you"><span class="rk">1</span><span class="nm">${save.name} (you)</span><span class="sc">${save.data.best.toLocaleString()}</span></li><li><span class="nm" style="opacity:.8;font-weight:600">${cloud.enabled ? 'Sign in to see global rankings.' : 'Global leaderboard needs Firebase (see README step 4).'}</span></li>`;
      return;
    }
    const rows = await cloud.leaderboard(10);
    list.innerHTML = rows.length ? rows.map((r, i) => `<li class="${r.you ? 'you' : ''}"><span class="rk">${i + 1}</span><span class="nm">${r.name.replace(/[<>&]/g, '')}</span><span class="sc">${r.best.toLocaleString()}</span></li>`).join('') : '<li><span class="nm">No scores yet — be the first!</span></li>';
  };
  $('bClose').onclick = () => ui.hide('board');

  // ---- global listeners ----
  document.addEventListener('pointerdown', () => { audio.unlock().then(() => { if (audio.ctx && audio.ctx.state === 'running') audio.startMusic(); }); }, { capture: true });
  input.onFirstGesture = () => audio.unlock();
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { pauseGame(); persistRun(); save.persist(); save.tick(0, true); audio.ctx?.suspend?.(); }
    else { audio.ctx?.resume?.(); if (G.mode === 'playing' || G.mode === 'paused') lockScreen(); }
  });
  window.addEventListener('pagehide', () => { persistRun(); save.persist(); save.tick(0, true); });
  const rot = $('rotate'); // gentle landscape hint on very small phones while playing is not forced; keep hidden
  rot.style.display = 'none';

  // iOS "Add to Home Screen" hint
  const standalone = window.navigator.standalone || matchMedia('(display-mode: standalone)').matches;
  if (isIOS && !standalone && !localStorage.getItem('bf.installDismissed')) {
    setTimeout(() => $('installHint').classList.remove('hidden'), 4500);
    $('btnInstallClose').onclick = () => { $('installHint').classList.add('hidden'); localStorage.setItem('bf.installDismissed', '1'); };
  }

  // PWA service worker (offline play)
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    navigator.serviceWorker.register('sw.js').catch((e) => console.warn('SW failed', e));
  }
  $('version').textContent = `v${VERSION}`;

  // ------------------------------------------------------------------------------------
  // Start
  // ------------------------------------------------------------------------------------
  applySettings();
  ui.loading(0.92, 'Almost there…'); await nextFrame();
  if (cloud.enabled) { // restore session in the background; never block the game on the network
    cloud.init().then(async () => { if (cloud.signedIn && save.hasUser) await syncFromCloud(); refreshMenu(); });
  }
  enterMenu();
  // pre-warm shaders so the first frame of play doesn't hitch
  gfx.renderer.compile(gfx.scene, gfx.camera);
  requestAnimationFrame(frame);
  ui.loading(1, 'Ready'); await new Promise((r) => setTimeout(r, 250));
  ui.loaded();
  if (!save.hasUser) { setAuthMode(); ui.show('auth'); }
  window.__bf = { gfx, world, player, companion, track, G, save, audio, cloud, startRun, ui, particles, input };   // handy for debugging in the console
}

boot().catch((e) => { console.error((e && e.stack) || e); ui.loading(1, 'Something went wrong: ' + (e && e.message ? e.message : e)); });
