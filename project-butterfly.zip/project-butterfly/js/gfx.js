// Rendering pipeline: WebGL2 renderer, HDR bloom, cinematic colour grading,
// adaptive quality (auto-scales resolution / shadows / bloom to hold your frame rate).
import * as THREE from '../vendor/three.bundle.js';
import { QUALITY } from './config.js';
import { isIOS, isMobile, clamp } from './util.js';

const GradeShader = {
  uniforms: {
    tDiffuse: { value: null },
    uTime: { value: 0 },
    uVignette: { value: 0.32 },
    uSat: { value: 1.26 },
    uContrast: { value: 1.14 },
    uTint: { value: new THREE.Color(1, 1, 1) },
    uTintAmt: { value: 0 },
    uAberration: { value: 0.0 },
    uWarp: { value: 0.0 },
    uWater: { value: 0.0 },
    uFlash: { value: new THREE.Color(0, 0, 0) },
    uGlow: { value: new THREE.Color(1.0, 0.92, 0.98) }
  },
  vertexShader: /* glsl */`
    varying vec2 vUv;
    void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
  `,
  fragmentShader: /* glsl */`
    precision highp float;
    uniform sampler2D tDiffuse;
    uniform float uTime, uVignette, uSat, uContrast, uTintAmt, uAberration, uWarp, uWater;
    uniform vec3 uTint, uFlash, uGlow;
    varying vec2 vUv;
    float hash(vec2 p) { return fract(sin(dot(p, vec2(41.3, 289.1))) * 43758.5453); }
    void main() {
      vec2 uv = vUv;
      vec2 c = uv - 0.5;
      float r2 = dot(c, c);
      // gentle underwater wobble
      uv += uWater * 0.0035 * vec2(sin(uv.y * 38.0 + uTime * 2.4), cos(uv.x * 30.0 + uTime * 2.0));
      // chromatic aberration grows toward screen edges (and with boost)
      float ab = (uAberration + 0.0007) * (0.5 + r2 * 6.0);
      vec3 col;
      if (uWarp > 0.01) {
        // radial speed blur
        vec3 acc = vec3(0.0);
        float w = 0.0;
        for (int i = 0; i < 7; i++) {
          float f = float(i) / 6.0;
          vec2 o = c * f * uWarp * 0.11;
          acc += vec3(texture2D(tDiffuse, uv - o * (1.0 + ab * 40.0)).r,
                      texture2D(tDiffuse, uv - o).g,
                      texture2D(tDiffuse, uv - o * (1.0 - ab * 40.0)).b) * (1.0 - f * 0.55);
          w += (1.0 - f * 0.55);
        }
        col = acc / w;
      } else {
        col = vec3(texture2D(tDiffuse, uv + c * ab).r, texture2D(tDiffuse, uv).g, texture2D(tDiffuse, uv - c * ab).b);
      }
      // grade (linear HDR space, before tone mapping)
      float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
      col = mix(vec3(l), col, uSat + uWater * 0.1);
      col = (col - 0.18) * uContrast + 0.18;
      // lift shadows toward a dreamy violet, highlights toward warm cream
      col += (1.0 - smoothstep(0.0, 0.35, l)) * vec3(0.018, 0.010, 0.032);
      col *= mix(vec3(1.0), uGlow, smoothstep(0.4, 1.4, l) * 0.5);
      // colour pickup tint wash
      col = mix(col, col * (uTint * 1.25 + 0.15), uTintAmt);
      // underwater caustic tint
      col = mix(col, col * vec3(0.72, 1.02, 1.18), uWater * 0.55);
      col += uFlash;
      // soft vignette
      col *= 1.0 - uVignette * smoothstep(0.12, 0.62, r2 * 2.0);
      // film grain (very light, avoids banding in gradients)
      col += (hash(vUv * 1731.0 + fract(uTime)) - 0.5) * 0.012;
      gl_FragColor = vec4(max(col, 0.0), 1.0);
    }
  `
};

export class Gfx {
  constructor(canvas) {
    this.canvas = canvas;
    this.renderer = new THREE.WebGLRenderer({
      canvas, antialias: false, alpha: false, powerPreference: 'high-performance',
      stencil: false, preserveDrawingBuffer: false
    });
    const r = this.renderer;
    r.outputColorSpace = THREE.SRGBColorSpace;
    r.toneMapping = THREE.ACESFilmicToneMapping;
    r.toneMappingExposure = 0.95;
    r.shadowMap.enabled = false;
    r.shadowMap.type = THREE.PCFShadowMap;
    r.setClearColor(0x1a1030, 1);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(70, 1, 0.1, 700);
    this.camera.position.set(0, 4, 10);

    this.tier = isMobile ? (isIOS ? 2 : 1) : 3;
    this.auto = true;
    this.userTier = 'auto';
    this.composer = null;
    this.maxDpr = Math.min(window.devicePixelRatio || 1, 3);
    this.w = 1; this.h = 1;
    this.dprScale = 1;       // dynamic resolution scalar (0.6..1)

    // perf monitor
    this._frames = 0; this._acc = 0; this._cool = 0; this._lowStreak = 0; this._highStreak = 0;
    this.fps = 60; this.onQuality = null;
    this.targetMs = 1000 / 58;

    this._buildPipeline();
    this.resize();
    window.addEventListener('resize', () => this.resize());
    window.addEventListener('orientationchange', () => setTimeout(() => this.resize(), 250));
    if (window.visualViewport) window.visualViewport.addEventListener('resize', () => this.resize());
  }

  get q() { return QUALITY[this.tier]; }

  _buildPipeline() {
    if (this.composer) { this.composer.dispose?.(); this.composer = null; }
    const { renderer, scene, camera } = this;
    const q = this.q;
    const dpr = clamp(Math.min(this.maxDpr, q.dpr) * this.dprScale, 0.6, 3);
    renderer.setPixelRatio(dpr);
    this.dpr = dpr;
    const w = Math.max(2, Math.floor(this.w * dpr)), h = Math.max(2, Math.floor(this.h * dpr));
    const rt = new THREE.WebGLRenderTarget(w, h, { type: THREE.HalfFloatType, samples: q.msaa, depthBuffer: true });
    this.composer = new THREE.EffectComposer(renderer, rt);
    this.composer.setPixelRatio(dpr);
    this.composer.setSize(this.w, this.h);
    this.composer.addPass(new THREE.RenderPass(scene, camera));
    this.bloom = new THREE.UnrealBloomPass(new THREE.Vector2(this.w, this.h), 0.4, 0.55, 1.15);
    this.bloom.enabled = q.bloom;
    this.composer.addPass(this.bloom);
    this.grade = new THREE.ShaderPass(GradeShader);
    this.composer.addPass(this.grade);
    this.composer.addPass(new THREE.OutputPass());
    renderer.shadowMap.enabled = q.shadows > 0;
    this.onQuality?.(this.tier, q);
  }

  setShadowSize(light) {
    const s = this.q.shadows;
    if (!s) { light.castShadow = false; return; }
    light.castShadow = true;
    if (light.shadow.mapSize.x !== s) {
      light.shadow.mapSize.set(s, s);
      if (light.shadow.map) { light.shadow.map.dispose(); light.shadow.map = null; }
    }
  }

  setQualityMode(mode) { // 'auto' | 0..3
    if (mode === 'auto') { this.auto = true; this.userTier = 'auto'; }
    else { this.auto = false; this.userTier = +mode; this.setTier(+mode); }
  }

  setTier(t) {
    t = clamp(t, 0, QUALITY.length - 1);
    if (t === this.tier) return;
    this.tier = t;
    this.dprScale = 1;
    this._buildPipeline();
  }

  resize() {
    const vv = window.visualViewport;
    const w = Math.floor(vv ? vv.width : window.innerWidth);
    const h = Math.floor(vv ? vv.height : window.innerHeight);
    if (w < 2 || h < 2) return;
    this.w = w; this.h = h;
    this.renderer.setSize(w, h, false);
    this.canvas.style.width = '100%';
    this.canvas.style.height = '100%';
    this.camera.aspect = w / h;
    // keep the horizontal field of view generous in portrait
    const vfov = clamp(THREE.MathUtils.radToDeg(2 * Math.atan(0.62 / this.camera.aspect)), 60, 80);
    this.camera.fov = vfov; this.baseFov = vfov;
    this.camera.updateProjectionMatrix();
    if (this.composer) {
      this.composer.setPixelRatio(this.dpr);
      this.composer.setSize(w, h);
    }
    this.onResize?.(w, h);
  }

  // adaptive quality: call with the raw frame dt (seconds) each frame
  monitor(dt) {
    if (dt <= 0 || dt > 0.5) return;
    this._frames++; this._acc += dt;
    if (this._frames < 45) return;
    const avgMs = (this._acc / this._frames) * 1000;
    this.fps = 1000 / avgMs;
    this._frames = 0; this._acc = 0;
    if (this._cool > 0) { this._cool--; return; }
    if (!this.auto) return;
    // Refresh-rate aware: ProMotion devices may legitimately sit at 8.3ms
    if (avgMs > 22) { this._lowStreak++; this._highStreak = 0; }
    else if (avgMs < 12.5) { this._highStreak++; this._lowStreak = 0; }
    else { this._lowStreak = 0; this._highStreak = 0; }
    if (this._lowStreak >= 2) {
      this._lowStreak = 0; this._cool = 3;
      if (this.dprScale > 0.75) { this.dprScale = Math.max(0.7, this.dprScale - 0.15); this._buildPipeline(); }
      else if (this.tier > 0) { this.setTier(this.tier - 1); }
    } else if (this._highStreak >= 6 && this.tier < QUALITY.length - 1 && this.tier < (isMobile ? 2 : 3)) {
      this._highStreak = 0; this._cool = 4;
      if (this.dprScale < 1) { this.dprScale = Math.min(1, this.dprScale + 0.15); this._buildPipeline(); }
      else this.setTier(this.tier + 1);
    }
  }

  render(time) {
    this.grade.uniforms.uTime.value = time;
    this.composer.render();
  }
}
