// The player: a butterfly-winged unicorn (air form) that morphs into a butterfly-finned
// mermaid (water form). Procedurally modelled, animated and tinted by collected colours.
import * as THREE from '../vendor/three.bundle.js';
import { fanGeometry, wingMaterial, timeU } from './geo.js';
import { clamp, damp, lerp, smooth } from './util.js';
import { WATER_LEVEL } from './config.js';

// ---------------------------------------------------------------------------
// Ribbon: a world-space follow-the-leader chain rendered as a glowing strip.
// Used for the unicorn's mane/tail, the mermaid's hair, and the companion's trail.
// ---------------------------------------------------------------------------
const RIBBON_VERT = /* glsl */`
  attribute float aT; attribute float aSide;
  varying float vT; varying float vSide;
  void main() { vT = aT; vSide = aSide; gl_Position = projectionMatrix * viewMatrix * vec4(position, 1.0); }`;
const RIBBON_FRAG = /* glsl */`
  precision highp float;
  uniform vec3 uTint; uniform float uTime, uMix, uIntensity, uHue, uAlpha;
  varying float vT; varying float vSide;
  void main() {
    vec3 rb = 0.5 + 0.5 * cos(6.2831 * (vT * 0.8 + uHue + uTime * 0.18 + vec3(0.0, 0.33, 0.67)));
    rb = pow(rb, vec3(1.35));
    vec3 col = mix(rb, uTint * 1.1 + 0.05, uMix);
    float core = 1.0 - abs(vSide) * 0.55;
    float a = (1.0 - vT * vT) * smoothstep(0.0, 0.06, vT + 0.05) * uAlpha;
    gl_FragColor = vec4(col * uIntensity * (0.75 + 0.6 * core), a);
  }`;

class Ribbon {
  constructor(scene, { n = 14, seg = 0.28, width = 0.5, hue = 0, mix = 0.45, intensity = 1.6, wave = 0.5, rise = 0.5, back = 1.0, tint = null, alpha = 0.95 } = {}) {
    this.n = n; this.seg = seg; this.width = width; this.wave = wave; this.rise = rise; this.back = back;
    this.p = Array.from({ length: n }, () => new THREE.Vector3());
    const pos = new Float32Array(n * 2 * 3), t = new Float32Array(n * 2), sd = new Float32Array(n * 2);
    const idx = [];
    for (let i = 0; i < n; i++) {
      t[i * 2] = t[i * 2 + 1] = i / (n - 1);
      sd[i * 2] = -1; sd[i * 2 + 1] = 1;
      if (i < n - 1) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aT', new THREE.BufferAttribute(t, 1));
    g.setAttribute('aSide', new THREE.BufferAttribute(sd, 1));
    g.setIndex(idx);
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);
    this.mat = new THREE.ShaderMaterial({
      uniforms: { uTint: { value: tint || new THREE.Color(1, 0.6, 0.9) }, uTime: timeU, uMix: { value: mix }, uIntensity: { value: intensity }, uHue: { value: hue }, uAlpha: { value: alpha } },
      vertexShader: RIBBON_VERT, fragmentShader: RIBBON_FRAG,
      transparent: true, depthWrite: false, side: THREE.DoubleSide
    });
    this.mesh = new THREE.Mesh(g, this.mat);
    this.mesh.frustumCulled = false; this.mesh.renderOrder = 6;
    scene.add(this.mesh);
    this._t = new THREE.Vector3(); this._s = new THREE.Vector3(); this._up = new THREE.Vector3(0, 1, 0);
    this.visible = true;
  }
  reset(a) { for (const p of this.p) p.copy(a); }
  setVisible(v) { this.mesh.visible = v; }
  update(dt, anchor, time, side = new THREE.Vector3(1, 0, 0), amount = 1) {
    const p = this.p, n = this.n;
    p[0].copy(anchor);
    for (let i = 1; i < n; i++) {
      const f = i / (n - 1);
      // drift: backwards, upwards, and a travelling sine wave
      p[i].x += Math.sin(time * 5 + i * 0.55) * this.wave * f * dt * 2.2;
      p[i].y += (this.rise * (0.35 + f) - 0.15) * dt * 1.4 * amount + Math.sin(time * 3.3 + i * 0.7) * 0.18 * f * dt * 2;
      p[i].z += this.back * dt * 1.8;
      const q = p[i - 1];
      this._t.subVectors(p[i], q);
      const l = this._t.length() || 1e-4;
      p[i].copy(q).addScaledVector(this._t, this.seg / l);
    }
    const arr = this.mesh.geometry.attributes.position.array;
    for (let i = 0; i < n; i++) {
      const a = p[Math.max(0, i - 1)], b = p[Math.min(n - 1, i + 1)];
      this._t.subVectors(a, b).normalize();
      this._s.crossVectors(this._t, this._up);
      if (this._s.lengthSq() < 1e-4) this._s.copy(side);
      this._s.normalize();
      const f = i / (n - 1);
      const w = this.width * (0.35 + Math.sin(Math.min(1, f * 1.15) * Math.PI) * 0.65) * (1 - f * 0.35) * amount;
      const k = i * 6;
      arr[k] = p[i].x - this._s.x * w; arr[k + 1] = p[i].y - this._s.y * w; arr[k + 2] = p[i].z - this._s.z * w;
      arr[k + 3] = p[i].x + this._s.x * w; arr[k + 4] = p[i].y + this._s.y * w; arr[k + 5] = p[i].z + this._s.z * w;
    }
    this.mesh.geometry.attributes.position.needsUpdate = true;
  }
}

// ---------------------------------------------------------------------------
function butterflyWingShape() {
  const s = new THREE.Shape();
  // x = outward, y = forward. Upper (fore) wing + lower (hind) wing with a notch between them.
  s.moveTo(0.1, 0.15);
  s.bezierCurveTo(0.5, 1.15, 1.7, 1.65, 2.55, 1.0);
  s.bezierCurveTo(3.05, 0.6, 2.7, -0.05, 1.95, -0.28);
  s.bezierCurveTo(2.35, -0.95, 1.75, -1.85, 0.95, -1.65);
  s.bezierCurveTo(0.4, -1.45, 0.1, -0.8, 0.1, -0.15);
  s.closePath();
  return s;
}
function flukeShape() {
  const s = new THREE.Shape();
  s.moveTo(0, 0);
  s.bezierCurveTo(0.5, 0.2, 1.3, 0.8, 1.5, 1.6);
  s.bezierCurveTo(0.9, 1.35, 0.35, 1.25, 0, 1.0);
  s.bezierCurveTo(-0.35, 1.25, -0.9, 1.35, -1.5, 1.6);
  s.bezierCurveTo(-1.3, 0.8, -0.5, 0.2, 0, 0);
  return s;
}
function finShape() {
  const s = new THREE.Shape();
  s.moveTo(0.05, 0.1);
  s.bezierCurveTo(0.5, 0.9, 1.4, 1.2, 2.0, 0.7);
  s.bezierCurveTo(2.3, 0.3, 1.9, -0.3, 1.4, -0.5);
  s.bezierCurveTo(1.7, -1.0, 1.2, -1.5, 0.6, -1.3);
  s.bezierCurveTo(0.2, -1.1, 0.05, -0.5, 0.05, -0.1);
  s.closePath();
  return s;
}

const WING_G = fanGeometry(butterflyWingShape(), 48, new THREE.Vector2(0.15, 0));
const FIN_G = fanGeometry(finShape(), 40, new THREE.Vector2(0.1, 0));
const FLUKE_G = (() => { const g = fanGeometry(flukeShape(), 40, new THREE.Vector2(0, 0.05)); return g; })();

function makeWingPair(geo, mat, scale, hinge) {
  const pivotR = new THREE.Group(), pivotL = new THREE.Group();
  const r = new THREE.Mesh(geo, mat), l = new THREE.Mesh(geo, mat);
  r.scale.setScalar(scale); l.scale.set(-scale, scale, scale);
  r.renderOrder = l.renderOrder = 5;
  pivotR.add(r); pivotL.add(l);
  pivotR.position.copy(hinge); pivotL.position.copy(hinge);
  return { pivotR, pivotL, r, l };
}

const C_WHITE = new THREE.Color(1, 1, 1), C_AQUA = new THREE.Color(0x3fe8ff), C_TEAL = new THREE.Color(0x38f0d8), C_MINT = new THREE.Color(0x66ffe0);
const mk = (geo, mat, x = 0, y = 0, z = 0, cast = true) => {
  const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = cast; return m;
};

// ---------------------------------------------------------------------------
export class Player {
  constructor(scene, particles) {
    this.scene = scene; this.particles = particles;
    this.rig = new THREE.Group();
    this.rig.scale.setScalar(1.25);
    scene.add(this.rig);

    this.tint = new THREE.Color(0xff7ac8);
    this.tintTarget = new THREE.Color(0xff7ac8);
    this._hsl = { h: 0, s: 0, l: 0 };
    this.wingA = new THREE.Color(); this.wingB = new THREE.Color();

    this.inWater = false;
    this.morph = 1;            // 0 → just switched, 1 → settled
    this.morphFrom = null;
    this.t = 0;
    this.gallop = 0;
    this.swim = 0;
    this.flap = 0;
    this.vx = 0;
    this.pos = new THREE.Vector3();
    this.worldAnchor = new THREE.Vector3();

    this._buildMaterials();
    this._buildUnicorn();
    this._buildMermaid();
    this._buildMorphFx();
    this.rig.add(this.air, this.water);
    this.water.visible = false;
    this.air.scale.setScalar(1); this.water.scale.setScalar(0.001);
    this.shadowMeshes = [];
    this.rig.traverse((o) => { if (o.isMesh && o.castShadow) this.shadowMeshes.push(o); });
  }

  // ---- materials ----------------------------------------------------------
  _buildMaterials() {
    this.mBody = new THREE.MeshPhysicalMaterial({ color: 0xfff6fb, roughness: 0.38, clearcoat: 0.9, clearcoatRoughness: 0.2, sheen: 1, sheenColor: new THREE.Color(0xffb0e0), sheenRoughness: 0.4, emissive: 0xff7ac8, emissiveIntensity: 0.16 });
    this.mHorn = new THREE.MeshPhysicalMaterial({ color: 0xfff0b0, roughness: 0.25, metalness: 0.4, emissive: 0xffd86b, emissiveIntensity: 1.2, clearcoat: 1 });
    this.mHoof = new THREE.MeshStandardMaterial({ color: 0xffd36b, roughness: 0.3, metalness: 0.7, emissive: 0xffa43a, emissiveIntensity: 0.35 });
    this.mEye = new THREE.MeshStandardMaterial({ color: 0x1a0a2e, roughness: 0.1, metalness: 0.2 });
    this.mEyeHi = new THREE.MeshBasicMaterial({ color: 0xffffff });
    this.mSkin = new THREE.MeshPhysicalMaterial({ color: 0xffe0cf, roughness: 0.5, clearcoat: 0.3, sheen: 0.5, sheenColor: new THREE.Color(0xffc0d8) });
    this.mScale = new THREE.MeshPhysicalMaterial({ color: 0x66ffe0, roughness: 0.18, metalness: 0.1, clearcoat: 1, iridescence: 1, iridescenceIOR: 1.6, iridescenceThicknessRange: [200, 600], emissive: 0x28ffd0, emissiveIntensity: 0.18 });
    this.mShell = new THREE.MeshPhysicalMaterial({ color: 0xfff0c8, roughness: 0.2, metalness: 0.5, emissive: 0xffd070, emissiveIntensity: 0.5, clearcoat: 1 });

    this.wingMat = wingMaterial({ colorA: 0xff7ac8, colorB: 0xffe28a, intensity: 1.55, style: 0 });
    this.finMat = wingMaterial({ colorA: 0x3fe8ff, colorB: 0xb98cff, intensity: 1.5, style: 1 });
    this.flukeMat = wingMaterial({ colorA: 0x38f0d8, colorB: 0xff9ae0, intensity: 1.6, style: 1 });
  }

  // ---- unicorn ---------------------------------------------------------------
  _buildUnicorn() {
    const A = this.air = new THREE.Group();
    const body = new THREE.Group(); A.add(body); this.uBody = body;

    const torso = mk(new THREE.CapsuleGeometry(0.46, 0.95, 8, 18), this.mBody, 0, 1.25, 0);
    torso.rotation.x = Math.PI / 2; body.add(torso);
    body.add(mk(new THREE.SphereGeometry(0.52, 20, 16), this.mBody, 0, 1.32, -0.58));
    body.add(mk(new THREE.SphereGeometry(0.5, 20, 16), this.mBody, 0, 1.25, 0.55));

    // neck + head
    const neck = mk(new THREE.CapsuleGeometry(0.21, 0.55, 6, 12), this.mBody, 0, 1.82, -1.02);
    neck.rotation.x = -0.62; body.add(neck);
    const head = new THREE.Group(); head.position.set(0, 2.2, -1.38); head.rotation.x = -0.1; body.add(head);
    this.uHead = head;
    const skull = mk(new THREE.SphereGeometry(0.28, 18, 14), this.mBody); skull.scale.set(1, 1, 1.35); head.add(skull);
    head.add(mk(new THREE.SphereGeometry(0.2, 16, 12), this.mBody, 0, -0.1, -0.36));
    for (const sx of [-1, 1]) {
      head.add(mk(new THREE.SphereGeometry(0.075, 12, 10), this.mEye, sx * 0.19, 0.04, -0.2, false));
      head.add(mk(new THREE.SphereGeometry(0.025, 8, 8), this.mEyeHi, sx * 0.205, 0.075, -0.255, false));
      const ear = mk(new THREE.ConeGeometry(0.07, 0.24, 8), this.mBody, sx * 0.14, 0.3, 0.1); ear.rotation.z = -sx * 0.25; head.add(ear);
      // blush
      const bl = new THREE.Mesh(new THREE.CircleGeometry(0.06, 12), new THREE.MeshBasicMaterial({ color: 0xff8fc8, transparent: true, opacity: 0.55 }));
      bl.position.set(sx * 0.22, -0.06, -0.24); bl.rotation.y = sx * 1.2; head.add(bl);
    }
    // horn with glowing rings
    const horn = new THREE.Group(); horn.position.set(0, 0.28, -0.2); horn.rotation.x = -0.5; head.add(horn);
    horn.add(mk(new THREE.ConeGeometry(0.075, 0.85, 12), this.mHorn, 0, 0.42, 0, false));
    for (let i = 0; i < 5; i++) { const r = mk(new THREE.TorusGeometry(0.065 - i * 0.011, 0.012, 6, 14), this.mHorn, 0, 0.12 + i * 0.14, 0, false); r.rotation.x = Math.PI / 2; horn.add(r); }
    this.hornTip = new THREE.Object3D(); this.hornTip.position.set(0, 0.85, 0); horn.add(this.hornTip);

    // legs
    this.legs = [];
    const mkLeg = (x, z, front) => {
      const hip = new THREE.Group(); hip.position.set(x, 1.05, z);
      hip.add(mk(new THREE.CapsuleGeometry(0.115, 0.4, 4, 8), this.mBody, 0, -0.28, 0));
      const knee = new THREE.Group(); knee.position.y = -0.52; hip.add(knee);
      knee.add(mk(new THREE.CapsuleGeometry(0.085, 0.38, 4, 8), this.mBody, 0, -0.26, 0));
      knee.add(mk(new THREE.CylinderGeometry(0.1, 0.12, 0.13, 10), this.mHoof, 0, -0.55, 0));
      body.add(hip);
      this.legs.push({ hip, knee, front, side: Math.sign(x) });
    };
    mkLeg(-0.27, -0.6, true); mkLeg(0.27, -0.6, true); mkLeg(-0.27, 0.6, false); mkLeg(0.27, 0.6, false);

    // butterfly wings
    const hinge = new THREE.Vector3(0, 1.78, -0.1);
    this.uWings = makeWingPair(WING_G, this.wingMat, 1.15, hinge);
    A.add(this.uWings.pivotR, this.uWings.pivotL);

    // mane + tail ribbons (world-space chains)
    this.mane = new Ribbon(this.scene, { n: 14, seg: 0.27, width: 0.42, hue: 0.0, mix: 0.4, wave: 0.7, rise: 0.12, back: 1.2, tint: this.tint });
    this.mane2 = new Ribbon(this.scene, { n: 12, seg: 0.25, width: 0.3, hue: 0.33, mix: 0.4, wave: 0.8, rise: 0.15, back: 1.3, tint: this.tint });
    this.tail = new Ribbon(this.scene, { n: 22, seg: 0.34, width: 0.62, hue: 0.66, mix: 0.4, wave: 0.8, rise: 0.12, back: 1.0, tint: this.tint, intensity: 1.35 });
    this.tail2 = new Ribbon(this.scene, { n: 18, seg: 0.3, width: 0.4, hue: 0.15, mix: 0.4, wave: 1.0, rise: 0.15, back: 1.1, tint: this.tint, intensity: 1.3 });
    this.ribbonsAir = [this.mane, this.mane2, this.tail, this.tail2];
  }

  // ---- mermaid -----------------------------------------------------------------
  _buildMermaid() {
    const W = this.water = new THREE.Group();
    const body = new THREE.Group(); W.add(body); this.mBodyG = body;
    const torso = mk(new THREE.CapsuleGeometry(0.27, 0.65, 8, 16), this.mSkin, 0, 0, 0); torso.rotation.x = Math.PI / 2; body.add(torso);
    // shell top
    for (const sx of [-1, 1]) {
      const sh = mk(new THREE.SphereGeometry(0.17, 12, 10), this.mShell, sx * 0.13, 0.17, -0.28); sh.scale.set(1, 0.8, 1); body.add(sh);
    }
    // head
    const head = new THREE.Group(); head.position.set(0, 0.16, -0.85); body.add(head); this.mHead = head;
    head.add(mk(new THREE.SphereGeometry(0.25, 18, 14), this.mSkin));
    for (const sx of [-1, 1]) {
      head.add(mk(new THREE.SphereGeometry(0.045, 10, 8), this.mEye, sx * 0.1, 0.02, -0.21, false));
      head.add(mk(new THREE.SphereGeometry(0.015, 8, 8), this.mEyeHi, sx * 0.11, 0.04, -0.245, false));
      const bl = new THREE.Mesh(new THREE.CircleGeometry(0.045, 12), new THREE.MeshBasicMaterial({ color: 0xff8fc8, transparent: true, opacity: 0.6 }));
      bl.position.set(sx * 0.15, -0.05, -0.2); bl.rotation.y = sx * 0.9; head.add(bl);
    }
    // hair cap + tiara
    this.mHairMat = new THREE.MeshPhysicalMaterial({ color: 0xff7ac8, roughness: 0.4, clearcoat: 0.8, emissive: 0xff7ac8, emissiveIntensity: 0.3 });
    const cap = mk(new THREE.SphereGeometry(0.275, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.62), this.mHairMat, 0, 0.03, 0.04); cap.rotation.x = -0.35; head.add(cap);
    const tiara = mk(new THREE.ConeGeometry(0.05, 0.2, 5), this.mShell, 0, 0.3, -0.12, false); head.add(tiara);
    // arms swept back
    this.arms = [];
    for (const sx of [-1, 1]) {
      const a = new THREE.Group(); a.position.set(sx * 0.27, 0.05, -0.45);
      const arm = mk(new THREE.CapsuleGeometry(0.075, 0.5, 4, 8), this.mSkin, 0, 0, 0.3);
      arm.rotation.x = Math.PI / 2; a.add(arm);
      body.add(a); this.arms.push({ g: a, side: sx });
    }

    // iridescent tail: 8 tapering segments
    this.tailSegs = [];
    for (let i = 0; i < 8; i++) {
      const f = i / 7;
      const r = lerp(0.3, 0.07, Math.pow(f, 0.9));
      const m = mk(new THREE.SphereGeometry(1, 14, 10), this.mScale); m.scale.set(r, r * 1.05, 0.34);
      body.add(m); this.tailSegs.push({ m, f, r });
    }
    this.tailEnd = new THREE.Group(); body.add(this.tailEnd);
    this.fluke = new THREE.Mesh(FLUKE_G, this.flukeMat); this.fluke.scale.setScalar(0.75); this.fluke.renderOrder = 5;
    this.tailEnd.add(this.fluke);
    // dorsal fin
    this.dorsal = new THREE.Mesh(FIN_G, this.finMat); this.dorsal.scale.setScalar(0.28); this.dorsal.rotation.z = Math.PI / 2; this.dorsal.renderOrder = 5; body.add(this.dorsal);

    // water-butterfly fins (shimmering wings made of water)
    this.wWings = makeWingPair(WING_G, this.finMat, 0.78, new THREE.Vector3(0, 0.22, -0.5));
    W.add(this.wWings.pivotR, this.wWings.pivotL);

    this.hairA = new Ribbon(this.scene, { n: 16, seg: 0.3, width: 0.36, hue: 0.5, mix: 0.45, wave: 1.0, rise: 0.1, back: 1.4, tint: this.tint, intensity: 1.5 });
    this.hairB = new Ribbon(this.scene, { n: 14, seg: 0.28, width: 0.28, hue: 0.8, mix: 0.45, wave: 1.2, rise: 0.15, back: 1.5, tint: this.tint });
    this.ribbonsWater = [this.hairA, this.hairB];
    this.ribbonsWater.forEach((r) => r.setVisible(false));
  }

  // ---- morph effect objects -------------------------------------------------------
  _buildMorphFx() {
    this.orb = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 16), new THREE.ShaderMaterial({
      uniforms: { uColor: { value: new THREE.Color(1, 1, 1) }, uAmt: { value: 0 } },
      vertexShader: `varying vec3 vN; varying vec3 vV; void main(){ vec4 mv = modelViewMatrix*vec4(position,1.); vN = normalize(normalMatrix*normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix*mv; }`,
      fragmentShader: `precision highp float; uniform vec3 uColor; uniform float uAmt; varying vec3 vN; varying vec3 vV;
        void main(){ float f = pow(1.0 - abs(dot(normalize(vN), normalize(vV))), 1.6); gl_FragColor = vec4(uColor * (0.5 + f * 2.2) * uAmt, uAmt * (0.25 + f * 0.75)); }`,
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending
    }));
    this.orb.visible = false; this.orb.renderOrder = 8;
    this.rig.add(this.orb);
    this.ring = new THREE.Mesh(new THREE.RingGeometry(0.85, 1.0, 64), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide }));
    this.ring.rotation.x = -Math.PI / 2; this.ring.visible = false; this.ring.renderOrder = 8;
    this.scene.add(this.ring);
  }

  // ---- control -----------------------------------------------------------------------
  setTint(hex) { this.tintTarget.set(hex); }

  reset(x, y, z) {
    this.rig.position.set(x, y, z);
    this.inWater = false; this.morph = 1;
    this.air.visible = true; this.water.visible = false;
    this.air.scale.setScalar(1); this.water.scale.setScalar(0.001);
    this.orb.visible = false; this.ring.visible = false;
    this.ribbonsAir.forEach((r) => r.setVisible(true)); this.ribbonsWater.forEach((r) => r.setVisible(false));
    this._ribbonsInit = false;
  }

  startMorph(toWater) {
    if (toWater === this.inWater) return;
    this.inWater = toWater;
    this.morph = 0;
    this.air.visible = true; this.water.visible = true;
    this.orb.visible = true; this.ring.visible = true;
    const r = this.ring; r.position.set(this.rig.position.x, (toWater ? WATER_LEVEL : this.rig.position.y - 0.4) + 0.05, this.rig.position.z);
    // both ribbon sets run during the cross-fade
    this.ribbonsAir.forEach((rb) => rb.setVisible(true)); this.ribbonsWater.forEach((rb) => rb.setVisible(true));
    this._morphDir = toWater;
  }

  // ---- per-frame ------------------------------------------------------------------------
  update(dt, time, { speed, boost, vx, targetY, y }) {
    this.t = time;
    const rig = this.rig;
    this.vx = vx;
    // tint blend
    this.tint.lerp(this.tintTarget, 1 - Math.exp(-6 * dt));
    this.tint.getHSL(this._hsl);
    this.wingA.copy(this.tint);
    this.wingB.setHSL((this._hsl.h + 0.13) % 1, Math.min(1, this._hsl.s + 0.1), Math.min(0.78, this._hsl.l + 0.12));
    this.wingMat.uniforms.uA.value.copy(this.wingA); this.wingMat.uniforms.uB.value.copy(this.wingB);
    this.finMat.uniforms.uA.value.lerpColors(this.wingA, C_AQUA, 0.45);
    this.finMat.uniforms.uB.value.copy(this.wingB);
    this.flukeMat.uniforms.uA.value.lerpColors(this.wingA, C_TEAL, 0.35);
    this.flukeMat.uniforms.uB.value.copy(this.wingB);
    this.mBody.emissive.copy(this.tint); this.mBody.sheenColor.copy(this.tint);
    this.mHairMat.color.copy(this.tint); this.mHairMat.emissive.copy(this.tint);
    this.mScale.color.lerpColors(this.tint, C_MINT, 0.5);

    // morph progress
    if (this.morph < 1) this.morph = Math.min(1, this.morph + dt / 0.85);
    const m = this.morph;
    const e = smooth(0, 1, m);
    const toW = this._morphDir;
    if (m < 1) {
      const out = toW ? this.air : this.water, inn = toW ? this.water : this.air;
      // outgoing shrinks with a spin; incoming grows with overshoot
      const so = 1 - smooth(0.0, 0.55, m), si = smooth(0.35, 1.0, m);
      const over = 1 + Math.sin(si * Math.PI) * 0.18;
      out.scale.setScalar(Math.max(0.001, so)); inn.scale.setScalar(Math.max(0.001, si * over));
      out.rotation.y = (1 - so) * 3.2 * (toW ? 1 : -1); inn.rotation.y = (1 - si) * -3.2 * (toW ? 1 : -1);
      const glow = Math.sin(Math.min(1, m * 1.15) * Math.PI);
      this.orb.material.uniforms.uAmt.value = glow * 0.85;
      this.orb.material.uniforms.uColor.value.copy(this.tint).lerp(C_WHITE, 0.45);
      const os = 1.0 + glow * 1.6; this.orb.scale.set(os * 1.2, os, os * 1.5);
      this.orb.position.set(0, toW ? 1.1 : 0.2, 0);
      // expanding ring
      this.ring.material.opacity = (1 - m) * 0.9; this.ring.material.color.copy(this.tint).lerp(C_WHITE, 0.5);
      this.ring.scale.setScalar(1 + m * 9);
      // spiral of sparkles
      const n = 5;
      for (let i = 0; i < n; i++) {
        const a = time * 14 + i * 1.256, h = Math.random() * 2.2;
        const rad = 1.4 * (1 - m * 0.4);
        this.particles.emit(rig.position.x + Math.cos(a) * rad, rig.position.y + h, rig.position.z + Math.sin(a) * rad,
          -Math.sin(a) * 2, 1.5 + Math.random() * 2, Math.cos(a) * 2,
          0.8 + this.tint.r * 0.6, 0.8 + this.tint.g * 0.6, 0.9 + this.tint.b * 0.6, 0.38, 0.9, { star: 1, drag: 1.5 });
      }
      if (m >= 1) {
        out.visible = false; out.scale.setScalar(0.001); out.rotation.y = 0;
        inn.scale.setScalar(1); inn.rotation.y = 0;
        this.orb.visible = false; this.ring.visible = false;
        (toW ? this.ribbonsAir : this.ribbonsWater).forEach((rb) => rb.setVisible(false));
      }
    }

    // steering pose
    const bank = clamp(-vx * 0.05, -0.55, 0.55);
    rig.rotation.z = damp(rig.rotation.z, bank, 10, dt);
    rig.rotation.y = damp(rig.rotation.y, clamp(-vx * 0.022, -0.35, 0.35), 8, dt);
    // vertical placement (smooth between forms)
    const ty = targetY;
    rig.position.y = damp(rig.position.y, ty, this.inWater ? 7 : 6, dt);

    const boostK = boost ? 1 : 0;
    this.flap += dt * (9 + speed * 0.12 + boostK * 8);
    this.gallop += dt * (6.2 + speed * 0.1 + boostK * 3);
    this.swim += dt * (7 + speed * 0.08 + boostK * 4);

    // ---- unicorn pose ----
    if (this.air.visible) {
      const ff = Math.sin(this.flap);
      const lift = 0.55 + ff * 0.5;
      this.uWings.pivotR.rotation.z = lift; this.uWings.pivotL.rotation.z = -lift;
      this.uWings.pivotR.rotation.y = -0.15 + ff * 0.12; this.uWings.pivotL.rotation.y = 0.15 - ff * 0.12;
      this.uBody.position.y = Math.sin(this.gallop * 2) * 0.05;
      this.uBody.rotation.x = Math.sin(this.gallop * 2 + 0.6) * 0.035 - boostK * 0.05;
      this.uHead.rotation.x = -0.1 + Math.sin(this.gallop * 2 + 1.2) * 0.07;
      for (const L of this.legs) {
        const ph = this.gallop + (L.front ? 0 : 1.6) + (L.side > 0 ? 0.5 : 0);
        L.hip.rotation.x = Math.sin(ph) * 0.85 - 0.25;
        L.knee.rotation.x = Math.max(0, -Math.sin(ph + 1.1)) * 1.3 + 0.15;
      }
    }
    // ---- mermaid pose ----
    if (this.water.visible) {
      const fw = Math.sin(this.flap * 0.8);
      this.wWings.pivotR.rotation.z = 0.7 + fw * 0.5; this.wWings.pivotL.rotation.z = -(0.7 + fw * 0.5);
      this.mBodyG.rotation.x = 0.05 + Math.sin(this.swim * 0.9) * 0.05 - boostK * 0.1;
      this.mHead.rotation.x = -0.05 + Math.sin(this.swim) * 0.05;
      for (const a of this.arms) { a.g.rotation.y = a.side * (0.45 + Math.sin(this.swim + a.side) * 0.18); a.g.rotation.z = a.side * -0.1; }
      // undulating tail (travelling wave, vertical)
      let z = 0.52, prevY = 0;
      for (let i = 0; i < this.tailSegs.length; i++) {
        const s = this.tailSegs[i];
        const amp = 0.04 + s.f * 0.34;
        const yy = Math.sin(this.swim * 1.15 - i * 0.62) * amp;
        s.m.position.set(0, yy, z);
        s.m.rotation.x = Math.atan2(yy - prevY, 0.34) * 0.9;
        prevY = yy; z += 0.34 * (1 - s.f * 0.12);
      }
      this.tailEnd.position.set(0, prevY, z - 0.1);
      this.tailEnd.rotation.x = Math.sin(this.swim * 1.15 - 8 * 0.62 + 0.6) * 0.55;
      this.dorsal.position.set(0, 0.28, 0.55);
    }

    // ribbons follow anchor points (world space)
    this._updateRibbons(dt, time);
  }

  _anchor(obj, offset, out) {
    out.copy(offset); obj.localToWorld(out); return out;
  }

  _updateRibbons(dt, time) {
    const v = this._v || (this._v = new THREE.Vector3());
    const A = this._anch || (this._anch = Array.from({ length: 6 }, () => new THREE.Vector3()));
    const sideV = this._side || (this._side = new THREE.Vector3(1, 0, 0));
    this.rig.updateMatrixWorld(true);
    if (!this._ribbonsInit) {
      this._ribbonsInit = true;
      for (const r of this.ribbonsAir.concat(this.ribbonsWater)) r.reset(this.rig.position);
    }
    if (this.air.visible) {
      const amt = this.air.scale.x > 0.05 ? Math.min(1, this.air.scale.x) : 0;
      this.mane.update(dt, this._anchor(this.uBody, v.set(0.05, 2.1, -1.1), A[0]), this.t, sideV, amt);
      this.mane2.update(dt, this._anchor(this.uBody, v.set(-0.05, 2.0, -0.95), A[1]), this.t, sideV, amt);
      this.tail.update(dt, this._anchor(this.uBody, v.set(0, 1.3, 1.0), A[2]), this.t, sideV, amt);
      this.tail2.update(dt, this._anchor(this.uBody, v.set(0.05, 1.2, 0.95), A[3]), this.t, sideV, amt);
    }
    if (this.water.visible) {
      const amt = this.water.scale.x > 0.05 ? Math.min(1, this.water.scale.x) : 0;
      this.hairA.update(dt, this._anchor(this.mHead, v.set(0.05, 0.1, 0.25), A[4]), this.t, sideV, amt);
      this.hairB.update(dt, this._anchor(this.mHead, v.set(-0.06, 0.08, 0.22), A[5]), this.t, sideV, amt);
    }
  }

  // world-space points for trail particles
  hornWorldInto(v) { return this.hornTip.getWorldPosition(v); }

  setShadow(on) { this.shadowMeshes.forEach((m) => { m.castShadow = on; }); }
}
