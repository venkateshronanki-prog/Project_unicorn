// ---------------------------------------------------------------------------
// Project Butterfly — central configuration
// Everything tunable lives here so the game is easy to extend.
// ---------------------------------------------------------------------------

// Paste your Firebase web-app config here to switch on cloud saves
// (username accounts + leaderboard). Leave as null to play with local saves only.
// See README.md → "Step 4: Firebase" for exactly where to get these values.
export const FIREBASE_CONFIG = null;
/* Example:
export const FIREBASE_CONFIG = {
  apiKey: "AIza...",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef"
};
*/

export const VERSION = '1.0.0';

// ----- Gameplay -------------------------------------------------------------
export const PATH_HALF_WIDTH = 6.2;     // half width of the glowing runway
export const STEER_LIMIT = 5.2;         // max |x| for the player
export const BASE_SPEED = 26;           // units / second at level 1
export const SPEED_PER_LEVEL = 1.8;
export const MAX_SPEED = 46;
export const BOOST_MULT = 1.6;
export const BOOST_DRAIN = 0.34;        // energy / second while boosting
export const BOOST_REGEN = 0.09;        // energy / second otherwise
export const LEVEL_LENGTH = 1400;       // metres per level (also the checkpoint distance)
export const START_HEARTS = 3;
export const COMPANION_LIFETIME = 28;   // seconds the baby follows you
export const FIRST_COMPANION_AT = 7;    // seconds into a run

// ----- Water zones ----------------------------------------------------------
export const WATER_FIRST_AT = 380;      // metres until the first water zone
export const WATER_PERIOD = 640;        // distance between zone starts
export const WATER_LENGTH = 190;        // length of each zone
export const WATER_BLEND = 34;          // ramp length in/out
export const WATER_LEVEL = -0.85;
export const WATER_DEPTH = 3.4;         // how far the path sinks under the water

// ----- World streaming ------------------------------------------------------
export const CHUNK_LEN = 80;
export const CHUNK_COUNT = 7;           // chunks alive at once
export const CHUNK_BEHIND = 1;          // chunks kept behind the player

// ----- Colour system --------------------------------------------------------
export const COLORS = [
  { id: 'rose',   name: 'Rose Quartz',   hex: 0xff4fa3, note: 0 },
  { id: 'gold',   name: 'Sunbeam Gold',  hex: 0xffc83a, note: 2 },
  { id: 'aqua',   name: 'Aqua Dream',    hex: 0x22e3d2, note: 4 },
  { id: 'violet', name: 'Starlit Violet',hex: 0xa05cff, note: 7 },
  { id: 'lime',   name: 'Meadow Mint',   hex: 0x5cff8f, note: 9 },
  { id: 'sky',    name: 'Sky Opal',      hex: 0x4aa8ff, note: 12 }
];

// ----- Level palettes (sky + fog + light) ----------------------------------
// Each level blends smoothly into the next as you run.
export const LEVELS = [
  { name: 'Dawn Meadow',     top: 0x5b7cff, mid: 0xff9ad5, low: 0xffe6b8, fog: 0xffd9e8, sun: 0xfff0d0, grass: 0x86e6a0, grass2: 0xffd0e8 },
  { name: 'Crystal Lake',    top: 0x2d8bff, mid: 0x7fe3ff, low: 0xd7fbff, fog: 0xbff3ff, sun: 0xffffff, grass: 0x60e8c0, grass2: 0xb7f0ff },
  { name: 'Golden Bloom',    top: 0xff7f6a, mid: 0xffc36b, low: 0xfff0b8, fog: 0xffe0a8, sun: 0xffe2a0, grass: 0xc8f07a, grass2: 0xffe08a },
  { name: 'Twilight Glade',  top: 0x2b1b7a, mid: 0xb15cff, low: 0xff9fd0, fog: 0xc7a2ff, sun: 0xffc2f0, grass: 0x7fa8ff, grass2: 0xd69cff },
  { name: 'Starlight Reef',  top: 0x0c1450, mid: 0x2f6bff, low: 0x6ff0ff, fog: 0x5a8dff, sun: 0xa8d8ff, grass: 0x3fd9d0, grass2: 0x8a7cff }
];

// ----- Quality tiers --------------------------------------------------------
// 0 = low, 1 = medium, 2 = high, 3 = ultra
export const QUALITY = [
  { name: 'Low',    dpr: 1.0,  bloom: false, shadows: 0,    msaa: 0, scenery: 0.45, particles: 0.4 },
  { name: 'Medium', dpr: 1.35, bloom: true,  shadows: 0,    msaa: 0, scenery: 0.7,  particles: 0.7 },
  { name: 'High',   dpr: 1.75, bloom: true,  shadows: 1024, msaa: 2, scenery: 1.0,  particles: 1.0 },
  { name: 'Ultra',  dpr: 2.0,  bloom: true,  shadows: 2048, msaa: 4, scenery: 1.0,  particles: 1.0 }
];
