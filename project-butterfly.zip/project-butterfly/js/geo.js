// Shared materials and geometry helpers.
import * as THREE from '../vendor/three.bundle.js';

// Fog uniforms shared by every custom shader so the whole world fades consistently.
export const fogU = {
  uFogColor: { value: new THREE.Color(0xffd9e8) },
  uFogDensity: { value: 0.0075 }
};

export const timeU = { value: 0 };

const FOG_GLSL = /* glsl */`
  uniform vec3 uFogColor; uniform float uFogDensity;
  vec3 applyFog(vec3 c, float dist) {
    float f = 1.0 - exp(-pow(dist * uFogDensity, 2.0));
    return mix(c, uFogColor, clamp(f, 0.0, 1.0));
  }
`;
export { FOG_GLSL };

// Emissive "glow" material used for orbs, crystals, flowers, gates, obstacles.
// Supports instanceColor and vertex colours, fresnel rim and HDR intensity (so bloom picks it up).
export function glowMaterial({ intensity = 1.5, rim = 1.2, rimPower = 2.5, useVertexColor = false, opacity = 1, pulse = 0, additive = false, shade = 0.35 } = {}) {
  const m = new THREE.ShaderMaterial({
    uniforms: {
      ...fogU, uTime: timeU,
      uIntensity: { value: intensity }, uRim: { value: rim }, uRimPower: { value: rimPower },
      uOpacity: { value: opacity }, uPulse: { value: pulse }, uShade: { value: shade },
      uSun: { value: new THREE.Vector3(0.25, 0.4, -0.9).normalize() }
    },
    vertexShader: /* glsl */`
      varying vec3 vN; varying vec3 vV; varying vec3 vCol; varying float vDist; varying float vPh;
      ${useVertexColor ? 'attribute vec3 color;' : ''}
      void main() {
        vec3 base = vec3(1.0);
        #ifdef USE_INSTANCING_COLOR
          base = instanceColor;
        #endif
        ${useVertexColor ? 'base *= color;' : ''}
        vCol = base;
        mat4 m = modelViewMatrix;
        #ifdef USE_INSTANCING
          m = modelViewMatrix * instanceMatrix;
          vPh = instanceMatrix[3].x * 0.37 + instanceMatrix[3].z * 0.21;
        #else
          vPh = 0.0;
        #endif
        vec4 mv = m * vec4(position, 1.0);
        vN = normalize(mat3(m) * normal);
        vV = normalize(-mv.xyz);
        vDist = length(mv.xyz);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: /* glsl */`
      precision highp float;
      uniform float uIntensity, uRim, uRimPower, uOpacity, uPulse, uTime, uShade;
      uniform vec3 uSun;
      varying vec3 vN; varying vec3 vV; varying vec3 vCol; varying float vDist; varying float vPh;
      ${FOG_GLSL}
      void main() {
        vec3 n = normalize(vN);
        float fres = pow(1.0 - clamp(dot(n, normalize(vV)), 0.0, 1.0), uRimPower);
        float lit = 0.65 + 0.35 * dot(n, vec3(0.3, 0.8, 0.5));
        float pulse = 1.0 + uPulse * sin(uTime * 3.0 + vPh * 6.0);
        vec3 c = vCol * mix(1.0, lit, uShade) * uIntensity * pulse;
        c += mix(vCol, vec3(1.0), 0.55) * fres * uRim;
        c = applyFog(c, vDist);
        gl_FragColor = vec4(c, uOpacity);
      }`,
    transparent: opacity < 1 || additive,
    depthWrite: !(opacity < 1 || additive),
    blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending
  });
  return m;
}

export function setInstanceColor(mesh, i, r, g, b) {
  if (!mesh.instanceColor) {
    mesh.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(mesh.instanceMatrix.count * 3), 3);
  }
  mesh.instanceColor.setXYZ(i, r, g, b);
}

const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _s = new THREE.Vector3(), _p = new THREE.Vector3(), _e = new THREE.Euler();
export function setInstance(mesh, i, x, y, z, sx = 1, sy = sx, sz = sx, rx = 0, ry = 0, rz = 0) {
  _p.set(x, y, z); _s.set(sx, sy, sz); _e.set(rx, ry, rz); _q.setFromEuler(_e);
  _m.compose(_p, _q, _s);
  mesh.setMatrixAt(i, _m);
}

// Paint a whole geometry with a single vertex colour (for merged geometry).
export function paint(geo, color) {
  const c = new THREE.Color(color);
  const n = geo.attributes.position.count;
  const arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { arr[i * 3] = c.r; arr[i * 3 + 1] = c.g; arr[i * 3 + 2] = c.b; }
  geo.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  return geo;
}

export function merge(list) {
  const prepared = list.map((g) => (g.index ? g.toNonIndexed() : g));
  prepared.forEach((g) => { if (!g.attributes.color) paint(g, 0xffffff); g.deleteAttribute('uv'); });
  return THREE.mergeGeometries(prepared, false);
}

// Spiky crystal cluster used for obstacles and decorative crystals.
export function crystalGeometry(spikes = 5, scale = 1, spread = 0.8, seed = 3) {
  const parts = [];
  let s = seed;
  const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  for (let i = 0; i < spikes; i++) {
    const h = (i === 0 ? 3.2 : 1.6 + r() * 1.6) * scale;
    const rad = (i === 0 ? 0.62 : 0.3 + r() * 0.22) * scale;
    const g = new THREE.ConeGeometry(rad, h, 5, 1);
    g.translate(0, h / 2, 0);
    const a = r() * Math.PI * 2, d = i === 0 ? 0 : spread * (0.5 + r() * 0.7) * scale;
    g.rotateZ((r() - 0.5) * (i === 0 ? 0.1 : 0.7));
    g.rotateY(r() * 6.28);
    g.translate(Math.cos(a) * d, 0, Math.sin(a) * d);
    parts.push(g);
  }
  return merge(parts);
}

// Wing / fin geometry: a triangle fan from a root vertex to an outline.
// Each vertex carries aEdge (0 at the root → 1 on the outline) and aAng (0..1 along the outline)
// so the fragment shader can draw veins, eye-spots and borders procedurally.
export function fanGeometry(shape, steps = 40, root = new THREE.Vector2(0.1, 0)) {
  const pts = shape.getPoints(steps);
  if (pts.length > 2 && pts[0].distanceTo(pts[pts.length - 1]) < 1e-4) pts.pop();
  const n = pts.length;
  const pos = new Float32Array((n + 1) * 3);
  const edge = new Float32Array(n + 1);
  const ang = new Float32Array(n + 1);
  pos[0] = root.x; pos[1] = 0; pos[2] = -root.y; edge[0] = 0; ang[0] = 0.5;
  for (let i = 0; i < n; i++) {
    // XY outline (x out, y forward) → XZ plane with forward = -Z
    pos[(i + 1) * 3] = pts[i].x; pos[(i + 1) * 3 + 1] = 0; pos[(i + 1) * 3 + 2] = -pts[i].y;
    edge[i + 1] = 1; ang[i + 1] = i / (n - 1);
  }
  const idx = [];
  for (let i = 0; i < n; i++) idx.push(0, 1 + i, 1 + ((i + 1) % n));
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('aEdge', new THREE.BufferAttribute(edge, 1));
  g.setAttribute('aAng', new THREE.BufferAttribute(ang, 1));
  g.setIndex(idx);
  // normals face up so lighting-free shader can still use a facing term
  const nrm = new Float32Array((n + 1) * 3);
  for (let i = 0; i <= n; i++) nrm[i * 3 + 1] = 1;
  g.setAttribute('normal', new THREE.BufferAttribute(nrm, 3));
  return g;
}

export function wingMaterial({ colorA, colorB, intensity = 1.6, style = 0 }) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uTime: timeU,
      uA: { value: new THREE.Color(colorA) },
      uB: { value: new THREE.Color(colorB) },
      uIntensity: { value: intensity },
      uStyle: { value: style },       // 0 = butterfly wing, 1 = fin / fluke
      uAlpha: { value: 1 }
    },
    vertexShader: /* glsl */`
      attribute float aEdge; attribute float aAng;
      varying float vEdge; varying float vAng;
      void main() { vEdge = aEdge; vAng = aAng; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
    fragmentShader: /* glsl */`
      precision highp float;
      uniform vec3 uA, uB; uniform float uTime, uIntensity, uStyle, uAlpha;
      varying float vEdge; varying float vAng;
      void main() {
        float e = vEdge, a = vAng;
        vec3 irid = 0.5 + 0.5 * cos(6.2831 * (e * 0.9 + a * 0.35 + uTime * 0.12 + vec3(0.0, 0.33, 0.67)));
        vec3 col = mix(uA, uB, smoothstep(0.1, 1.0, e));
        col = mix(col, col * (0.55 + irid), 0.45);
        // veins
        float vein = smoothstep(0.93, 1.0, abs(sin(a * 62.8)));
        if (uStyle > 0.5) vein = smoothstep(0.9, 1.0, abs(sin(a * 40.0 + e * 5.0)));
        col += vein * 0.35 * (1.0 - e * 0.6);
        // eye-spots
        vec2 q1 = vec2((a - 0.2) * 3.4, e - 0.64);
        vec2 q2 = vec2((a - 0.66) * 3.4, e - 0.58);
        float s1 = length(q1 * vec2(1.0, 2.4)), s2 = length(q2 * vec2(1.0, 2.4));
        float spot = (1.0 - smoothstep(0.1, 0.16, s1)) + (1.0 - smoothstep(0.08, 0.13, s2));
        float ring = (smoothstep(0.1, 0.16, s1) * (1.0 - smoothstep(0.16, 0.22, s1)) + smoothstep(0.08, 0.13, s2) * (1.0 - smoothstep(0.13, 0.19, s2)));
        if (uStyle < 0.5) { col = mix(col, vec3(0.08, 0.03, 0.2), spot * 0.8); col += ring * vec3(1.0, 0.95, 0.8) * 0.9; col += spot * uB * 0.9; }
        // border with white dots
        float border = smoothstep(0.86, 0.93, e);
        float dots = step(0.5, fract(a * 54.0)) * smoothstep(0.93, 0.95, e) * (1.0 - smoothstep(0.985, 1.0, e));
        col = mix(col, vec3(0.1, 0.04, 0.18), border * 0.5 * (1.0 - uStyle));
        col += dots * vec3(1.2, 1.2, 1.3) * (1.0 - uStyle);
        // glow near the root
        col += (1.0 - smoothstep(0.0, 0.4, e)) * 0.5 * uB;
        float alpha = smoothstep(1.0, 0.82, e) * 0.38 + 0.62;
        alpha = mix(alpha, 0.8 * (1.0 - smoothstep(0.7, 1.0, e)) + 0.2, uStyle);
        gl_FragColor = vec4(col * uIntensity, alpha * uAlpha);
      }`,
    transparent: true, depthWrite: false, side: THREE.DoubleSide
  });
}
