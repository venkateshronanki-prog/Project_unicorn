// GPU point-sprite particle system (sparkles, bursts, splashes, motes).
// One draw call, ring-buffer pooled, CPU simulated for simplicity.
import * as THREE from '../vendor/three.bundle.js';

const VERT = /* glsl */`
  attribute float aSize;
  attribute float aAlpha;
  attribute vec3 aColor;
  attribute float aKind;
  uniform float uScale;
  varying vec3 vColor;
  varying float vAlpha;
  varying float vKind;
  void main() {
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_Position = projectionMatrix * mv;
    gl_PointSize = clamp(aSize * uScale / max(0.1, -mv.z), 0.0, 220.0);
    vColor = aColor; vAlpha = aAlpha; vKind = aKind;
  }
`;
const FRAG = /* glsl */`
  precision highp float;
  varying vec3 vColor;
  varying float vAlpha;
  varying float vKind;
  void main() {
    vec2 p = gl_PointCoord - 0.5;
    float d = length(p);
    if (d > 0.5) discard;
    float glow = pow(max(0.0, 1.0 - d * 2.0), 2.2);
    float core = smoothstep(0.16, 0.0, d);
    float star = 0.0;
    if (vKind > 0.5) {
      float cross = max(0.0, 1.0 - 26.0 * min(abs(p.x), abs(p.y)));
      star = cross * max(0.0, 1.0 - d * 2.0);
      float diag = max(0.0, 1.0 - 26.0 * min(abs(p.x + p.y), abs(p.x - p.y)) * 0.7);
      star += diag * 0.5 * max(0.0, 1.0 - d * 2.0);
    }
    float a = (glow * 0.85 + core * 0.9 + star) * vAlpha;
    gl_FragColor = vec4(vColor * a, a);
  }
`;

export class Particles {
  constructor(scene, max = 2400) {
    this.max = max;
    this.cursor = 0;
    this.limit = max; // quality scalable
    this.pos = new Float32Array(max * 3);
    this.vel = new Float32Array(max * 3);
    this.col = new Float32Array(max * 3);
    this.size = new Float32Array(max);
    this.sizeBase = new Float32Array(max);
    this.alpha = new Float32Array(max);
    this.kind = new Float32Array(max);
    this.life = new Float32Array(max);
    this.maxLife = new Float32Array(max);
    this.grav = new Float32Array(max);
    this.drag = new Float32Array(max);
    this.grow = new Float32Array(max);

    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aColor', new THREE.BufferAttribute(this.col, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aSize', new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aAlpha', new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aKind', new THREE.BufferAttribute(this.kind, 1));
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5);
    this.geo = g;
    this.mat = new THREE.ShaderMaterial({
      uniforms: { uScale: { value: 600 } },
      vertexShader: VERT, fragmentShader: FRAG,
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending
    });
    this.points = new THREE.Points(g, this.mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 10;
    scene.add(this.points);
    for (let i = 0; i < max; i++) { this.pos[i * 3 + 1] = -9999; this.life[i] = 0; }
  }

  setScale(heightPx, fovDeg) {
    this.mat.uniforms.uScale.value = heightPx / (2 * Math.tan(THREE.MathUtils.degToRad(fovDeg) / 2));
  }

  // quality scaling: lower tiers simply reject a fraction of emissions
  emit(x, y, z, vx, vy, vz, r, g, b, size, life, { gravity = 0, drag = 0, star = 0, grow = 0, alpha = 1 } = {}) {
    if (this.limit < this.max && Math.random() > this.limit / this.max) return;
    const i = this.cursor; this.cursor = (this.cursor + 1) % this.max;
    const k = i * 3;
    this.pos[k] = x; this.pos[k + 1] = y; this.pos[k + 2] = z;
    this.vel[k] = vx; this.vel[k + 1] = vy; this.vel[k + 2] = vz;
    this.col[k] = r; this.col[k + 1] = g; this.col[k + 2] = b;
    this.sizeBase[i] = size; this.size[i] = size;
    this.life[i] = life; this.maxLife[i] = life;
    this.grav[i] = gravity; this.drag[i] = drag; this.kind[i] = star; this.grow[i] = grow;
    this.alpha[i] = alpha;
    this._aBase = alpha;
  }

  burst(x, y, z, color, count, speed, size, life, opts = {}) {
    const r = color.r, g = color.g, b = color.b;
    for (let n = 0; n < count; n++) {
      const u = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2;
      const s = Math.sqrt(1 - u * u);
      const sp = speed * (0.4 + Math.random() * 0.8);
      this.emit(x, y, z, s * Math.cos(th) * sp, u * sp, s * Math.sin(th) * sp,
        r, g, b, size * (0.6 + Math.random() * 0.8), life * (0.6 + Math.random() * 0.6),
        { star: Math.random() < 0.45 ? 1 : 0, ...opts });
    }
  }

  update(dt) {
    const n = this.max;
    for (let i = 0; i < n; i++) {
      const l = this.life[i];
      if (l <= 0) { if (this.alpha[i] !== 0) { this.alpha[i] = 0; this.size[i] = 0; } continue; }
      const k = i * 3;
      const nl = l - dt; this.life[i] = nl;
      const d = this.drag[i];
      const damp = d > 0 ? Math.exp(-d * dt) : 1;
      this.vel[k] *= damp; this.vel[k + 1] = this.vel[k + 1] * damp - this.grav[i] * dt; this.vel[k + 2] *= damp;
      this.pos[k] += this.vel[k] * dt; this.pos[k + 1] += this.vel[k + 1] * dt; this.pos[k + 2] += this.vel[k + 2] * dt;
      const t = Math.max(0, nl / this.maxLife[i]);
      this.alpha[i] = t < 0.25 ? t * 4 : 1;
      this.size[i] = this.sizeBase[i] * (this.grow[i] ? (1 + (1 - t) * this.grow[i]) : (0.4 + 0.6 * t));
      if (nl <= 0) { this.alpha[i] = 0; this.size[i] = 0; }
    }
    const a = this.geo.attributes;
    a.position.needsUpdate = true; a.aColor.needsUpdate = true; a.aSize.needsUpdate = true; a.aAlpha.needsUpdate = true; a.aKind.needsUpdate = true;
  }

  clear() { this.life.fill(0); this.alpha.fill(0); this.size.fill(0); }
}

// Expanding glowing rings on the water surface (wake ripples, splash rings).
export class Ripples {
  constructor(scene, n = 10) {
    this.items = [];
    const geo = new THREE.RingGeometry(0.86, 1.0, 56); geo.rotateX(-Math.PI / 2);
    for (let i = 0; i < n; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
      const m = new THREE.Mesh(geo, mat); m.visible = false; m.renderOrder = 4; m.frustumCulled = false;
      scene.add(m); this.items.push({ m, t: 1, life: 1, size: 1 });
    }
    this.cursor = 0;
  }
  spawn(x, y, z, color, size = 6, life = 1.1, opacity = 0.7) {
    const it = this.items[this.cursor]; this.cursor = (this.cursor + 1) % this.items.length;
    it.t = 0; it.life = life; it.size = size; it.op = opacity;
    it.m.position.set(x, y, z); it.m.material.color.copy(color); it.m.visible = true; it.m.scale.setScalar(0.3);
  }
  update(dt) {
    for (const it of this.items) {
      if (!it.m.visible) continue;
      it.t += dt / it.life;
      if (it.t >= 1) { it.m.visible = false; continue; }
      const k = it.t;
      it.m.scale.setScalar(0.3 + k * it.size);
      it.m.material.opacity = (1 - k) * (1 - k) * it.op;
    }
  }
}
