// Haptics: Android/desktop via navigator.vibrate, iOS Safari 17.4+ via the
// native <input type="checkbox" switch> trick (toggling it fires a system tick).
import { isIOS } from './util.js';

export class Haptics {
  constructor() {
    this.enabled = true;
    this._label = null;
    this._input = null;
    this._last = 0;
    if (isIOS) this._buildIOS();
  }

  _buildIOS() {
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.setAttribute('switch', '');
    input.id = 'haptic-switch';
    input.style.cssText = 'position:fixed;left:-100px;top:-100px;opacity:0;pointer-events:none;';
    const label = document.createElement('label');
    label.htmlFor = 'haptic-switch';
    label.style.cssText = 'position:fixed;left:-100px;top:-100px;opacity:0;pointer-events:none;';
    document.body.appendChild(input);
    document.body.appendChild(label);
    this._input = input; this._label = label;
  }

  _tickIOS() {
    // Label click toggles the switch which produces a light haptic tick.
    try { this._label.click(); } catch (e) { /* ignore */ }
  }

  // pattern: ms or array of ms. For iOS we approximate with 1–3 ticks.
  play(pattern = 12) {
    if (!this.enabled) return;
    const now = performance.now();
    if (now - this._last < 30) return;
    this._last = now;
    if (isIOS) {
      const arr = Array.isArray(pattern) ? pattern : [pattern];
      const n = Math.min(3, Math.max(1, Math.round(arr.filter((_, i) => i % 2 === 0).length)));
      this._tickIOS();
      for (let i = 1; i < n; i++) setTimeout(() => this._tickIOS(), i * 70);
    } else if (navigator.vibrate) {
      try { navigator.vibrate(pattern); } catch (e) { /* ignore */ }
    }
  }

  tick() { this.play(8); }
  collect() { this.play(14); }
  chain() { this.play([18, 40, 18, 40, 30]); }
  hit() { this.play([40, 30, 60]); }
  morph() { this.play([12, 40, 12, 40, 12]); }
  boost() { this.play(25); }
  levelUp() { this.play([20, 50, 20, 50, 20, 50, 40]); }
}
