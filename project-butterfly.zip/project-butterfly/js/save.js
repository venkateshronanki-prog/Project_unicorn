// Username-based saves. Always saved locally (works fully offline); when Firebase is
// configured the same record is mirrored to Cloud Firestore so a run can be resumed on
// any device (iPhone ⇄ iPad ⇄ desktop) after signing in with the same username.
import { COLORS } from './config.js';

const LAST_USER = 'bf.lastUser';
const userKey = (n) => `bf.user.${n.toLowerCase()}`;

export const defaultSettings = () => ({
  quality: 'auto', music: 0.55, sfx: 0.9, haptics: true, gyro: false, sens: 1.0, fps: false
});

export const defaultData = (name = 'Guest') => ({
  username: name, best: 0, bestDist: 0, maxLevel: 0, totalOrbs: 0, runs: 0,
  colors: Object.fromEntries(COLORS.map((c) => [c.id, 0])),
  run: null,                  // in-progress run for "Continue"
  settings: defaultSettings(),
  updatedAt: 0
});

export function cleanName(raw) {
  return (raw || '').trim().replace(/[^\p{L}\p{N}_\- ]/gu, '').replace(/\s+/g, ' ').slice(0, 16);
}

export class Save {
  constructor() {
    this.data = defaultData();
    this.cloudPush = null;      // set by main: (data) => void
    this._pushTimer = 0;
    this._dirty = false;
    const last = localStorage.getItem(LAST_USER);
    if (last) this.load(last);
  }

  get name() { return this.data.username; }
  get hasUser() { return !!localStorage.getItem(LAST_USER); }

  load(name) {
    let d = null;
    try { d = JSON.parse(localStorage.getItem(userKey(name)) || 'null'); } catch (e) { d = null; }
    this.data = this._merge(defaultData(name), d || {});
    this.data.username = name;
    localStorage.setItem(LAST_USER, name);
    return this.data;
  }

  _merge(base, d) {
    const out = { ...base, ...d };
    out.settings = { ...defaultSettings(), ...(d.settings || {}) };
    out.colors = { ...base.colors, ...(d.colors || {}) };
    return out;
  }

  // Merge a cloud record into the local one: keep the best of everything; newest run wins.
  mergeCloud(c) {
    if (!c) return;
    const d = this.data;
    d.best = Math.max(d.best, c.best || 0);
    d.bestDist = Math.max(d.bestDist, c.bestDist || 0);
    d.maxLevel = Math.max(d.maxLevel, c.maxLevel || 0);
    d.totalOrbs = Math.max(d.totalOrbs, c.totalOrbs || 0);
    d.runs = Math.max(d.runs, c.runs || 0);
    for (const k of Object.keys(d.colors)) d.colors[k] = Math.max(d.colors[k] || 0, (c.colors && c.colors[k]) || 0);
    const cu = c.updatedAt || 0;
    if (cu > (d.updatedAt || 0)) {
      d.run = c.run || null;
      if (c.settings) d.settings = { ...d.settings, ...c.settings };
    }
    this.persist(false);
  }

  persist(push = true) {
    this.data.updatedAt = Date.now();
    try { localStorage.setItem(userKey(this.data.username), JSON.stringify(this.data)); localStorage.setItem(LAST_USER, this.data.username); } catch (e) { /* storage full / private mode */ }
    if (push) this._dirty = true;
  }

  // Throttled cloud push (called every frame cheaply).
  tick(dt, force = false) {
    if (!this._dirty || !this.cloudPush) return;
    this._pushTimer -= dt;
    if (force || this._pushTimer <= 0) { this._pushTimer = 8; this._dirty = false; this.cloudPush(this.data); }
  }

  // ---- game events -----------------------------------------------------------------------
  reachedLevel(level) { if (level > this.data.maxLevel) { this.data.maxLevel = level; } this.persist(); }
  saveRun(run) { this.data.run = run; this.persist(); }
  clearRun() { this.data.run = null; this.persist(); }
  finishRun({ score, dist, orbs, colors }) {
    const d = this.data;
    d.best = Math.max(d.best, Math.floor(score));
    d.bestDist = Math.max(d.bestDist, Math.floor(dist));
    d.totalOrbs += orbs; d.runs += 1;
    for (const k of Object.keys(colors)) d.colors[k] = (d.colors[k] || 0) + colors[k];
    d.run = null;
    this.persist();
    return d;
  }
  setSettings(patch) { Object.assign(this.data.settings, patch); this.persist(); }
}
