// Everything that lives ON the route: colour orbs, obstacles, rainbow gates,
// hearts and Lumi's star-eggs — plus the pattern generator that lays them out.
import * as THREE from '../vendor/three.bundle.js';
import { COLORS, PATH_HALF_WIDTH, WATER_LEVEL, LEVEL_LENGTH } from './config.js';
import { rng, clamp, TAU } from './util.js';
import { glowMaterial, setInstance, setInstanceColor, crystalGeometry, merge, paint, fogU, timeU } from './geo.js';
import { waterFactor, pathY } from './world.js';

const MAX_ORBS = 280, MAX_OBS = 70;
const AHEAD = 280;           // how far in front of the player things are spawned
const LANES = [-3.6, 0, 3.6];
const RAINBOW = [0xff4b6e, 0xff9a3c, 0xffe14a, 0x4aff9a, 0x4ab4ff, 0xa05cff];

const HALO_V = /* glsl */`
  attribute vec3 aColor; attribute float aSize; varying vec3 vC;
  uniform float uScale;
  void main() { vec4 mv = modelViewMatrix * vec4(position, 1.0); gl_Position = projectionMatrix * mv; gl_PointSize = clamp(aSize * uScale / max(0.1, -mv.z), 0.0, 260.0); vC = aColor; }`;
const HALO_F = /* glsl */`
  precision highp float; varying vec3 vC;
  void main() { vec2 p = gl_PointCoord - 0.5; float d = length(p); if (d > 0.5) discard; float g = pow(max(0.0, 1.0 - d * 2.0), 2.4); gl_FragColor = vec4(vC * g * 0.9, g * 0.9); }`;

export class Track {
  constructor(scene, particles, audio, haptics) {
    this.scene = scene; this.particles = particles; this.audio = audio; this.haptics = haptics;

    // ---- orbs ----
    this.orbGeo = new THREE.IcosahedronGeometry(0.5, 2);
    this.orbMat = glowMaterial({ intensity: 2.2, rim: 1.8, rimPower: 2.0, pulse: 0.12, shade: 0.3 });
    this.orbMesh = new THREE.InstancedMesh(this.orbGeo, this.orbMat, MAX_ORBS);
    this.orbMesh.count = 0; this.orbMesh.frustumCulled = false;
    this.orbMesh.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(MAX_ORBS * 3), 3);
    this.orbMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    scene.add(this.orbMesh);
    // halos
    const hg = new THREE.BufferGeometry();
    this.haloPos = new Float32Array(MAX_ORBS * 3); this.haloCol = new Float32Array(MAX_ORBS * 3); this.haloSize = new Float32Array(MAX_ORBS);
    hg.setAttribute('position', new THREE.BufferAttribute(this.haloPos, 3).setUsage(THREE.DynamicDrawUsage));
    hg.setAttribute('aColor', new THREE.BufferAttribute(this.haloCol, 3).setUsage(THREE.DynamicDrawUsage));
    hg.setAttribute('aSize', new THREE.BufferAttribute(this.haloSize, 1).setUsage(THREE.DynamicDrawUsage));
    hg.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);
    this.haloMat = new THREE.ShaderMaterial({ uniforms: { uScale: { value: 600 } }, vertexShader: HALO_V, fragmentShader: HALO_F, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    this.halos = new THREE.Points(hg, this.haloMat); this.halos.frustumCulled = false; this.halos.renderOrder = 7;
    scene.add(this.halos);
    this.orbs = []; this.orbPool = [];

    // ---- obstacles ----
    this.obsGeo = crystalGeometry(5, 1.0, 0.85, 11);
    this.obsMat = glowMaterial({ intensity: 1.0, rim: 2.2, rimPower: 1.8, useVertexColor: true, shade: 0.7, pulse: 0.2 });
    this.obsMesh = new THREE.InstancedMesh(this.obsGeo, this.obsMat, MAX_OBS);
    this.obsMesh.count = 0; this.obsMesh.frustumCulled = false;
    this.obsMesh.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(MAX_OBS * 3), 3);
    scene.add(this.obsMesh);
    this.obstacles = [];

    // ---- gates (rainbow arches) ----
    const arcs = [];
    RAINBOW.forEach((hex, i) => {
      const g = new THREE.TorusGeometry(7.3 - i * 0.34, 0.17, 8, 56, Math.PI);
      paint(g, hex); arcs.push(g);
    });
    this.gateGeo = merge(arcs);
    this.gateMat = glowMaterial({ intensity: 2.2, rim: 0.8, useVertexColor: true, shade: 0.2, pulse: 0.1 });
    this.gates = [];
    for (let i = 0; i < 4; i++) {
      const m = new THREE.Mesh(this.gateGeo, this.gateMat); m.visible = false; m.frustumCulled = false;
      scene.add(m); this.gates.push({ mesh: m, s: 0, active: false, passed: false });
    }

    // ---- hearts & eggs ----
    const hs = new THREE.Shape();
    hs.moveTo(0, -0.5); hs.bezierCurveTo(-0.9, 0.1, -0.5, 0.8, 0, 0.35); hs.bezierCurveTo(0.5, 0.8, 0.9, 0.1, 0, -0.5);
    const hgeo = new THREE.ExtrudeGeometry(hs, { depth: 0.28, bevelEnabled: true, bevelSize: 0.08, bevelThickness: 0.1, bevelSegments: 3, curveSegments: 14 });
    hgeo.center(); hgeo.scale(1.15, 1.15, 1.15);
    this.heartGeo = hgeo; this.heartMat = glowMaterial({ intensity: 2.4, rim: 1.6, shade: 0.4, useVertexColor: true });
    this.eggGeo = new THREE.SphereGeometry(0.62, 20, 16); this.eggGeo.scale(1, 1.3, 1);
    this.eggMat = glowMaterial({ intensity: 2.0, rim: 2.0, rimPower: 1.6, shade: 0.4, useVertexColor: true });
    this.specials = [];
    for (let i = 0; i < 6; i++) {
      const isHeart = i < 3;
      const m = new THREE.Mesh(isHeart ? this.heartGeo : this.eggGeo, isHeart ? this.heartMat : this.eggMat);
      m.visible = false; m.frustumCulled = false;
      // glow colour via instanceColor isn't available on a plain mesh → use a child sprite-ish point
      scene.add(m);
      this.specials.push({ mesh: m, kind: isHeart ? 'heart' : 'egg', active: false, s: 0, x: 0 });
    }
    // special glow (Points)
    const sg = new THREE.BufferGeometry();
    this.spPos = new Float32Array(6 * 3); this.spCol = new Float32Array(6 * 3); this.spSize = new Float32Array(6);
    sg.setAttribute('position', new THREE.BufferAttribute(this.spPos, 3).setUsage(THREE.DynamicDrawUsage));
    sg.setAttribute('aColor', new THREE.BufferAttribute(this.spCol, 3).setUsage(THREE.DynamicDrawUsage));
    sg.setAttribute('aSize', new THREE.BufferAttribute(this.spSize, 1).setUsage(THREE.DynamicDrawUsage));
    sg.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);
    this.spGlow = new THREE.Points(sg, this.haloMat); this.spGlow.frustumCulled = false; this.spGlow.renderOrder = 7;
    scene.add(this.spGlow);

    this.tintSpecials();
    // events
    this.onCollect = null; this.onHit = null; this.onGate = null; this.onHeart = null; this.onEgg = null;
    this.nextS = 0; this.patternIdx = 0; this.lastSpecial = 0; this.nextEggS = 0; this.nextHeartS = 0;
    this._c = new THREE.Color();
  }

  setScale(heightPx, fovDeg) {
    this.haloMat.uniforms.uScale.value = heightPx / (2 * Math.tan(THREE.MathUtils.degToRad(fovDeg) / 2));
  }

  reset(startS) {
    for (const o of this.orbs) this.orbPool.push(o);
    this.orbs.length = 0; this.obstacles.length = 0;
    this.gates.forEach((g) => { g.active = false; g.mesh.visible = false; });
    this.specials.forEach((sp) => { sp.active = false; sp.mesh.visible = false; });
    this.nextS = startS + 70; this.patternIdx = Math.floor(startS / 60);
    this.nextEggS = startS + 200; this.nextHeartS = startS + 520;
    this.safeUntil = startS + 60;
  }

  // ---- spawning ---------------------------------------------------------------------
  orbY(s) { return waterFactor(s) > 0.5 ? WATER_LEVEL + 1.05 : Math.max(1.5, pathY(s) + 1.55); }

  addOrb(x, s, c, y = null) {
    const o = this.orbPool.pop() || {};
    o.x = x; o.s = s; o.c = c; o.y = y ?? this.orbY(s); o.ph = Math.random() * TAU; o.alive = true; o.pull = 0;
    this.orbs.push(o);
    return o;
  }
  addObstacle(x, s, scale = 1) {
    if (this.obstacles.length >= MAX_OBS) return;
    const water = waterFactor(s) > 0.5;
    this.obstacles.push({ x, s, scale, r: 1.05 * scale, water, y: water ? WATER_LEVEL - 0.6 : pathY(s) });
  }
  addGate(s) {
    const g = this.gates.find((q) => !q.active); if (!g) return;
    g.active = true; g.s = s; g.passed = false; g.mesh.visible = true;
    const y = waterFactor(s) > 0.5 ? WATER_LEVEL - 0.1 : pathY(s);
    g.mesh.position.set(0, y, -s);
  }
  addSpecial(kind, s, x) {
    const sp = this.specials.find((q) => !q.active && q.kind === kind); if (!sp) return;
    sp.active = true; sp.s = s; sp.x = x; sp.mesh.visible = true;
  }

  // Layout generator. Patterns are chosen from the level number so difficulty ramps naturally.
  generate(playerS, level, flags) {
    while (this.nextS < playerS + AHEAD) {
      const s0 = this.nextS;
      const R = rng((this.patternIdx++) * 977 + 31);
      const diff = Math.min(1, level / 8 + (s0 - 0) * 0.00002);
      const inWater = waterFactor(s0) > 0.4;
      const color = Math.floor(R() * COLORS.length);
      const lane = Math.floor(R() * 3);
      const roll = R();
      let len = 40;
      const safe = s0 < this.safeUntil;
      const obsChance = safe ? 0 : (0.25 + diff * 0.45);

      if (roll < 0.2) {                            // straight line in a lane (chroma chain)
        const n = 7 + Math.floor(R() * 4);
        for (let i = 0; i < n; i++) this.addOrb(LANES[lane], s0 + i * 3.4, color);
        len = n * 3.4 + 12;
      } else if (roll < 0.4) {                     // flowing sine wave, rainbow
        const n = 16, amp = 3.2 + R() * 1.4, wl = 34 + R() * 12, ph = R() * TAU;
        for (let i = 0; i < n; i++) this.addOrb(clamp(Math.sin(ph + (i / n) * TAU * (n * 3.2 / wl)) * amp, -4.6, 4.6), s0 + i * 3.2, (color + i) % COLORS.length);
        len = n * 3.2 + 12;
      } else if (roll < 0.55) {                    // zig-zag, single colour
        const n = 10;
        for (let i = 0; i < n; i++) this.addOrb(((i % 2) ? 1 : -1) * (2.0 + (i % 4) * 0.7), s0 + i * 3.6, color);
        len = n * 3.6 + 10;
      } else if (roll < 0.68) {                    // three coloured lanes: pick your colour
        const n = 6;
        for (let l = 0; l < 3; l++) for (let i = 0; i < n; i++) this.addOrb(LANES[l], s0 + i * 3.6, (color + l * 2) % COLORS.length);
        len = n * 3.6 + 12;
      } else if (roll < 0.8) {                     // gate with a line through it
        this.addGate(s0 + 14);
        for (let i = 0; i < 9; i++) this.addOrb(Math.sin(i * 0.7) * 2.2, s0 + i * 3.2, (color + i) % COLORS.length, this.orbY(s0) + Math.sin((i / 8) * Math.PI) * 1.2);
        len = 40;
      } else {                                     // wall of obstacles with a gap + reward
        const gap = lane;
        if (obsChance > 0) {
          for (let l = 0; l < 3; l++) if (l !== gap) this.addObstacle(LANES[l] + (R() - 0.5) * 0.8, s0 + 8, 1 + R() * 0.3);
          if (diff > 0.35 && R() < 0.5) { for (let l = 0; l < 3; l++) if (l !== (gap + 1) % 3) this.addObstacle(LANES[l], s0 + 28, 1); }
        }
        for (let i = 0; i < 6; i++) this.addOrb(LANES[gap], s0 + 2 + i * 3, color);
        len = 42;
      }

      // sprinkle extra obstacles between patterns on harder levels
      if (!safe && R() < obsChance * 0.6) {
        const n = 1 + Math.floor(R() * (1 + diff * 2));
        for (let i = 0; i < n; i++) this.addObstacle((R() - 0.5) * 9, s0 + len * (0.25 + 0.5 * R()), 0.8 + R() * 0.5);
      }

      // hearts & Lumi's egg
      if (s0 > this.nextHeartS) { this.addSpecial('heart', s0 + len * 0.5, (R() - 0.5) * 6); this.nextHeartS = s0 + 700 + R() * 300; }
      if (s0 > this.nextEggS && !flags.companionActive) { this.addSpecial('egg', s0 + len * 0.5, (R() - 0.5) * 6); this.nextEggS = s0 + 650 + R() * 250; }

      this.nextS = s0 + len + 14 + R() * 12 - diff * 6;
    }
  }

  // ---- per-frame ---------------------------------------------------------------------------
  update(dt, time, st) {
    // st: { s, x, y, inWater, magnet, invulnerable, boost }
    const { s, x } = st;
    const gate = this.gates, sp = this.specials;
    // orbs
    const oc = this.orbMesh.instanceColor.array;
    let n = 0;
    const m = this._m || (this._m = new THREE.Matrix4());
    const q = this._q || (this._q = new THREE.Quaternion());
    const e = this._e || (this._e = new THREE.Euler());
    const p3 = this._p3 || (this._p3 = new THREE.Vector3());
    const s3 = this._s3 || (this._s3 = new THREE.Vector3());
    const collected = [];
    for (let i = this.orbs.length - 1; i >= 0; i--) {
      const o = this.orbs[i];
      if (o.s < s - 22) { this.orbPool.push(o); this.orbs[i] = this.orbs[this.orbs.length - 1]; this.orbs.pop(); continue; }
    }
    for (let i = 0; i < this.orbs.length && n < MAX_ORBS; i++) {
      const o = this.orbs[i];
      // magnet (companion) pulls nearby orbs toward the player
      if (st.magnet > 0) {
        const dx = x - o.x, ds = s - o.s;
        const d = Math.hypot(dx, ds);
        if (d < st.magnet && d > 0.01) { o.pull = Math.min(1, o.pull + dt * 3); const k = o.pull * dt * 16; o.x += dx * Math.min(1, k * 0.2); o.s += ds * Math.min(1, k * 0.2); o.y += (st.y + 1.0 - o.y) * Math.min(1, k * 0.15); }
      }
      const dx = o.x - x, ds = o.s - s;
      if (Math.abs(ds) < 1.6 && Math.abs(dx) < 1.45) {
        collected.push(o);
        this.orbs[i] = this.orbs[this.orbs.length - 1]; this.orbs.pop(); i--; continue;
      }
      const bob = Math.sin(time * 3 + o.ph) * 0.18;
      const sc = 0.9 + Math.sin(time * 4 + o.ph) * 0.08;
      p3.set(o.x, o.y + bob, -o.s); s3.set(sc, sc, sc); e.set(time * 1.4 + o.ph, time * 2 + o.ph, 0); q.setFromEuler(e);
      m.compose(p3, q, s3); this.orbMesh.setMatrixAt(n, m);
      const col = COLORS[o.c].hex; this._c.set(col);
      oc[n * 3] = this._c.r; oc[n * 3 + 1] = this._c.g; oc[n * 3 + 2] = this._c.b;
      this.haloPos[n * 3] = o.x; this.haloPos[n * 3 + 1] = o.y + bob; this.haloPos[n * 3 + 2] = -o.s;
      this.haloCol[n * 3] = this._c.r; this.haloCol[n * 3 + 1] = this._c.g; this.haloCol[n * 3 + 2] = this._c.b;
      this.haloSize[n] = 1.9 + Math.sin(time * 5 + o.ph) * 0.25;
      n++;
    }
    this.orbMesh.count = n;
    this.orbMesh.instanceMatrix.needsUpdate = true; this.orbMesh.instanceColor.needsUpdate = true;
    for (let i = n; i < MAX_ORBS; i++) this.haloSize[i] = 0;
    const ha = this.halos.geometry.attributes;
    ha.position.needsUpdate = ha.aColor.needsUpdate = ha.aSize.needsUpdate = true;
    for (const o of collected) {
      this.particles.burst(o.x, o.y, -o.s, this._c.set(COLORS[o.c].hex).multiplyScalar(1.3), 16, 6, 0.55, 0.7, { star: 1, drag: 2.2 });
      this.onCollect?.(o);
      this.orbPool.push(o);
    }

    // obstacles
    const oi = this.obsMesh.instanceColor.array;
    let k = 0;
    for (let i = this.obstacles.length - 1; i >= 0; i--) if (this.obstacles[i].s < s - 22) { this.obstacles[i] = this.obstacles[this.obstacles.length - 1]; this.obstacles.pop(); }
    for (const ob of this.obstacles) {
      if (k >= MAX_OBS) break;
      p3.set(ob.x, ob.y, -ob.s); s3.set(ob.scale, ob.scale, ob.scale); e.set(0, ob.s * 0.37, 0); q.setFromEuler(e);
      m.compose(p3, q, s3); this.obsMesh.setMatrixAt(k, m);
      // dark amethyst crystals with a hot-pink rim; coral variant underwater
      if (ob.water) { oi[k * 3] = 0.12; oi[k * 3 + 1] = 0.55; oi[k * 3 + 2] = 0.65; }
      else { oi[k * 3] = 0.42; oi[k * 3 + 1] = 0.16; oi[k * 3 + 2] = 0.72; }
      k++;
      if (!st.invulnerable && Math.abs(ob.s - s) < 1.0 && Math.abs(ob.x - x) < ob.r + 0.55) {
        ob.s = -1e9;
        this.particles.burst(ob.x, ob.y + 1, -s, this._c.set(0xff5fb0), 40, 9, 0.7, 0.8, { star: 1, gravity: 4, drag: 1.5 });
        this.onHit?.(ob);
      }
    }
    this.obsMesh.count = k;
    this.obsMesh.instanceMatrix.needsUpdate = true; this.obsMesh.instanceColor.needsUpdate = true;

    // gates
    for (const g of gate) {
      if (!g.active) continue;
      if (g.s < s - 25) { g.active = false; g.mesh.visible = false; continue; }
      if (!g.passed && g.s <= s) {
        g.passed = true;
        if (Math.abs(x) < 7.2) {
          this.onGate?.(g);
          for (let i = 0; i < 60; i++) {
            const a = (i / 60) * Math.PI;
            const col = this._c.set(RAINBOW[i % RAINBOW.length]);
            this.particles.emit(Math.cos(a) * 7, g.mesh.position.y + Math.sin(a) * 7, -g.s, 0, 0, 7 + Math.random() * 4, col.r * 1.4, col.g * 1.4, col.b * 1.4, 0.7, 1.1, { star: 1, drag: 1.2 });
          }
        }
      }
      // shimmer at the apex
      if (Math.random() < dt * 20) {
        const a = Math.random() * Math.PI, r = 7.3 - Math.floor(Math.random() * 6) * 0.34;
        const col = this._c.set(RAINBOW[Math.floor(Math.random() * 6)]);
        this.particles.emit(Math.cos(a) * r, g.mesh.position.y + Math.sin(a) * r, -g.s, 0, 0.4, 0, col.r, col.g, col.b, 0.35, 0.9, { star: 1 });
      }
    }

    // hearts & eggs
    let sc = 0;
    for (const o of sp) {
      if (!o.active) { this.spSize[sc++] = 0; continue; }
      if (o.s < s - 22) { o.active = false; o.mesh.visible = false; this.spSize[sc++] = 0; continue; }
      const y = (waterFactor(o.s) > 0.5 ? WATER_LEVEL + 1.3 : 2.0) + Math.sin(time * 2.6 + o.s) * 0.25;
      o.mesh.position.set(o.x, y, -o.s);
      o.mesh.rotation.y = time * 1.8;
      const pulse = 1 + Math.sin(time * 5) * 0.07;
      o.mesh.scale.setScalar(o.kind === 'heart' ? 1.05 * pulse : pulse);
      const col = o.kind === 'heart' ? this._c.set(0xff4f8f) : this._c.set(0xffe9a0);
      // tint via material uniform isn't per-mesh, so approximate with the glow Points
      this.spPos[sc * 3] = o.x; this.spPos[sc * 3 + 1] = y; this.spPos[sc * 3 + 2] = -o.s;
      this.spCol[sc * 3] = col.r; this.spCol[sc * 3 + 1] = col.g; this.spCol[sc * 3 + 2] = col.b;
      this.spSize[sc++] = 4.2 + Math.sin(time * 4) * 0.4;
      if (Math.abs(o.s - s) < 1.8 && Math.abs(o.x - x) < 1.9) {
        o.active = false; o.mesh.visible = false;
        this.particles.burst(o.x, y, -o.s, this._c.set(o.kind === 'heart' ? 0xff6aa8 : 0xffe9a0).multiplyScalar(1.4), 50, 7, 0.7, 1.0, { star: 1, drag: 1.5 });
        if (o.kind === 'heart') this.onHeart?.(o); else this.onEgg?.(o);
      }
      if (Math.random() < dt * 14) this.particles.emit(o.x + (Math.random() - 0.5), y + (Math.random() - 0.5), -o.s, 0, 0.6, 0, col.r, col.g, col.b, 0.3, 0.9, { star: 1 });
    }
    const sa = this.spGlow.geometry.attributes; sa.position.needsUpdate = sa.aColor.needsUpdate = sa.aSize.needsUpdate = true;
  }

  // set special mesh colours once (they use the shared glow material with white base → tint via vertex)
  tintSpecials() {
    this.specials.forEach((sp) => {
      const g = sp.mesh.geometry;
      if (!g.attributes.color) {
        const col = new THREE.Color(sp.kind === 'heart' ? 0xff4f8f : 0xffe9a0);
        const arr = new Float32Array(g.attributes.position.count * 3);
        for (let i = 0; i < arr.length; i += 3) { arr[i] = col.r; arr[i + 1] = col.g; arr[i + 2] = col.b; }
        g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
      }
    });
  }

  // drop a few orbs ahead of the player (Lumi's goodbye gift)
  gift(s, x, n = 7) {
    const colour = Math.floor(Math.random() * COLORS.length);
    for (let i = 0; i < n; i++) this.addOrb(clamp(x + Math.sin(i * 0.9) * 1.5, -4.6, 4.6), s + 14 + i * 2.8, colour, this.orbY(s) + 0.2);
  }
}
