// "Lumi", the baby butterfly-unicorn companion. She joins you, trails behind for a limited
// time, then says goodbye and drifts away in a shower of stars (leaving a gift of orbs).
import * as THREE from '../vendor/three.bundle.js';
import { fanGeometry, wingMaterial } from './geo.js';
import { COMPANION_LIFETIME } from './config.js';
import { damp, clamp, smooth, lerp } from './util.js';

function babyWingShape() {
  const s = new THREE.Shape();
  s.moveTo(0.05, 0.1);
  s.bezierCurveTo(0.3, 0.8, 1.0, 1.0, 1.4, 0.55);
  s.bezierCurveTo(1.6, 0.2, 1.3, -0.1, 0.95, -0.15);
  s.bezierCurveTo(1.2, -0.6, 0.8, -1.0, 0.4, -0.85);
  s.bezierCurveTo(0.1, -0.7, 0.05, -0.3, 0.05, -0.1);
  s.closePath();
  return s;
}
const BABY_WING_G = fanGeometry(babyWingShape(), 36, new THREE.Vector2(0.08, 0));

export class Companion {
  constructor(scene, particles) {
    this.scene = scene; this.particles = particles;
    this.root = new THREE.Group(); this.root.visible = false; scene.add(this.root);
    this.state = 'hidden';  // hidden | arriving | following | goodbye | leaving
    this.timer = 0; this.life = 0; this.t = 0; this.stateT = 0;
    this.speech = null; this.speechUntil = 0;
    this.vel = new THREE.Vector3();
    this.pos = new THREE.Vector3();
    this.rel = new THREE.Vector3();     // offset from the player (so Lumi never lags behind at speed)
    this._prev = new THREE.Vector3();
    this.color = new THREE.Color(0xffd0ec);
    this.fade = 1;
    this.blink = 0; this.nextBlink = 2;
    this.onSay = null; this.onGoodbye = null; this.onGift = null;

    const bodyMat = new THREE.MeshPhysicalMaterial({ color: 0xfff2fa, roughness: 0.35, clearcoat: 0.8, sheen: 1, sheenColor: new THREE.Color(0xffa0d8), emissive: 0xff9ad0, emissiveIntensity: 0.18 });
    this.bodyMat = bodyMat;
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.4, 24, 18), bodyMat); body.scale.set(1, 0.95, 1.05); this.root.add(body);
    this.body = body;
    const belly = new THREE.Mesh(new THREE.SphereGeometry(0.3, 16, 12), new THREE.MeshStandardMaterial({ color: 0xffe0f0, roughness: 0.6, emissive: 0xffc0e0, emissiveIntensity: 0.3 }));
    belly.position.set(0, -0.14, -0.14); this.root.add(belly);

    const eyeMat = new THREE.MeshStandardMaterial({ color: 0x1b0b30, roughness: 0.08, metalness: 0.1 });
    const hiMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    this.eyes = [];
    for (const sx of [-1, 1]) {
      const e = new THREE.Group(); e.position.set(sx * 0.16, 0.07, -0.34);
      const ball = new THREE.Mesh(new THREE.SphereGeometry(0.1, 14, 12), eyeMat); ball.scale.set(1, 1.2, 0.6); e.add(ball);
      const h1 = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 8), hiMat); h1.position.set(0.03 * sx, 0.05, -0.05); e.add(h1);
      const h2 = new THREE.Mesh(new THREE.SphereGeometry(0.018, 8, 8), hiMat); h2.position.set(-0.03 * sx, -0.03, -0.06); e.add(h2);
      this.root.add(e); this.eyes.push(e);
      const bl = new THREE.Mesh(new THREE.CircleGeometry(0.075, 14), new THREE.MeshBasicMaterial({ color: 0xff7fb8, transparent: true, opacity: 0.6, depthWrite: false }));
      bl.position.set(sx * 0.26, -0.06, -0.3); bl.rotation.y = sx * 0.9; this.root.add(bl);
      const ear = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.2, 8), bodyMat); ear.position.set(sx * 0.2, 0.36, -0.02); ear.rotation.z = -sx * 0.35; this.root.add(ear);
    }
    const smile = new THREE.Mesh(new THREE.TorusGeometry(0.055, 0.012, 6, 14, Math.PI), new THREE.MeshBasicMaterial({ color: 0xc23c7c }));
    smile.position.set(0, -0.06, -0.385); smile.rotation.z = Math.PI; this.root.add(smile);
    this.horn = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.22, 8), new THREE.MeshStandardMaterial({ color: 0xffe9a0, emissive: 0xffd060, emissiveIntensity: 1.4, metalness: 0.4, roughness: 0.3 }));
    this.horn.position.set(0, 0.42, -0.18); this.horn.rotation.x = -0.4; this.root.add(this.horn);
    // halo
    this.halo = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.025, 8, 24), new THREE.MeshBasicMaterial({ color: 0xfff0a0 }));
    this.halo.position.set(0, 0.72, 0); this.halo.rotation.x = Math.PI / 2; this.root.add(this.halo);

    this.wingMat = wingMaterial({ colorA: 0xffa0d8, colorB: 0xffe9a0, intensity: 1.7, style: 0 });
    this.wR = new THREE.Group(); this.wL = new THREE.Group();
    const r = new THREE.Mesh(BABY_WING_G, this.wingMat), l = new THREE.Mesh(BABY_WING_G, this.wingMat);
    r.scale.setScalar(0.62); l.scale.set(-0.62, 0.62, 0.62);
    this.wR.add(r); this.wL.add(l);
    this.wR.position.set(0.15, 0.25, 0.1); this.wL.position.set(-0.15, 0.25, 0.1);
    this.root.add(this.wR, this.wL);

    this.root.traverse((o) => { if (o.material && o.material.transparent === undefined) o.material.transparent = false; });
    this.allMats = [];
    this.root.traverse((o) => { if (o.isMesh) this.allMats.push(o.material); });
  }

  get active() { return this.state !== 'hidden'; }
  get following() { return this.state === 'following'; }
  get remaining() { return this.state === 'following' ? Math.max(0, this.life - this.timer) : 0; }
  get fraction() { return this.state === 'following' ? 1 - this.timer / this.life : 0; }

  say(text, secs = 2.6) {
    this.speech = text; this.speechUntil = this.t + secs; this.onSay?.(text, secs);
  }

  summon(playerPos, lifetime = COMPANION_LIFETIME) {
    if (this.state === 'following') { this.timer = Math.max(0, this.timer - lifetime * 0.5); this.say('Yay, more fun together! 💖'); return; }
    this.state = 'arriving'; this.stateT = 0; this.timer = 0; this.life = lifetime; this.fade = 0;
    this.root.visible = true;
    this.rel.set(3, 6, 5);
    this.pos.set(playerPos.x + 3, playerPos.y + 6, playerPos.z + 5);
    this.root.position.copy(this.pos); this.root.scale.setScalar(0.01);
    this.vel.set(0, 0, 0);
    this._burst(this.pos, 26, 5);
  }

  dismiss() { this.state = 'hidden'; this.root.visible = false; this.speech = null; }

  _burst(p, n, sp) {
    this.particles.burst(p.x, p.y, p.z, this.color.set(0xffd0f0), n, sp, 0.5, 1.1, { star: 1, drag: 1.2 });
    this.particles.burst(p.x, p.y, p.z, this.color.set(0xfff0a0), Math.floor(n * 0.6), sp * 0.8, 0.4, 1.0, { star: 1, drag: 1.0 });
  }

  update(dt, time, player, speed) {
    this.t = time;
    if (this.state === 'hidden') return;
    this.stateT += dt;
    const root = this.root;
    const px = player.rig.position.x, py = player.rig.position.y, pz = player.rig.position.z;
    const bob = Math.sin(time * 3.1) * 0.22;
    let tx, ty, tz, lam = 3.2;

    if (this.state === 'arriving') {
      // swoops in from above-behind with a little spiral
      const k = smooth(0, 1.6, this.stateT);
      const a = (1 - k) * 5;
      tx = px + 2.0 + Math.sin(a) * (1 - k) * 3; ty = py + 1.7 + (1 - k) * 4 + bob; tz = pz + 3.8 + (1 - k) * 3 + Math.cos(a) * (1 - k);
      lam = 3.0;
      root.scale.setScalar(Math.min(1, root.scale.x + dt * 1.6));
      this.fade = 1;
      if (this.stateT > 0.6 && !this._hello) { this._hello = true; this.say("Hi! I'm Lumi! Can I fly with you? ✨", 3.2); this.onHello?.(); }
      if (this.stateT >= 1.8) { this.state = 'following'; this._hello = false; this.timer = 0; }
    } else if (this.state === 'following') {
      this.timer += dt;
      const sway = Math.sin(time * 1.1) * 2.1;
      tx = px + 1.9 + sway * 0.5 + Math.sin(time * 0.7) * 0.8; ty = py + 1.5 + bob + Math.sin(time * 1.7) * 0.2; tz = pz + 3.7;
      root.scale.setScalar(damp(root.scale.x, 1, 6, dt));
      // sweet chatter
      if (!this._chat1 && this.timer > this.life * 0.4) { this._chat1 = true; this.say('Wheee! This is so fun! 🌈', 2.4); }
      if (!this._chat2 && this.timer > this.life * 0.72) { this._chat2 = true; this.say("I love our colours! 💗", 2.4); }
      if (this.timer >= this.life) { this.state = 'goodbye'; this.stateT = 0; this._chat1 = this._chat2 = false; }
      // little hearts now and then
      if (Math.random() < dt * 0.9) {
        this.particles.emit(this.pos.x, this.pos.y + 0.7, this.pos.z, (Math.random() - 0.5) * 0.6, 1.1, 0.4, 1.0, 0.45, 0.75, 0.5, 1.4, { star: 0, alpha: 0.9 });
      }
    } else if (this.state === 'goodbye') {
      // slides beside the player, waves, and says goodbye
      tx = px + 1.7; ty = py + 2.3 + bob * 0.5; tz = pz - 0.2;
      lam = 4.0;
      if (this.stateT > 0.35 && !this._bye) {
        this._bye = true; this.say('Bye-bye! See you soon, friend! 💖', 3.2); this.onGoodbye?.();
      }
      if (this.stateT > 3.0) { this.state = 'leaving'; this.stateT = 0; this._bye = false; this._gift = false; }
    } else { // leaving
      const k = smooth(0, 1.8, this.stateT);
      tx = this.pos.x + Math.sin(time * 4) * 0.4; ty = this.pos.y + 8 * dt; tz = this.pos.z + speed * dt * 0.25;
      lam = 8;
      root.scale.setScalar(Math.max(0.001, 1 - k));
      if (this.stateT > 0.25 && !this._gift) { this._gift = true; this.onGift?.(); this._burst(this.pos, 70, 8); }
      this.particles.emit(this.pos.x, this.pos.y, this.pos.z, (Math.random() - 0.5) * 2, 1 + Math.random() * 2, (Math.random() - 0.5) * 2, 1, 0.85, 1, 0.4, 1.3, { star: 1, drag: 1 });
      if (this.stateT >= 1.9) { this.state = 'hidden'; root.visible = false; this.speech = null; return; }
    }

    // spring-follow in the player's frame of reference (no lag at speed)
    this._prev.copy(this.pos);
    this.rel.x = damp(this.rel.x, tx - px, lam, dt);
    this.rel.y = damp(this.rel.y, ty - py, lam * 1.1, dt);
    this.rel.z = damp(this.rel.z, tz - pz, lam * 0.9, dt);
    this.pos.set(px + this.rel.x, py + this.rel.y, pz + this.rel.z);
    this.vel.set((this.pos.x - this._prev.x) / Math.max(dt, 1e-4), (this.pos.y - this._prev.y) / Math.max(dt, 1e-4), 0);
    root.position.copy(this.pos);
    // orientation: lean into motion, face forward, wave when saying goodbye
    root.rotation.z = damp(root.rotation.z, clamp(-this.vel.x * 0.05, -0.5, 0.5), 8, dt);
    root.rotation.x = damp(root.rotation.x, clamp(this.vel.y * 0.03, -0.4, 0.4), 6, dt);
    root.rotation.y = this.state === 'leaving' ? root.rotation.y + dt * 8 : damp(root.rotation.y, 0, 5, dt);
    if (this.state === 'goodbye') root.rotation.z = Math.sin(time * 9) * 0.28;   // happy wave/wiggle
    // wings
    const f = Math.sin(time * 18) * 0.75 + 0.35;
    this.wR.rotation.z = f; this.wL.rotation.z = -f;
    this.halo.rotation.z = time * 2; this.halo.position.y = 0.72 + Math.sin(time * 4) * 0.03;
    // blink
    this.nextBlink -= dt;
    if (this.nextBlink <= 0) { this.blink = 0.14; this.nextBlink = 1.6 + Math.random() * 2.4; }
    if (this.blink > 0) this.blink -= dt;
    const ey = this.blink > 0 ? 0.1 : 1;
    this.eyes.forEach((e) => { e.scale.y = damp(e.scale.y, ey, 40, dt); });
    // sparkle trail
    if (Math.random() < dt * 30) {
      this.particles.emit(this.pos.x + (Math.random() - 0.5) * 0.4, this.pos.y + (Math.random() - 0.5) * 0.4, this.pos.z + 0.4,
        0, 0.2, 1.5, 1.0, 0.8 + Math.random() * 0.2, 0.95, 0.2 + Math.random() * 0.15, 0.7, { star: Math.random() < 0.5 ? 1 : 0, drag: 0.5 });
    }
    // low-time flicker warning (gentle pulse in glow)
    const warn = this.state === 'following' && this.remaining < 4 ? 0.5 + 0.5 * Math.sin(time * 10) : 0;
    this.bodyMat.emissiveIntensity = 0.18 + warn * 0.5;
    if (this.speech && time > this.speechUntil) this.speech = null;
  }
}
