// Procedural audio — no audio files needed, so it works offline and ships tiny.
// WebAudio synth: pickup chimes (one pentatonic note per colour), morph shimmer,
// boost whoosh, splash, hit, goodbye lullaby and a gentle generative music bed.
import { COLORS } from './config.js';

const PENTA = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24]; // major pentatonic semitones
const midiHz = (m) => 440 * Math.pow(2, (m - 69) / 12);

export class AudioEngine {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.sfxBus = null;
    this.musicBus = null;
    this.muted = false;
    this.sfxVol = 0.9;
    this.musicVol = 0.55;
    this.musicOn = false;
    this._nextBar = 0;
    this._bar = 0;
    this.boostNode = null;
    this.waterMix = 0;
  }

  // Must be called from a user gesture (iOS requirement).
  async unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC({ latencyHint: 'interactive' });
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 1;
      const comp = this.ctx.createDynamicsCompressor();
      comp.threshold.value = -14; comp.ratio.value = 4;
      this.master.connect(comp); comp.connect(this.ctx.destination);

      this.sfxBus = this.ctx.createGain(); this.sfxBus.gain.value = this.sfxVol;
      this.musicBus = this.ctx.createGain(); this.musicBus.gain.value = this.musicVol * 0.5;
      // low-pass on music that closes slightly underwater
      this.musicFilter = this.ctx.createBiquadFilter();
      this.musicFilter.type = 'lowpass'; this.musicFilter.frequency.value = 12000;
      this.musicBus.connect(this.musicFilter); this.musicFilter.connect(this.master);
      this.sfxBus.connect(this.master);

      // tiny convolution-free reverb: feedback delay
      this.delay = this.ctx.createDelay(1.0); this.delay.delayTime.value = 0.27;
      const fb = this.ctx.createGain(); fb.gain.value = 0.32;
      const wet = this.ctx.createGain(); wet.gain.value = 0.35;
      const lp = this.ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 3200;
      this.delay.connect(lp); lp.connect(fb); fb.connect(this.delay); lp.connect(wet);
      wet.connect(this.master);
      this.fxSend = this.ctx.createGain(); this.fxSend.gain.value = 0.5;
      this.fxSend.connect(this.delay);

      this._noise = this._makeNoise();
    }
    if (this.ctx.state !== 'running') { try { await this.ctx.resume(); } catch (e) { /* ignore */ } }
  }

  _makeNoise() {
    const len = this.ctx.sampleRate * 2;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    return buf;
  }

  setMuted(m) {
    this.muted = m;
    if (this.master) this.master.gain.setTargetAtTime(m ? 0 : 1, this.ctx.currentTime, 0.05);
  }
  setVolumes(sfx, music) {
    this.sfxVol = sfx; this.musicVol = music;
    if (this.sfxBus) this.sfxBus.gain.value = sfx;
    if (this.musicBus) this.musicBus.gain.value = music * 0.5;
  }

  // ----- primitives --------------------------------------------------------
  _tone(freq, t, dur, { type = 'sine', gain = 0.3, attack = 0.005, bus = null, send = 0.4, detune = 0, slideTo = 0 } = {}) {
    const c = this.ctx;
    const o = c.createOscillator(); const g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t); o.detune.value = detune;
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(bus || this.sfxBus);
    if (send > 0) { const s = c.createGain(); s.gain.value = send; g.connect(s); s.connect(this.fxSend); }
    o.start(t); o.stop(t + dur + 0.05);
  }
  _noiseBurst(t, dur, { freq = 2000, q = 1, gain = 0.2, type = 'bandpass', sweepTo = 0 } = {}) {
    const c = this.ctx;
    const s = c.createBufferSource(); s.buffer = this._noise;
    const f = c.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(freq, t); f.Q.value = q;
    if (sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo, t + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + dur * 0.2);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(this.sfxBus);
    s.start(t, Math.random()); s.stop(t + dur + 0.05);
  }

  // ----- SFX ---------------------------------------------------------------
  pickup(colorIdx, streak = 0) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const step = (COLORS[colorIdx].note + Math.min(streak, 6) * 2) % PENTA.length;
    const base = 72 + PENTA[step % PENTA.length] % 24;
    const f = midiHz(base);
    this._tone(f, t, 0.5, { type: 'sine', gain: 0.32 });
    this._tone(f * 2, t + 0.02, 0.45, { type: 'triangle', gain: 0.14 });
    this._tone(f * 3.01, t + 0.04, 0.3, { type: 'sine', gain: 0.07 });
    this._tone(f * 1.5, t + 0.07, 0.35, { type: 'sine', gain: 0.1 });
    if (streak >= 2) this._tone(f * 4, t + 0.1, 0.4, { type: 'sine', gain: 0.08 });
  }
  chain() { // chroma chain (3+ same colour)
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    [0, 4, 7, 12, 16, 19, 24].forEach((s, i) => this._tone(midiHz(72 + s), t + i * 0.05, 0.7, { gain: 0.2, type: 'triangle' }));
  }
  morph(toWater) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const seq = toWater ? [84, 81, 77, 72, 65] : [65, 72, 77, 81, 84, 89];
    seq.forEach((m, i) => this._tone(midiHz(m), t + i * 0.08, 0.9, { gain: 0.18, type: 'sine', send: 0.7 }));
    this._noiseBurst(t, 0.9, { freq: toWater ? 5000 : 800, sweepTo: toWater ? 700 : 6000, q: 0.8, gain: 0.12 });
  }
  splash() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this._noiseBurst(t, 0.6, { freq: 3500, sweepTo: 600, q: 0.7, gain: 0.25 });
    this._tone(220, t, 0.25, { slideTo: 90, gain: 0.15, send: 0 });
  }
  hit() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this._tone(180, t, 0.35, { type: 'sawtooth', slideTo: 55, gain: 0.25, send: 0.1 });
    this._noiseBurst(t, 0.3, { freq: 900, q: 0.6, gain: 0.25, type: 'lowpass' });
  }
  heart() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    [76, 80, 83, 88].forEach((m, i) => this._tone(midiHz(m), t + i * 0.07, 0.5, { gain: 0.2, type: 'triangle' }));
  }
  boostStart() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this._noiseBurst(t, 0.7, { freq: 400, sweepTo: 5000, q: 1.2, gain: 0.22 });
    this._tone(220, t, 0.6, { slideTo: 880, type: 'sawtooth', gain: 0.07, send: 0.2 });
  }
  boostEnd() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this._noiseBurst(t, 0.5, { freq: 4000, sweepTo: 300, q: 1, gain: 0.12 });
  }
  gate() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    [79, 83, 86, 91].forEach((m, i) => this._tone(midiHz(m), t + i * 0.06, 0.6, { gain: 0.16, type: 'sine' }));
  }
  companionHello() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    // little "coo coo" chirps
    [88, 93, 91, 96].forEach((m, i) => this._tone(midiHz(m), t + i * 0.1, 0.18, { gain: 0.16, type: 'sine', slideTo: midiHz(m + 3), send: 0.5 }));
  }
  companionBye() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    // soft descending lullaby
    [96, 93, 91, 88, 84, 81].forEach((m, i) => this._tone(midiHz(m), t + i * 0.18, 0.7, { gain: 0.15, type: 'sine', send: 0.8 }));
  }
  gameOver() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    [72, 69, 65, 60].forEach((m, i) => this._tone(midiHz(m), t + i * 0.22, 1.0, { gain: 0.18, type: 'triangle', send: 0.7 }));
  }
  levelUp() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    [72, 76, 79, 84, 88, 91, 96].forEach((m, i) => this._tone(midiHz(m), t + i * 0.07, 0.9, { gain: 0.17, type: 'triangle', send: 0.7 }));
  }
  click() {
    if (!this.ctx) return;
    this._tone(900, this.ctx.currentTime, 0.08, { gain: 0.1, type: 'triangle', send: 0.2 });
  }

  // ----- Music: generative pentatonic pad + arpeggio -----------------------
  startMusic() {
    if (!this.ctx || this.musicOn) return;
    this.musicOn = true;
    this._nextBar = this.ctx.currentTime + 0.1;
    this._bar = 0;
  }
  stopMusic() { this.musicOn = false; }

  setWaterMix(w) {
    this.waterMix = w;
    if (this.musicFilter) this.musicFilter.frequency.setTargetAtTime(12000 - w * 10200, this.ctx.currentTime, 0.2);
  }

  update() {
    if (!this.ctx || !this.musicOn) return;
    const c = this.ctx;
    // schedule a bar ahead
    const beat = 0.5;
    while (this._nextBar < c.currentTime + 1.2) {
      const t = this._nextBar;
      const chords = [[57, 64, 69, 72], [53, 60, 65, 69], [48, 55, 60, 64], [55, 62, 67, 71]];
      const ch = chords[this._bar % chords.length];
      // pad
      ch.forEach((m) => this._tone(midiHz(m - 12 + 12), t, beat * 8, { type: 'sine', gain: 0.05, attack: 0.6, bus: this.musicBus, send: 0.3 }));
      // arpeggio
      for (let i = 0; i < 16; i++) {
        const note = ch[(i * 3 + (i >> 2)) % ch.length] + 12 + ((i % 8 === 6) ? 12 : 0);
        if (i % 2 === 0 || Math.random() < 0.35) {
          this._tone(midiHz(note), t + i * beat * 0.5, 0.45, { type: 'triangle', gain: 0.045, bus: this.musicBus, send: 0.5, attack: 0.01 });
        }
      }
      // soft bell melody
      if (Math.random() < 0.8) {
        const mel = ch[Math.floor(Math.random() * ch.length)] + 24;
        this._tone(midiHz(mel), t + beat * (1 + Math.floor(Math.random() * 5)), 1.2, { type: 'sine', gain: 0.05, bus: this.musicBus, send: 0.7 });
      }
      this._nextBar += beat * 8;
      this._bar++;
    }
  }
}
