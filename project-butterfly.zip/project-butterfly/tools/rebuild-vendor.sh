#!/usr/bin/env bash
# Rebuilds vendor/three.bundle.js (Three.js + post-processing) — only needed if you want to upgrade Three.js.
# Usage:  bash tools/rebuild-vendor.sh
set -e
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
cp tools/vendor-entry.js "$TMP/entry.js"
cd "$TMP"
npm init -y >/dev/null
npm install three esbuild >/dev/null
npx esbuild entry.js --bundle --minify --format=esm \
  --alias:three/addons=./node_modules/three/examples/jsm \
  --outfile="$OLDPWD/vendor/three.bundle.js"
echo "Done. Three.js $(node -p "require('./node_modules/three/package.json').version") bundled."
